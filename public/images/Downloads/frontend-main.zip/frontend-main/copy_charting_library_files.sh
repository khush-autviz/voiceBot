#!/bin/sh

remove_if_directory_exists() {
	if [ -d "$1" ]; then rm -Rf "$1"; fi
}

BRANCH="master";

REPOSITORY='https://github.com/tradingview/charting_library/'

# LATEST_HASH=$(git ls-remote $REPOSITORY $BRANCH | grep -Eo '^[[:alnum:]]+')
LATEST_HASH="1cc3ce33a53fd5a8003718c5efe9415dbbd4d97d"

remove_if_directory_exists "$LATEST_HASH"

git clone -q --depth 1 -b "$BRANCH" $REPOSITORY "$LATEST_HASH"

mkdir -p "src/assets/js"

remove_if_directory_exists "src/assets/js/charting_library"
# remove_if_directory_exists "src/assets/js/datafeeds"

cp -r "$LATEST_HASH/charting_library" src/assets/js/charting_library
# cp -r "$LATEST_HASH/datafeeds" src/assets/js

remove_if_directory_exists "$LATEST_HASH"
# read  -n 1 -p "Input Selection:" mainmenuinput
