import { environment } from "src/environment/environment";
import { SolusMode, SupportedCoin } from "src/types/app.types";

export const BASE_URL: string = environment.backend;
export const PUBLIC = '/public';
export const ERROR_LOG = `${BASE_URL}/log`;

/** Login Related */
export const LOGIN_WITH_EMAIL = `${BASE_URL}${PUBLIC}/login/email`;
export const LOGIN_WITH_GOOGLE = `${BASE_URL}${PUBLIC}/login/google`;
export const SEND_OTP = `${BASE_URL}${PUBLIC}/otp`
export const VERIFY_OTP = `${BASE_URL}${PUBLIC}/verify`;
export const USER_VERIFY_OTP = `${BASE_URL}/user/verify`;
export const FORGOT_PASSWORD_REQUEST_OTP = `${BASE_URL}${PUBLIC}/forgot-password`;
export const FORGOT_PASSWORD_VERIFY_OTP = `${BASE_URL}${PUBLIC}/forgot-password/verify`;

/** Engagement Related */
export const REFERRAL = `${BASE_URL}/referral`;
export const REWARDS = `${REFERRAL}/rewards`;
export const REWARDS_MAINNET_TOKEN = `${REFERRAL}/rewards/main-net-token`;
export const REWARDS_USDT = `${REFERRAL}/rewards/usdt`;
export const REFERRAL_TRANSACTIONS = `${REFERRAL}/transactions`;

/** User Profile Related */
export const USER_INFO_CURRENCY = (coin: SupportedCoin): string => `${BASE_URL}/user?currency=${SupportedCoin[coin]}`;
export const BALANCE = `${BASE_URL}/user/balances`;
export const CURRENCY: string = `${BASE_URL}/currency`;
export const SAVE_PROFILE = `${BASE_URL}/user`
export const SET_PASSWORD = `${BASE_URL}/user/password`;

/** Market Related */
export const ASSETS_BY_ID = (assetId: number): string => `${BASE_URL}/assets/${assetId}`;
export const LISTED_ASSETS = `${BASE_URL}/assets/trade-variation`;

/** KYC Related */
const KYC_BASE_URL = `${BASE_URL}/kyc`;
export const KYC_STATUS = `${KYC_BASE_URL}/status`;
export const KYC_ALL = `${KYC_BASE_URL}/all`;
export const KYC_STEP_1 = `${KYC_BASE_URL}/step-1`;
export const KYC_STEP_2 = `${KYC_BASE_URL}/step-2`;
export const KYC_STEP_3 = `${KYC_BASE_URL}/step-3`;
export const KYC_STEP_4 = `${KYC_BASE_URL}/step-4`;
export const KYC_START_CHECK = `${KYC_BASE_URL}/check`;
export const KYC_TOKEN = `${KYC_BASE_URL}/token`;

/** Token Related */
export const TOKEN_BASE_URL = `${BASE_URL}/token`;
export const DEPOSIT_USDT = `${TOKEN_BASE_URL}/deposit/usdt`;
export const WITHDRAW_USDT = `${TOKEN_BASE_URL}/withdraw/usdt`;
export const WITHDRAW_USDT_CHARGES = `${TOKEN_BASE_URL}/withdraw/usdt/charges`;
export const DEPOSIT_USDT_V2 = `${TOKEN_BASE_URL}/deposit/usdt/v2`;

/** Transactions */
export const TRANSACTIONS = (coin: SupportedCoin, referenceId?: number) => `${BASE_URL}/transactions?currency=${SupportedCoin[coin]}${referenceId ? `&referenceId=${referenceId}` : ''}`;

/** Settings */
export const SETTINGS = `${BASE_URL}/settings`;

/** Portfolio */
export const PORTFOLIO_COMBINED = `${BASE_URL}/portfolio/combined`;

/** Deposit */
export const DEPOSIT_ADDRESS = `${BASE_URL}/mapping/deposit`;
export const POLYGONSCAN_TRANSACTIONS = (address: string) => `https://api.polygonscan.com/api?module=account&action=tokentx&contractaddress=0xc2132D05D31c914a87C6611C10748AEb04B58e8F&address=${address}&apikey=${environment.polygonScanApiKey}&page=1&offset=1000&sort=desc`;
export const PAYPAL_INIT = `${BASE_URL}/paypal/init`;
export const PAYPAL_COMPLETE = `${BASE_URL}/paypal/complete`;
export const PAYPAL_CANCEL = `${BASE_URL}/paypal/cancel`;

/** Spot Trading */
export const SPOT_TRADES = `${BASE_URL}/spot/trades`;
export const SPOT_TRADE_VARIATION = `${BASE_URL}/spot/variations`;

/** Demo Reload */
export const DEMO_RELOAD = `${BASE_URL}/demo/currency/reload`;

/** Affiliate */
export const AFFILIATE = `${BASE_URL}/affiliate`;
export const AFFILIATE_UPDATE_CLICK_COUNT = (referralCode: string) => `${AFFILIATE}/update-click-count?referral=${referralCode}`;
export const AFFILIATE_UPDATE_CLICK_COUNT_API = `/affiliate/update-click-count`;
export const AFFILIATE_REFERRAL = `${AFFILIATE}/referral`;

/** Deposit - UPI  */
export const DEPOSIT_UPI = `${BASE_URL}/deposit/upi`;

/** Trade Share  */
export const SCREENSHOT_CAPTURE = (id: number) => `${BASE_URL}/screenshot/capture/${id}`;

/** UPI Withdrawal  */
export const WITHDRAW_UPI = `${BASE_URL}/withdraw/upi`;
export const UPI_WITHDRAWAL_REQUEST = `${BASE_URL}/withdraw/upi`;
export const UPI_WITHDRAWAL_CHARGES = (amount: number) => `${BASE_URL}/upi/withdrawal/charges?requestedAmount=${amount}`;

/** User Deposit Bonus */
export const USER_DEPOSIT_BONUS = `${BASE_URL}/user-deposit-bonuses/enabled`;

/** Percentage Turnover Bonus */
export const APPLY_TURNOVER_BONUS = (code: string) => `${BASE_URL}/promo-code/apply/${code}`;
export const GET_TURNOVER_BONUS = `${BASE_URL}/promo-code/status`;

/** Radom */
export const RADOM_CREATE_SESSION = `${BASE_URL}/api/v1/checkout/create-session`;

/** Delete Account */
export const DELETE_ACCOUNT = `${BASE_URL}/user/delete`;

/** Trade Updates */
export const TRADE_UPDATES = (token: string) => `${BASE_URL}/public/subscribe?token=${token}`;

