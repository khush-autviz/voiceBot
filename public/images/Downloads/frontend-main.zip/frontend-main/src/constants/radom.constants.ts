import { RadomTokenConfig } from "src/types/app.types";

export const radomTokenConfig: RadomTokenConfig[] = [
	{
		"token": "AVAX",
		"name": "Avalanche",
		"logo": "https://cryptologos.cc/logos/avalanche-avax-logo.svg",
		"networks": [
			{
				"network": "Avalanche",
				"name": "Avalanche",
				"logo": "https://cryptologos.cc/logos/avalanche-avax-logo.svg"
			}
		]
	},
	{
		"token": "BAT",
		"name": "Basic Attention Token",
		"logo": "https://cryptologos.cc/logos/basic-attention-token-bat-logo.svg",
		"networks": [
			{
				"network": "Ethereum",
				"name": "Ethereum",
				"logo": "https://cryptologos.cc/logos/ethereum-eth-logo.svg"
			},
			{
				"network": "Solana",
				"name": "Solana",
				"logo": "https://cryptologos.cc/logos/solana-sol-logo.svg"
			},
			{
				"network": "BNB",
				"name": "BNB",
				"logo": "https://cryptologos.cc/logos/bnb-bnb-logo.svg"
			},
			{
				"network": "Polygon",
				"name": "Polygon",
				"logo": "https://cryptologos.cc/logos/polygon-matic-logo.svg"
			},
			{
				"network": "SepoliaTestnet",
				"name": "SepoliaTestnet",
				"logo": "https://cryptologos.cc/logos/ethereum-eth-logo.svg"
			},
		]
	},
	{
		"token": "BNB",
		"name": "BNB",
		"logo": "https://cryptologos.cc/logos/bnb-bnb-logo.svg",
		"networks": [
			{
				"network": "BNB",
				"name": "BNB",
				"logo": "https://cryptologos.cc/logos/bnb-bnb-logo.svg"
			}
		]
	},
	{
		"token": "BTC",
		"name": "Bitcoin",
		"logo": "https://cryptologos.cc/logos/bitcoin-btc-logo.svg",
		"networks": [
			{
				"network": "Bitcoin",
				"name": "Bitcoin",
				"logo": "https://cryptologos.cc/logos/bitcoin-btc-logo.svg"
			}
		]
	},
	{
		"token": "BUSD",
		"name": "Binance USD",
		"logo": "https://cryptologos.cc/logos/binance-usd-busd-logo.svg",
		"networks": [
			{
				"network": "BNB",
				"name": "BNB",
				"logo": "https://cryptologos.cc/logos/bnb-bnb-logo.svg"
			}
		]
	},
	{
		"token": "DOT",
		"name": "Polkadot",
		"logo": "https://cryptologos.cc/logos/polkadot-new-dot-logo.svg",
		"networks": [
			{
				"network": "Polkadot",
				"name": "Polkadot",
				"logo": "https://cryptologos.cc/logos/polkadot-new-dot-logo.svg"
			},
			{
				"network": "PolkadotAssetHub",
				"name": "PolkadotAssetHub",
				"logo": "https://cryptologos.cc/logos/polkadot-new-dot-logo.svg"
			}
		]
	},
	{
		"token": "ETH",
		"name": "Ethereum",
		"logo": "https://cryptologos.cc/logos/ethereum-eth-logo.svg",
		"networks": [
			{
				"network": "Ethereum",
				"name": "Ethereum",
				"logo": "https://cryptologos.cc/logos/ethereum-eth-logo.svg"
			},
			{
				"network": "Arbitrum",
				"name": "Arbitrum",
				"logo": "https://cryptologos.cc/logos/arbitrum-arb-logo.svg"
			},
			{
				"network": "Base",
				"name": "Base",
				"logo": "https://tokenlogo.xyz/assets/chain/base.svg"
			},
			{
				"network": "SepoliaTestnet",
				"name": "SepoliaTestnet",
				"logo": "https://cryptologos.cc/logos/ethereum-eth-logo.svg"
			},
		]
	},
	{
		"token": "MATIC",
		"name": "Polygon",
		"logo": "https://cryptologos.cc/logos/polygon-matic-logo.svg",
		"networks": [
			{
				"network": "Polygon",
				"name": "Polygon",
				"logo": "https://cryptologos.cc/logos/polygon-matic-logo.svg"
			}
		]
	},
	{
		"token": "SOL",
		"name": "Solana",
		"logo": "https://cryptologos.cc/logos/solana-sol-logo.svg",
		"networks": [
			{
				"network": "Solana",
				"name": "Solana",
				"logo": "https://cryptologos.cc/logos/solana-sol-logo.svg"
			}
		]
	},
	{
		"token": "TRX",
		"name": "Tron",
		"logo": "https://cryptologos.cc/logos/tron-trx-logo.svg",
		"networks": [
			{
				"network": "Tron",
				"name": "Tron",
				"logo": "https://cryptologos.cc/logos/tron-trx-logo.svg"
			}
		]
	},
	{
		"token": "USDC",
		"name": "USD Coin",
		"logo": "https://cryptologos.cc/logos/usd-coin-usdc-logo.svg",
		"networks": [
			{
				"network": "PolkadotAssetHub",
				"name": "PolkadotAssetHub",
				"logo": "https://cryptologos.cc/logos/polkadot-new-dot-logo.svg"
			},
			{
				"network": "Ethereum",
				"name": "Ethereum",
				"logo": "https://cryptologos.cc/logos/ethereum-eth-logo.svg"
			},
			{
				"network": "Solana",
				"name": "Solana",
				"logo": "https://cryptologos.cc/logos/solana-sol-logo.svg"
			},
			{
				"network": "BNB",
				"name": "BNB",
				"logo": "https://cryptologos.cc/logos/bnb-bnb-logo.svg"
			},
			{
				"network": "Polygon",
				"name": "Polygon",
				"logo": "https://cryptologos.cc/logos/polygon-matic-logo.svg"
			},
			{
				"network": "Base",
				"name": "Base",
				"logo": "https://tokenlogo.xyz/assets/chain/base.svg"
			},
			{
				"network": "Arbitrum",
				"name": "Arbitrum",
				"logo": "https://cryptologos.cc/logos/arbitrum-arb-logo.svg"
			},
			{
				"network": "SepoliaTestnet",
				"name": "SepoliaTestnet",
				"logo": "https://cryptologos.cc/logos/ethereum-eth-logo.svg"
			},
		]
	},
	{
		"token": "USDC.e",
		"name": "USD Coin Bridged",
		"logo": "https://cryptologos.cc/logos/usd-coin-usdc-logo.svg",
		"networks": [
			{
				"network": "Polygon",
				"name": "Polygon",
				"logo": "https://cryptologos.cc/logos/polygon-matic-logo.svg"
			}
		]
	},
	{
		"token": "USDT",
		"name": "Tether",
		"logo": "https://cryptologos.cc/logos/tether-usdt-logo.svg",
		"networks": [
			{
				"network": "PolkadotAssetHub",
				"name": "PolkadotAssetHub",
				"logo": "https://cryptologos.cc/logos/polkadot-new-dot-logo.svg"
			},
			{
				"network": "Ethereum",
				"name": "Ethereum",
				"logo": "https://cryptologos.cc/logos/ethereum-eth-logo.svg"
			},
			{
				"network": "Solana",
				"name": "Solana",
				"logo": "https://cryptologos.cc/logos/solana-sol-logo.svg"
			},
			{
				"network": "BNB",
				"name": "BNB",
				"logo": "https://cryptologos.cc/logos/bnb-bnb-logo.svg"
			},
			{
				"network": "Polygon",
				"name": "Polygon",
				"logo": "https://cryptologos.cc/logos/polygon-matic-logo.svg"
			},
			{
				"network": "Arbitrum",
				"name": "Arbitrum",
				"logo": "https://cryptologos.cc/logos/arbitrum-arb-logo.svg"
			},
			{
				"network": "Avalanche",
				"name": "Avalanche",
				"logo": "https://cryptologos.cc/logos/avalanche-avax-logo.svg"
			},
			{
				"network": "Tron",
				"name": "Tron",
				"logo": "https://cryptologos.cc/logos/tron-trx-logo.svg"
			},
			{
				"network": "SepoliaTestnet",
				"name": "SepoliaTestnet",
				"logo": "https://cryptologos.cc/logos/ethereum-eth-logo.svg"
			},
		]
	}
];
