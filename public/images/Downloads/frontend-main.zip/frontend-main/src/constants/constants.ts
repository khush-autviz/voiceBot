import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';
import { MatDialogConfig } from '@angular/material/dialog';
import * as moment from 'moment';
import { Subject } from 'rxjs';
import { APIResponse, Balance, KycData, MatDialogData, ReferralSocials, SolusMode, SpotTradeAsset, State, SupportedCoin } from 'src/types/app.types';

export const JWT: string = 'jwt';
export const JWT_CREATED_AT: string = 'jwtCreatedAt';
export const USER: string = 'user';
export const COIN: string = 'coin';
export const MODE: string = 'mode';
export const MYSQL_DATE_FORMAT: string = 'YYYY-MM-DD HH:mm:ss';
export const URL_REGEX: RegExp = /^[A-Za-z][A-Za-z\d.+-]*:\/*(?:\w+(?::\w+)?@)?[^\s/]+(?::\d+)?(?:\/[\w#!:.?+=&%@\-/]*)?$/;

export const SIGN_LOGIN_MESSAGE = 'Sign Login Message';
export const CREATE_ACCOUNT_MESSAGE = 'Sign Message to Continue';
export const GETTING_RECAPTCHA = 'Getting Recaptcha';
export const RETRIEVING_LOGIN_MESSAGE = 'Retrieving Login Message';
export const WAITING_FOR_WALLET_SIGNATURE = 'Waiting For Wallet Signature';
export const VERIFYING_SIGNATURE = 'Verifying Signature';
export const VERIFIED_LOGGING_IN = 'Verified, Logging In';
export const CASHBACKVALUE_ERROR_MSG = 'Insufficient Promo Cash Balance';
export const NEGATIVE_PROMO_CASH_ERROR_MSG = 'Please enter a valid Promo Cash Amount';

export const LAST_TRADE_MARKET = 'lastMarket';
export const LAST_TRADE_ASSET = 'lastAsset';
export const LAST_TRADE_ASSET_VARIATION = 'lastAssetVariation';

export const PAYPAL_REFERENCE_ID = 8888888888;
export const PAYPAL_MINIMUM_DEPOSIT_AMOUNT = 20;
export const UPI_QR_CODE_ID = 'UPI_QR_dbaskgq28737dw1LWIGr';
export const UPI_DEPOSIT_REFERENCE_ID = 77777;
export const UPI_WITHDRAWAL_REFERENCE_ID = 99999999;
export const RADOM_DEPOSIT_REFERENCE_ID = -2202;


export const ASSET_MAX_DECIMAL_PLACES = '0.0-8';

export const DISCORD_SUPPORT_CHANNEL_LINK = "https://discord.com/channels/1024263886083465297/1077321140374077490";


export const SOLUS_OTC_PREFIX = 'OTC';

export const REJECTED_EMAIL_DOMAINS_REGEX = /^[a-zA-Z0-9_.+-]+@(?:(?:[a-zA-Z0-9-]+\.)?[a-zA-Z]+\.)?(qq|yopmail)\.com$/;

export const DEFAULT_PAGE_SIZE = 100;

export const ASSET_HISTORY_MAX_LENGTH = 10;
export const ASSET_HISTORY_USDT = 'assetHistoryUSDT';
export const ASSET_HISTORY_DEMO = 'assetHistoryDEMO';

export const APP_WEB_SOCKET_RESPONSES = {
	CONNECTED: 'Connected to server for payout data!',
	SUBSCRIBED: 'Subscribed successfully'
}

export const SHARDEUM = {
	method: 'wallet_addEthereumChain',
	params: [
		{
			chainId: '0x1f91',
			rpcUrls: ['https://dapps.shardeum.org'],
			chainName: 'Shardeum Sphinx Dapp 1.X',
			nativeCurrency: {
				name: 'SHM',
				symbol: 'SHM',
				decimals: 18,
			},
			blockExplorerUrls: ['https://explorer-dapps.shardeum.org'],
		},
	],
};

export const POLYGON = {
	method: 'wallet_addEthereumChain',
	params: [
		{
			chainId: '0x89',
			rpcUrls: ['https://polygon-rpc.com/'],
			chainName: 'Polygon Mainnet',
			nativeCurrency: {
				name: 'MATIC',
				symbol: 'MATIC',
				decimals: 18,
			},
			blockExplorerUrls: ['https://polygonscan.com'],
		},
	],
};

export const DEFAULT_COIN: SupportedCoin = SupportedCoin.USDT;

export const INITIAL_STATE: State = {
	coin: DEFAULT_COIN,
	mode: SolusMode.PRICE_PREDICTION,
	jwt: null,
	user: null,
	balance: null,
	currencies: []
};

export const hasPassed = (date: string): boolean => {
	return moment().isAfter(moment(date));
};

export const getPrecision = (price: number = 11): string => {
	let precision = '0.2-2';
	if (price < 10) {
		precision = '0.0-4';
	}
	if (price < 1) {
		precision = '0.0-6';
	}
	return precision;
};

export const getMatDialogConfig = (
	data: MatDialogData
): MatDialogConfig<MatDialogData> => {
	return {
		width: '500px',
		// height: '220px',
		disableClose: true,
		autoFocus: false,
		data: data,
	};
};

export const errorConfig = (response: APIResponse<any>, fallbackTitle: string = "An Error Occurred"): MatDialogConfig<MatDialogData> => {
	const errors: string[] = response.body.toString().split(":");
	return getMatDialogConfig({
		success: false,
		title: errors.length > 0 ? errors[0].replace("Exception", " Error").trim() : fallbackTitle,
		message: errors.length > 0 ? errors[1].trim() : response.body.toString()
	});
};
export const recapthcaConfig = (): MatDialogConfig<MatDialogData> => {
	return getMatDialogConfig({
		success: false,
		title: 'Recaptcha Failed',
		message: 'Please use a trusted browser like Google Chrome',
	});
};

export const getBalanceOfCoin = (balances: Balance[] | null, coin: SupportedCoin): number => {
	if (balances === null) return 0;
	for (const balance of balances) {
		if (balance.symbol === SupportedCoin[coin]) {
			return balance.balance;
		}
	}
	return 0;
};

export const copyToClipboard = (text: string): void => {
	if (!navigator.clipboard) {
		fallbackCopyTextToClipboard(text);
	}
	navigator.clipboard.writeText(text).then(
		function () {
			return new Subject<boolean>();
		},
		function (err) {
			console.error('Async: Could not copy text: ', err);
		}
	);
};

export const shareReferralLink = (social: any, url: string, text: string) => {
	text = encodeURIComponent(text);
	url = encodeURIComponent(url);
	if (social.name === 'facebook') {
		return `${social.url}?u=${url}`;
	}
	if (social.name === 'whatsapp') {
		return `${social.url}?text=${text} %0A ${url}`;
	}
	if (social.name === 'twitter') {
		return `${social.url}?text=${text}&url=${url}\n&hashtags=solus,joinsolus`;
	}
	if (social.name === 'linkedin') {
		return `${social.url}?url=${url}`;
	}
	if (social.name === 'reddit') {
		return `${social.url}?url=${url}&title=${text}`;
	}
	if (social.name === 'telegram') {
		return `${social.url}?text=${text} ${url}&url=${url}`;
	}
	if (social.name === 'email') {
		return `${social.url}?subject=${'Join me on Solus'}&body=${text}%0A${url}`;
	}
	return '#';
};

const fallbackCopyTextToClipboard = (text: string) => {
	const textArea = document.createElement('textarea');
	textArea.value = text;

	// Avoid scrolling to bottom
	textArea.style.top = '0';
	textArea.style.left = '0';
	textArea.style.position = 'fixed';

	document.body.appendChild(textArea);
	textArea.focus();
	textArea.select();

	try {
		const successful = document.execCommand('copy');
		const msg = successful ? 'successful' : 'unsuccessful';
	} catch (err) {
		console.error('Fallback: Oops, unable to copy', err);
	}

	document.body.removeChild(textArea);
};

export const twitter: ReferralSocials = {
	name: 'twitter',
	icon: 'bi-twitter',
	url: 'https://twitter.com/intent/tweet',
};
export const facebook: ReferralSocials = {
	name: 'facebook',
	icon: 'bi-facebook',
	url: 'https://www.facebook.com/sharer/sharer.php',
};
export const whatsapp: ReferralSocials = {
	name: 'whatsapp',
	icon: 'bi-whatsapp',
	url: 'https://api.whatsapp.com/send',
};
export const reddit: ReferralSocials = {
	name: 'reddit',
	icon: 'bi-reddit',
	url: 'https://reddit.com/submit',
};
export const telegram: ReferralSocials = {
	name: 'telegram',
	icon: 'bi-telegram',
	url: 'https://t.me/share/url',
};

export const social: ReferralSocials[] = [
	facebook, // u=
	whatsapp, // text
	twitter, // url, text
	{
		name: 'linkedin',
		icon: 'bi-linkedin',
		url: 'https://www.linkedin.com/sharing/share-offsite/',
	}, //url
	reddit, // url, title
	telegram,
	{ name: 'email', icon: 'bi-envelope', url: 'mailto:?' },
	{ name: 'clipboard', icon: 'bi-clipboard', url: '' },
	{ name: '', icon: '', url: '' },
];

export const hexStringToBigInt = (hexString: string): number => {
	// Remove the "0x" prefix if present
	const cleanHexString = hexString.startsWith('0x') ? hexString.slice(2) : hexString;
	// Parse the hex string to a bigint
	return Number(cleanHexString);
}

const CLEAR: string = 'clear';
export const isKycComplete = (kycData: KycData | undefined = undefined): boolean => {
	if (kycData === undefined) return false;
	return kycData.outcome === CLEAR && kycData.documentCheckOutcome === CLEAR && kycData.signedUserAgreement;
}

export function ethereumAddressValidator(): ValidatorFn {
	return (control: AbstractControl): ValidationErrors | null => {
		if (!control.value) {
			// If the control is empty, consider it valid
			return null;
		}
		return /^0x[a-fA-F0-9]{40}$/.test(control.value) ? null : { invalidEthereumAddress: true };
	};
}

export function positiveNonZeroValidator(): ValidatorFn {
	return (control: AbstractControl): ValidationErrors | null => {
		const value = control.value;

		if (value === null || value === undefined || value <= 0) {
			return { positiveNonZero: true };
		}

		return null;
	};
}

export function upiIdValidator(): ValidatorFn {
	return (control: AbstractControl): ValidationErrors | null => {
		if (!control.value) {
			// If the control is empty, consider it valid
			return null;
		}
		return /^[a-zA-Z0-9.-_]{2,256}@[a-zA-Z]{2,64}$/.test(control.value) ? null : { pattern: true };
	};
}

export const confirmUpiIdValidator: ValidatorFn = (
	control: AbstractControl
): ValidationErrors | null => {
	return control.value.upiId === control.value.confirmUpiId
		? null
		: { upiNoMatch: true };
};

export const assetsSortByName = (a: SpotTradeAsset, b: SpotTradeAsset) => {
	// Remove 'OTC' from the end if it exists
	const aBase = a.name.replace(/ OTC$/, '');
	const bBase = b.name.replace(/ OTC$/, '');

	// If the base names are the same but one is OTC, place the OTC version after
	if (aBase === bBase) {
		if (a.name.endsWith("OTC")) return -1;
		if (b.name.endsWith("OTC")) return 1;
	}

	// Otherwise, sort by base name
	return aBase.localeCompare(bBase);
}
