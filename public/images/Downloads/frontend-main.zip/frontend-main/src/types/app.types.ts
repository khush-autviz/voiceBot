import { Observable } from "rxjs";

export type Environment = {
	production: boolean;
	uat: boolean;
	dev: boolean;
	backend: string;
	frontend: string;
	name?: string;
	recaptcha: string;
	discord: string;
	metamaskDeepLink: string;
	google: string;
	googleRedirectUri: string;
	pricingEngineWebSocket: string;
	binanceWebSocket: string;
	appWebSocket: string;
	underMaintenance: boolean;
	polygonScanApiKey: string;
}

export type APIResponse<T> = {
	success: boolean;
	body: T;
}

export type Navigation = {
	label: string;
	icon: string;
	link: string;
}


export type State = {
	coin: SupportedCoin;
	mode: SolusMode;
	jwt: string | null;
	user: User | null;
	balance: Balance[] | null;
	currencies: SolusCurrency[];
}

export type PasswordLoginRequest = {
	email: string;
	password: string;
	recaptcha: string;
}

export type EmailSignUpRequest = {
	email: string;
	password: string;
	recaptcha: string;
	referralCode: string;
}

export type PartnerCampaignSignInDto = {
	partner: string;
	metadata: string;
	platform: string;
}

export type CreateAccountRequest = {
	emailAddress: string;
	otp: number;
	referralCode: string | null;
	recaptcha: string;
	partner: string;
	metadata: string;
	platform: string;
	clickId: string;
	siteId: string;
}

export type LoginWithGooglePayload = {
	code: string;
	recaptcha: string;
	redirectUri: string;
	referralCode: string;
	partner: string;
	metadata: string;
	platform: string;
	clickId: string;
	siteId: string;
}

export type SendOTPResponse = {
	otpSent: boolean;
	otpRequired: boolean;
}

export type User = {
	address: string;
	balance: number;
	chain: string;
	investments: number;
	returns: number;
	email?: string;
	profile?: Profile;
	referralCode: string;
	showPasswordPrompt: boolean;
	isDiscordLinked: boolean;
	legalRestriction: LegalRestriction;
	countryCode: string;
	affiliate: boolean;
}

export type Profile = {
	id?: number;
	firstName: string;
	lastName: string;
	name?: string;
	instagram?: string;
	youtube?: string;
	discord?: string;
	email?: string;
	avatar?: string;
	level?: string;
}

export type JwtResponse = {
	firstLogin?: boolean;
	showDiscordPrompt?: boolean;
	showPasswordPrompt?: boolean;
	showProfileDetailsPrompt?: boolean;
	token: string;
}

export type Balance = {
	name: string;
	symbol: string;
	balance: number;
	decimals: number;
	priority?: number;
}

export type Asset = {
	id: number;
	created: string;
	createdBy: string;
	updated: string;
	updatedBy: string;
	name: string;
	token: string;
	logo: string;
	deleted: boolean;
	assetType: "CRYPTO" | "STOCKS";
	coinGeckoId: string;
	marketCount: number;
	tradingViewSymbol: string;
	binanceSymbol: string;
	futuresEnabled: boolean;
	innerDelta: number;
	outerDelta: number;
	baseCost: number;
	decimals: number;
	minimumInvestment: number;
}

export interface SpotTradeAsset extends Asset {
	variations: SpotTradeVariation[];
	selectedVariation: SpotTradeVariation;
	profits?: { [key: string]: number }
}

export type MatDialogData = {
	success: boolean;
	title: string;
	message: string;
	redirect?: string;
	closeButtonLabel?: string;
	firstButtonLabel?: string;
	skipLog?: boolean;
	mergeQueryParams?: boolean
}

export type JustPassword = {
	password: string;
	recaptcha: string;
}

export type ReferralRecordDto = {
	joinedAddress: string;
	display: string;
	name: string;
	createdAt: string;
	referralCommission: number;
	usdtTrades: number;
	usdtTradeVolume: number;
}

export type ReferralDto = {
	referralCommision: number;
	referralCount: number;
	referrals: ReferralRecordDto[];
}

export type ReferralRewardsDto = {
	referralCommission: number;
	referralReward: number;
	mainnetReferralCommission: number;
	referralUsdtTradeVolume: number;
}

export type ReferralSocials = {
	name: string;
	icon: string;
	url: string;
}

export type BinanceStreamMessage = {
	stream: string;
	data: BinanceMiniTicker;
}

export type BinanceMiniTicker = {
	e: string;
	E: number;
	s: string;
	c: number;
	o: number;
	h: number;
	l: number;
	v: number;
	q: number;
}

export type KycPersonalDetails = {
	countryCode: string;
	dateOfBirth: string;
	emailId: string;
	firstName: string;
	gender: string;
	lastName: string;
	phoneNumber: string;
}

export type KycAddressDetails = {
	addressLine: string;
	country: string;
	countryCode: string;
	state: string;
	stateCode: string;
	city: string;
	postalCode: string;
}

export type KnowYourCustomer = {

	walletAddress: string;
	createdAt: string;
	updatedAt: string;

	phoneNumberPrefix: string;
	dateOfBirth: string;
	emailId: string;
	firstName: string;
	gender: string;
	lastName: string;
	phoneNumber: string;

	addressLine: string;
	country: string;
	state: string;
	city: string;
	postalCode: string;

}

export type KycData = {
	id: any;
	walletAddress: string;
	version: number;
	name: string;
	email: string;
	identityDocument: string;
	status: string;
	outcome: string;
	issuingCountry: string;
	checkId: string;
	clientId: string;
	addressId: string;
	documentId: string;
	livePhotoId: string;
	created: string;
	updated: string;
	sdkToken: string;

	documentCheckId: string;
	documentCheckStatus: string;
	documentCheckOutcome: string;

	signedUserAgreement: boolean;
	signedAt: string;
	signingWithIp: string;
}


export type CountryCode = {
	code: string;
	name: string;
}

export type DocumentUploadRequest = {
	clientId?: string;
	data: string;
	side?: "front" | "back";
	fileName?: string;
}

export type ForgotPasswordRequestOtp = {
	email: string;
	recaptcha: string;
}

export type ForgotPasswordVerifyOtp = {
	email: string;
	otp: string;
	password: string;
	recaptcha: string;
}

export type ComplyCubeDocumentCapture = {
	documentCapture: {
		documentId: string;
		documentType: string;
	}
	faceCapture: {
		livePhotoId: string;
	}
}

export type SolusCurrency = {
	id: number;
	name: string;
	symbol: string;
	chain: string;
	decimals: number;
	contractAddress: string;
}


export type IDDocument = {
	selectedId: string;
}


export type TokenWithdrawalDto = {
	amount: number;
}

export enum LegalRestriction {
	UNKNOWN, UNRESTRICTED, RESTRICTED_US
}

// DO NOT CHANGE THE SEQUENCE OF COINS HERE
// THEY ASSOCIATE WITH BACKEND ID OF THESE COINS
export enum SupportedCoin {
	_, SUS, MAINNET_TOKEN, USDT, DEMO_USDT, BONUS_USDT
}

export enum SolusMode {
	PRICE_PREDICTION = 'PRICE_PREDICTION',
	FUTURES = 'FUTURES'
}

export type Page<T> = {
	content: T[];
	page: {
		totalPages: number;
		totalElements: number;
		last: boolean;
		size: number;
		number: number;
	};
	totalPages: number;
	totalElements: number;
	last: boolean;
	size: number;
	number: number;
	numberOfElements: number;
	first: boolean;
	empty: boolean;
}

export type TokenTransaction = {
	blockNumber: number;
	nonce: number;
	blockHash: string;
	contractAddress: string;
	tokenName: string;
	tokenSymbol: string;
	tokenDecimal: number;
	transactionIndex: number;
	gas: number;
	gasPrice: number;
	gasUsed: number;
	cumulativeGasUsed: number;
	input: any;
	confirmations: number;
	timeStamp: number;
	hash: string;
	from: string;
	to: string;
	value: number;
	depositIndicator?: boolean;
}

export type LoaderData = {
	title: string;
	message: string;
}

export type TradeStats = {
	id: number;
	count: number;
	invested: number;
	returns: number;
}

export enum TradeStatus {
	All = 'all',
	Open = 'open',
	Closed = 'closed',
	Resolved = 'resolved'
}

export enum TransactionType {
	All = 'all',
	Deposits = 'deposits',
	Withdrawals = 'withdrawals',
	MainnetToken = 'mainnet_token'
}

export enum TransactionDirection {
	SEND = 'SEND',
	RECEIVE = 'RECEIVE',
}

export type Transaction = {
	amount: number;
	cause: string;
	cpty: string;
	currencyId: number;
	fees: number;
	id: number;
	owner: string;
	publishedAt: string;
	referenceId: number;
	synced: boolean;
	syncing: boolean;
	txnDate: string;
	txnId: string;
}

export type MainnetTokenTransaction = Transaction;

export enum TransactionFilter {
	Wallet = 'WALLET',
	MainnetToken = 'MAINNET_TOKEN',
}

export type TokenWithdrawResponse = {
	address: string;
	amount: number;
	currencyId: number;
	message: string;
	status: string;
	transactionHash: string;
	txnTimestamp: string;
}

export enum CashOutStatus {
	QUEUED = "QUEUED",
	PROCESSING = "PROCESSING",
	FAILED = "FAILED",
	COMPLETED = "COMPLETED",
	DISMISSED = "DISMISSED",
	REJECTED = "REJECTED",
}

export enum TransactionActivity {
	CR = 'CR',
	DR = 'DR'
}

export type PassbookTransaction = {
	timeStamp: string;
	activity: TransactionActivity;
	amount: number;
	openingBalance: number;
	closingBalance: number;
}

export enum PortfolioFilter {
	Overall = 'overall',
	ThisMonth = 'thisMonth',
	Today = 'today'
}

export type AppConfig = {
	key: string;
	value: string;
}

export enum AppConfigEnum {
	MINIMUM_WITHDRAWAL_PER_CASH_OUT = 'MINIMUM_WITHDRAWAL_PER_CASH_OUT',
	PRICE_PREDICTION_WIN_MULTIPLIER = 'PRICE_PREDICTION_WIN_MULTIPLIER',
	VINU_PER_TXN_FEES = 'VINU_PER_TXN_FEES',
	DEMO_USDT_RELOAD_AMOUNT = 'DEMO_USDT_RELOAD_AMOUNT',
	EXCHANGE_RATE = 'EXCHANGE_RATE'
}

export type OverAllPortfolio = {
	amountDeposited: number;
	amountWithdrawn: number;
	withdrawableBalance: number;
}

export type ReferralTransaction = {
	date: string;
	investedBy: string;
	amount: number;
}

export type QrCodeDialogData = {
	title: string;
	qrData: string;
}

export type PolygonScanTransaction = {
	blockNumber: string,
	timeStamp: string,
	hash: string,
	from: string,
	to: string,
	value: string,
	contractAddress: string,
	input: string,
	type: string,
	gas: string,
	gasUsed: string,
	traceId: string,
	isError: string,
	errCode: string,
}

export type PolygonScanResponse = {
	status: string,
	message: string,
	result: PolygonScanTransaction[]
}

export type TransactionHashDto = {
	transactionHash: string
}

export type PaymentOrder = {
	status: string,
	payId: string,
	redirectUrl: string,
}

export type CompletedOrder = {
	isSuccess: boolean,
	token: string,
}

export enum PaymentStatus {
	Processing = 'processing',
	Success = 'success',
	Failed = 'failed',
	Cancelled = 'cancelled'
}

export type SocialButton = {
	title: string,
	logo: string,
	link: string,
	theme: string,
	color: string,
}

export enum TradePosition {
	Long = 'LONG',
	Short = 'SHORT'
}

export enum SpotTradeStatus {
	Open = 'OPEN',
	Cancelled = 'CANCELLED',
	Profit = 'PROFIT',
	Loss = 'LOSS',
	Refunded = 'REFUNDED',
	Closed = 'CLOSED'
}

export type SpotTradeRequest = {
	variationId: number,
	entryAt: Date,
	recaptcha: string,
	amount: number,
	entryPrice: number,
	tradePosition: TradePosition,
	authHeader?: string
}

export type CancelSpotTradeRequest = {
	spotTradeId: number,
	exitAt: Date,
	recaptcha: string,
	exitPrice: number,
}

export type SpotTradeQueryParams = {
	assetId?: number,
	currencyId?: number,
	tradeStatus?: SpotTradeStatus,
	page?: number,
	size?: number,
}

export type SpotTrade = {
	id: number;
	updatedAt: Date;
	enteredAt: Date;
	exitedAt: Date;
	assetId: number;
	currencyId: number;
	walletAddress: string;
	tradePosition: TradePosition;
	tradeStatus: SpotTradeStatus;
	tradeDuration: number;
	entryPrice: number;
	exitPrice: number;
	quantity: number;
	investedAmount: number;
	returnedAmount: number;
	roi: number;
	pnl: number;
	exitPremiumCharges: number;
	takerFee: number;
	requestedEnteredAt: Date,
	expiresAt: Date,
	requestedExitedAt: Date,
	requestedEntryPrice: number,
	requestedExitPrice: number,
	netAmount: number,
	makerFee: number,
	transactionFee: number

	isConfirmDelete?: boolean;
	isCancelling?: boolean;

	expectedProfit?: number;
	expectedLoss?: number;
	expectedPnL?: number;
	pnlAfterSale?: number;

	isResolved?: boolean;

	variationId: number;
	winMultiplier: number;
}


export type SpotTradeVariation = {
	id: number;
	assetId: number;
	currencyId: number;
	duration: number;
	isListed: boolean;
	isActive: boolean;
	createdAt: Date;
	updatedAt?: Date;
	label?: string;
	spotTradeSlippage: number;
	winMultiplier: number;
	loseInsurance: number;
	minExitCharges: number;
	maxExitCharges: number;
	exitPremiumCharges: number;
	makerFeeMultiplier: number;
	takerFeeMultiplier: number;
	transactionFeeMultiplier: number;
	minInvestmentAmount: number;
	maxInvestmentAmount: number;
}

export type SpotTradePortfolioView = {
	tradeStatus: SpotTradeStatus;
	tradeCount: number;
	investedAmount: number;
	returnedAmount: number;
	pnl: number;
	roi: number;
}

export type SpotTradeAssetView = {
	tradeStatus: SpotTradeStatus;
	tradeCount: number;
	assetId: number;
	pnl: number;
	roi: number;
	investedAmount: number;
	returnedAmount: number;
	name: string;
	logo: string;
	token: string;
}

export type PortfolioPieChartData = {
	label: string;
	invested: string;
	investedPercentage: string;
	returns: string;
	count: number;
	id: number;
}

export enum UserRole {
	GENERIC_USER = 'GENERIC_USER',
	AFFILIATE_USER = 'AFFILIATE_USER',
	ADMIN = 'ADMIN',
}

export enum UPIPaymentStatus {
	INITIATED = 'INITIATED',
	COMPLETED = 'COMPLETED',
	DECLINED = 'DECLINED'
}

export type UPITransaction = {
	id: number,
	createdAt: Date,
	modifiedAt: Date,
	address: string,
	upiReferenceId: string,
	amountInINR: number,
	amountInUSD: number,
	exchangeRate: number,
	convenienceFee: number,
	approvedAt: Date,
	status: UPIPaymentStatus,
	qrCodeId: string,
}

export type UPIRequestDTO = {
	upiReferenceId: string,
	qrCodeId: string,
	amountInINR: number,
}

export type SolusStreamMessage = {
	e: string,
	E: number,
	s: string,
	k: {
		t: number,
		T: number,
		s: string,
		i: string,
		f: number,
		L: number,
		o: number,
		c: number,
		h: number,
		l: number,
		v: number,
		n: number,
		x: boolean,
		q: number,
		V: number,
		Q: number,
		B: number
	}
}

export type UPIWithdrawRequest = {
	amountInUSDT: number;
	upiId: string;
}

export type UPIWithdrawal = {
	id: number,
	createdAt: Date,
	modifiedAt: Date,
	address: string,
	upiReferenceId: string,
	amountInINR: number,
	amountInUSD: number,
	exchangeRate: number,
	convenienceFee: number,
	approvedAt: Date,
	status: UPIPaymentStatus, upiId: string,
	referenceNumber: string,
	description: string,
}

export type DepositMethods = {
	label: string,
	icon: string,
	click?: () => void
}

export type UserDepositBonus = {
	id?: number;
	minDeposit: number;
	bonusPercentage: number;
	maxUsageInTrade: number;
	isApplyForFTD: boolean;
	voucherCode?: string;
	isEnabled: boolean;
}

export type UserAffiliateReferralDTO = {
	eligible: boolean,
	isFirstTimeDeposit: boolean,
	bonusPercentage: number,
	minDepositAmount: number,
}

export enum WebSocketResponseType {
	CONNECTED = "CONNECTED",
	SUBSCRIBE = "SUBSCRIBE",
	UNSUBSCRIBE = "UNSUBSCRIBE",
	SPOT_TRADE_VARIATIONS = "SPOT_TRADE_VARIATIONS",
	SPOT_TRADE_PLACE = "SPOT_TRADE_PLACE",
	UNKNOWN = "UNKNOWN"
}

export type WebSocketResponse<T> = {
	type: WebSocketResponseType,
	data: T
}

export type ResponseEntity<T> = {
	headers: any;
	body: APIResponse<T>;
	statusCode: number;
}

export type PromocodeDialogData = {
	title: string;
	message: string;
	confirmButtonText: string;
	cancelButtonText: string;
	redirectUrl?: string;
	mergeQueryParams?: boolean;
	customStyles?: { [key: string]: string };
	additionalActions?: { text: string, action: () => void }[];
	skipLog?: boolean;
	success: boolean;
	url?: string;
}

export type PromoCodeAlertConfig = {
	title: string,
	description: string,
	subtitle: string,
	listItems: string[],
	buttonText: string,
};

export type PromoCodeHistoryDialogConfig = {
	displayedColumns: TableColumnConfig[],
	iconConfig: IconConfig,
	title: string,
	getHistory: Observable<APIResponse<any>>,
};

export type PromoCodePromptConfig = {
	title: string,
	tradeIdInput: boolean,
	apply?: (code: string) => Observable<APIResponse<any>>
};

export type IconConfig = {
	icon: string,
	class: string
}

export type OffersCardConfig = {
	iconConfig: IconConfig,
	title: string,
	supportIcon: string,
	comingSoonIcon: string,
	comingSoonText: string,
	showComingSoon: boolean,
	historyIcon: string,
	historyText: string,
	showHistory: boolean,
	promoCodeButtonText: string,
	showCodeInput: boolean,
	historyDisplayedColumns: any,
	getHistory: Observable<APIResponse<any>>,
	promoCodeAlert: () => void,
	promoCodeHistory: () => void,
	promoCodePrompt: () => void,
};

export type TurnoverBonus = {
	id?: number;
	promoCode: string;
	startDate: string;
	endDate: string;
	duration: number;
	turnoverMultiplier: number;
}

export type TableColumnConfig = {
	name: string,
	label: string,
	valueKey: string,
	isCurrency?: boolean,
	currency?: SupportedCoin,
	isPercentage?: boolean,
	activeClass?: string,
	activeField?: string
}

export type PromoStatusDTO = {
	promoCode: string;
	currentTurnOver: number;
	bonusToBeConverted: number;
	status: string;
}

export type RadomSessionResponse = {
	checkoutSessionId: string,
	checkoutSessionUrl: string
}

export type PortfolioCombinedRequest = {
	currencySymbol: string;
    start: string;
    end: string;
    solusMode: string;
}

export type PortfolioCombinedResponse = {
	balances: Balance[];
	assetPortfolio: SpotTradeAssetView[];
	overAllPortfolio: OverAllPortfolio;
	spotTradePortfolio: SpotTradePortfolioView[];
}

export enum SpotTradeEventType {
	ResolvedTrade = "RESOLVED_TRADE",
	RefundedTrade = "REFUNDED_TRADE"
}

export type RadomTokenConfig = {
	token: string;
	name: string;
	logo: string;
	networks: RadomNetworkConfig[];
}

export type RadomNetworkConfig = {
	network: string;
	name: string;
	logo: string;
}
