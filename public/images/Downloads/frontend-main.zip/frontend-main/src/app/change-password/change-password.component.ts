import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { ReCaptchaV3Service } from 'ng-recaptcha';
import { Subscription } from 'rxjs';
import { DialogComponent } from 'src/components/dialog/dialog.component';
import { getMatDialogConfig } from 'src/constants/constants';
import { MARKETS } from 'src/constants/ui.routes';
import { APIService } from 'src/service/api.service';
import { StateService } from 'src/service/state.service';
import { State } from 'src/types/app.types';
import * as zxcvbn from 'zxcvbn';
import { ZXCVBNResult } from 'zxcvbn';

const materialModules = [MatDialogModule, MatFormFieldModule, MatIconModule, MatInputModule, MatButtonModule];

@Component({
	selector: 'app-change-password',
	standalone: true,
	imports: [CommonModule, ReactiveFormsModule, ...materialModules,],
	templateUrl: './change-password.component.html',
	styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit, OnDestroy {

	state: State;
	stateSub!: Subscription;
	formChangesSub!: Subscription;
	passwordStrength: ZXCVBNResult | undefined;
	passwordsMatch: boolean | undefined = undefined;

	passwordResetForm: FormGroup = new FormGroup({
		wallet: new FormControl<string>('', [Validators.required]),
		password: new FormControl<string>('', [Validators.required]),
		confirmPassword: new FormControl<string>('', [Validators.required])
	});

	constructor(private api: APIService, private matDialog: MatDialog, private recaptcha: ReCaptchaV3Service, private stateService: StateService) {
		this.state = this.stateService.getState();
		this.passwordResetForm.patchValue({
			wallet: this.state.user?.address
		});
	}

	ngOnInit(): void {
		this.stateSub = this.stateService.state$.subscribe({
			next: (state: State) => {
				this.state = state;
			}
		});
		this.formChangesSub = this.passwordResetForm.valueChanges.subscribe({
			next: (value: any) => {
				this.passwordStrength = value.password == '' ? undefined : zxcvbn(value.password);
				this.passwordsMatch = value.confirmPassword == '' ? undefined : value.password == value.confirmPassword;
			}
		});
	}

	ngOnDestroy(): void {
		if (this.formChangesSub) {
			this.formChangesSub.unsubscribe();
		}
		if (this.stateSub) {
			this.stateSub.unsubscribe();
		}
	}


	setPassword() {
		if (this.passwordResetForm.value['password'] == '') {
			this.openErrorDialog('Can not set empty password');
		}
		if (this.passwordStrength) {
			if (this.passwordStrength.score < 2) {
				this.openErrorDialog('Set a stronger password');
			}
			else {
				if (!this.passwordsMatch) {
					this.openErrorDialog('Passwords don\'t match')
				}
				else {
					this.recaptcha.execute('change_password').subscribe({
						next: (token: string) => {
							this.api.setPassword({ password: this.passwordResetForm.value['confirmPassword'], recaptcha: token }).subscribe({
								next: (response) => {
									if (response.success) {
										this.stateService.fetchUser();
										this.matDialog.open(DialogComponent, getMatDialogConfig({
											success: true,
											title: 'Password Changed',
											message: 'Password has been changed successfully',
											redirect: MARKETS
										}));
									}
								}
							})
						}
					});
				}
			}

		}

	}

	openErrorDialog(message: string) {
		this.matDialog.open(DialogComponent, getMatDialogConfig({
			success: false,
			title: 'Password Error',
			message: message
		}));
	}

}
