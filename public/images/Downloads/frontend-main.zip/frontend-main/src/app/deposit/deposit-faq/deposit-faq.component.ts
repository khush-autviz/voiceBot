import { CommonModule } from '@angular/common';
import { Component, ViewEncapsulation } from '@angular/core';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatIconModule } from '@angular/material/icon';
import { PAYPAL_MINIMUM_DEPOSIT_AMOUNT } from 'src/constants/constants';

@Component({
  selector: 'app-deposit-faq',
  standalone: true,
  imports: [MatExpansionModule, CommonModule, MatIconModule],
  templateUrl: './deposit-faq.component.html',
  styleUrl: './deposit-faq.component.scss',
  encapsulation: ViewEncapsulation.None
})
export class DepositFaqComponent {
	paypalMinAmount: number = PAYPAL_MINIMUM_DEPOSIT_AMOUNT;
}
