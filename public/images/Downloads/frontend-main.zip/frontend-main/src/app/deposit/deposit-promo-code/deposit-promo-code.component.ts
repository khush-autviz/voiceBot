import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, EventEmitter, Input, OnInit, Output, ViewEncapsulation } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { CoinDecimalPipe } from 'src/pipes/coin-decimal.pipe';
import { CurrencySymbolPipe } from 'src/pipes/currency-symbol.pipe';
import { APIService } from 'src/service/api.service';
import { CashInService } from 'src/service/cash-in.service';
import { StateService } from 'src/service/state.service';
import { APIResponse, AppConfig, AppConfigEnum, UserAffiliateReferralDTO, UserDepositBonus } from 'src/types/app.types';

const materialModules = [MatCardModule, MatInputModule, MatRadioModule, MatButtonModule, MatIconModule];
const pipes = [CoinDecimalPipe, CurrencySymbolPipe];

@Component({
	selector: 'app-deposit-promo-code',
	standalone: true,
	imports: [CommonModule, FormsModule, ...materialModules, ...pipes],
	templateUrl: './deposit-promo-code.component.html',
	styleUrl: './deposit-promo-code.component.scss',
	encapsulation: ViewEncapsulation.None
})
export class DepositPromoCodeComponent implements OnInit {
	@Input() isINR: boolean = false;
	@Output() applyBonus = new EventEmitter();

	bonuses: UserDepositBonus[] = [];
	selectedBonus: number | null | undefined = null;
	voucherCode: string = '';
	exchangeRate: number = 0.01111;
	applyClicked: boolean = false;
	error: string = '';
	affiliateBonusDto: UserAffiliateReferralDTO | undefined = undefined;

	constructor(private api: APIService, private stateService: StateService, private cashInService: CashInService) {
		this.getExchangeRate();
	}

	ngOnInit(): void {
		this.getBonuses();
		this.getAffiliateBonusData();
	}

	getBonuses() {
		this.api.getUserDepositBonuses().subscribe({
			next: (res) => {
				if (res.success) {
					this.bonuses = res.body.sort((a, b) => {
						// First, check if isApplyForFTD is different, and put true values first
						if (a.isApplyForFTD !== b.isApplyForFTD) {
							return a.isApplyForFTD ? -1 : 1;
						}
						// If isApplyForFTD is the same, sort by bonusPercentage in descending order
						return b.bonusPercentage - a.bonusPercentage;
					});

					this.cashInService.setBonuses(this.bonuses);
				} else {
					this.bonuses = [];
				}
			}, error: () => {
				this.bonuses = []
			}
		});
	}

	getExchangeRate() {
		this.api.getSettings().subscribe({
			next: (res: APIResponse<AppConfig[]>) => {
				if (res.success) {
					this.stateService.setConfig(res.body);

					const configAmount = this.stateService.getConfig(AppConfigEnum.EXCHANGE_RATE);
					if (configAmount) {
						this.exchangeRate = Number(configAmount);
					} else {
						this.exchangeRate = 0.01111;
					}
				}
			},
			error: () => {
				this.exchangeRate = 0.01111;
			}
		});
	}

	bonusSelected(bonus: UserDepositBonus) {
		this.applyClicked = false;
		this.selectedBonus = bonus.id;
		this.voucherCode = bonus.voucherCode || '';
	}

	applyVoucher() {
		if (this.bonuses.filter(b => b.voucherCode === this.voucherCode).length > 0) {
			this.applyClicked = true;
			this.error = '';
			this.applyBonus.emit(this.voucherCode);
		} else {
			this.applyClicked = false;
			this.error = 'Please enter a valid voucher code.';
		}
	}

	getAffiliateBonusData() {
		this.api.getAffiliateBonusData().subscribe({
			next: (res) => {
				if (res.success) {
					this.affiliateBonusDto = res.body;
				} else {
					this.affiliateBonusDto = undefined;
				}
			},
			error: (err: HttpErrorResponse) => {
				console.error(err.error);
				this.affiliateBonusDto = undefined;
			}
		});
	}

	validateAffiliateBonus() {
		if (this.affiliateBonusDto) {
			const { eligible, isFirstTimeDeposit, bonusPercentage, minDepositAmount } = this.affiliateBonusDto;
			return eligible && isFirstTimeDeposit && bonusPercentage > 0 && minDepositAmount > 0;
		}

		return false;
	}
}
