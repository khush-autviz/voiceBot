import { MediaMatcher } from '@angular/cdk/layout';
import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { DialogComponent } from 'src/components/dialog/dialog.component';
import { PAYPAL_MINIMUM_DEPOSIT_AMOUNT, getMatDialogConfig } from 'src/constants/constants';
import { DEPOSIT } from 'src/constants/ui.routes';
import { CoinDecimalPipe } from 'src/pipes/coin-decimal.pipe';
import { CurrencySymbolPipe } from 'src/pipes/currency-symbol.pipe';
import { APIService } from 'src/service/api.service';
import { CashInService } from 'src/service/cash-in.service';
import { StateService } from 'src/service/state.service';
import { DepositPromoCodeComponent } from "../../deposit-promo-code/deposit-promo-code.component";
import { DepositFaqComponent } from "../../deposit-faq/deposit-faq.component";
import { BalanceCardComponent } from "../../balance-card/balance-card.component";
import { HttpErrorResponse } from '@angular/common/http';
import { UserDepositBonus } from 'src/types/app.types';


const materialModules = [MatCardModule, MatButtonModule, MatIconModule, MatDividerModule, MatDialogModule, MatInputModule, MatFormFieldModule, MatProgressSpinnerModule,];
const pipes = [CoinDecimalPipe, CurrencySymbolPipe];

@Component({
	selector: 'app-paypal-deposit',
	standalone: true,
	imports: [CommonModule, ...materialModules, ...pipes, ReactiveFormsModule, DepositPromoCodeComponent, DepositFaqComponent, BalanceCardComponent],
	templateUrl: './paypal-deposit.component.html',
	styleUrl: './paypal-deposit.component.scss'
})
export class PaypalDepositComponent implements OnInit {
	subscriptions: Subscription[] = [];
	paymentLoading: boolean = false;
	paypalMinAmount: number = PAYPAL_MINIMUM_DEPOSIT_AMOUNT;
	paypalAmountControl = new FormControl(PAYPAL_MINIMUM_DEPOSIT_AMOUNT, [Validators.min(PAYPAL_MINIMUM_DEPOSIT_AMOUNT)]);
	transactionHashControl = new FormControl('', [Validators.required]);
	paypalAmountError = '';
	voucherCode: string = '';
	bonuses: UserDepositBonus[] = [];
	bonusMinAmount: number = 0;

	constructor(private api: APIService, private matDialog: MatDialog, private cashInService: CashInService, private coinDecimalPipe: CoinDecimalPipe, private router: Router, private mediaMatcher: MediaMatcher, private stateService: StateService) {
		const sub = cashInService.bonuses$.subscribe((bonuses) => {
			this.bonuses = bonuses;
		});
		this.subscriptions.push(sub);
	}


	get paypalAmount() {
		return this.paypalAmountControl.value || 0;
	}

	ngOnInit(): void {
		const sub = this.paypalAmountControl.valueChanges.subscribe((val) => {
			if (val !== null) {
				if (val < PAYPAL_MINIMUM_DEPOSIT_AMOUNT) {
					this.paypalAmountError = `Please enter an amount greater than $${PAYPAL_MINIMUM_DEPOSIT_AMOUNT}`;
				} else {
					this.paypalAmountError = '';
				}
			}
		});
		this.subscriptions.push(sub);

	}

	depositWithPayPal() {
		this.paymentLoading = true;
		this.api.initPayPalPayment('USD', this.paypalAmount < this.paypalMinAmount ? 10 : this.paypalAmount, this.voucherCode).subscribe({
			next: (res) => {
				if (res.success) {
					if (res.body.status !== 'error' && res.body.redirectUrl) {
						window.open(res.body.redirectUrl, "_self");
					} else {
						this.matDialog.open(DialogComponent, getMatDialogConfig({
							success: false,
							title: 'Payment Failed',
							message: 'Sorry, we are not able to initiate the payment at the moment. Please try again later.',
						}));
					}
				}

				this.paymentLoading = false;
			},
			error: (err: HttpErrorResponse) => {
				this.paymentLoading = false;
				console.error(err);
				this.matDialog.open(DialogComponent, getMatDialogConfig({
					success: false,
					message: err.message,
					title: 'Payment Failed'
				}));
			}
		})
	}

	goToDeposit() {
		this.router.navigate([DEPOSIT]);
	}

	applyBonus(voucherCode: string) {
		this.voucherCode = voucherCode;

		const bonus = this.bonuses.find(b => b.voucherCode === voucherCode);

		if (bonus) {
			this.bonusMinAmount = bonus.minDeposit;
		}
	}

	getBonusMinAmount() {
		return this.coinDecimalPipe.transform(this.bonusMinAmount);
	}
}
