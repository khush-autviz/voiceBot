import { CommonModule } from '@angular/common';
import { Component, OnDestroy } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDialog, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { DialogComponent } from 'src/components/dialog/dialog.component';
import { QrCodeDialogComponent } from 'src/components/qr-code-dialog/qr-code-dialog.component';
import { copyToClipboard, getMatDialogConfig, PAYPAL_MINIMUM_DEPOSIT_AMOUNT } from 'src/constants/constants';
import { DEPOSIT } from 'src/constants/ui.routes';
import { CoinDecimalPipe } from 'src/pipes/coin-decimal.pipe';
import { CurrencySymbolPipe } from 'src/pipes/currency-symbol.pipe';
import { CashInService } from 'src/service/cash-in.service';
import { APIResponse, QrCodeDialogData, SupportedCoin, Transaction } from 'src/types/app.types';
import { DepositPromoCodeComponent } from "../../deposit-promo-code/deposit-promo-code.component";
import { DepositFaqComponent } from "../../deposit-faq/deposit-faq.component";
import { BalanceCardComponent } from "../../balance-card/balance-card.component";
import { FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { HttpErrorResponse } from '@angular/common/http';
import { APIService } from 'src/service/api.service';

const materialModules = [MatCardModule, MatButtonModule, MatIconModule, MatDividerModule, MatDialogModule, MatInputModule, MatFormFieldModule];
const pipes = [CoinDecimalPipe, CurrencySymbolPipe];

@Component({
	selector: 'app-polygon-deposit',
	standalone: true,
	imports: [CommonModule, ...materialModules, ...pipes, DepositPromoCodeComponent, DepositFaqComponent, BalanceCardComponent, ReactiveFormsModule],
	templateUrl: './polygon-deposit.component.html',
	styleUrl: './polygon-deposit.component.scss'
})
export class PolygonDepositComponent implements OnDestroy {
	depositAddress: string = '';
	copyButtonText: string = 'Copy';
	paypalMinAmount: number = PAYPAL_MINIMUM_DEPOSIT_AMOUNT;

	subscriptions: Subscription[] = [];

	qrDialogRef: MatDialogRef<QrCodeDialogComponent> | undefined;
	transaction: Transaction | undefined;
	voucherCode: string = '';

	transactionHashControl = new FormControl('', [Validators.required]);

	constructor(private matDialog: MatDialog, private router: Router, private cashInService: CashInService, private coinDecimalPipe: CoinDecimalPipe, private api: APIService) {
		const sub = this.cashInService.depositAddress$.subscribe({
			next: (depositAddress: string) => {
				this.depositAddress = depositAddress;

				if (depositAddress) {
					this.cashInService.checkDepositStatus(depositAddress);

					const sub = this.cashInService.transaction$.subscribe({
						next: (transaction: Transaction | undefined) => {
							if (transaction) {
								this.showDepositSuccess(transaction);
							}
						}
					});
					this.subscriptions.push(sub);
				}
			}
		});
		this.subscriptions.push(sub);
	}

	generateQrCode(event: Event) {
		event.stopPropagation();

		this.qrDialogRef = this.matDialog.open<QrCodeDialogComponent, QrCodeDialogData>(QrCodeDialogComponent, {
			data: {
				title: 'Send USDT (Polygon)',
				qrData: `ethereum:${this.depositAddress}`,
			},
			width: '300px'
		});
	}

	copy(): void {
		copyToClipboard(this.depositAddress);
		this.copyButtonText = 'Copied!';
		setTimeout(() => {
			this.copyButtonText = 'Copy';
		}, 5000);
	}

	showDepositSuccess(transaction: Transaction) {
		this.transaction = transaction;

		const amount = this.coinDecimalPipe.transform(this.transaction.amount, { decimalPlaces: 2, coinType: SupportedCoin.USDT });

		this.qrDialogRef?.close();

		this.matDialog.open(DialogComponent, getMatDialogConfig({
			success: true,
			title: 'Deposit Successful!',
			message: `You have successfully deposited $${amount}!`
		}));
	}

	goToDeposit() {
		this.router.navigate([DEPOSIT]);
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach(sub => sub.unsubscribe());
		this.cashInService.destroyDepositStatusCheck();
		this.cashInService.resetTransaction();
	}

	applyBonus(voucherCode: string) {
		// this.voucherCode = voucherCode;
		this.cashInService.voucherCode = voucherCode;
	}

	checkDepositStatus() {
		const hash = this.transactionHashControl.value;
		if (hash && hash.startsWith('0x')) {
			this.api.getDepositTokenFromHash({ transactionHash: hash }, this.voucherCode).subscribe({
				next: (res: APIResponse<Transaction>) => {
					if (res.success) {
						this.showDepositSuccess(res.body);
					} else {
						this.matDialog.open(DialogComponent, getMatDialogConfig({
							success: false,
							title: 'Deposit Failed!',
							message: res.body as unknown as string,
						}));
					}
				},
				error: (err: HttpErrorResponse) => {
					this.matDialog.open(DialogComponent, getMatDialogConfig({
						success: false,
						title: 'Could not check deposit status!',
						message: err.message,
					}));
				}
			});
		}
	}
}
