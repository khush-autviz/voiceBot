import { MediaMatcher } from '@angular/cdk/layout';
import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDialog, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { Router } from '@angular/router';
import { CdTimerModule } from 'angular-cd-timer';
import { QRCodeModule } from 'angularx-qrcode';
import * as moment from 'moment';
import { Subscription } from 'rxjs';
import { DialogComponent } from 'src/components/dialog/dialog.component';
import { DISCORD_SUPPORT_CHANNEL_LINK, PAYPAL_MINIMUM_DEPOSIT_AMOUNT, UPI_QR_CODE_ID, getMatDialogConfig } from 'src/constants/constants';
import { DEPOSIT } from 'src/constants/ui.routes';
import { CoinDecimalPipe } from 'src/pipes/coin-decimal.pipe';
import { CurrencySymbolPipe } from 'src/pipes/currency-symbol.pipe';
import { APIService } from 'src/service/api.service';
import { CashInService } from 'src/service/cash-in.service';
import { StateService } from 'src/service/state.service';
import { APIResponse, AppConfig, AppConfigEnum, UPIPaymentStatus, UPITransaction, UserDepositBonus } from 'src/types/app.types';
import { BalanceCardComponent } from "../../balance-card/balance-card.component";
import { DepositFaqComponent } from "../../deposit-faq/deposit-faq.component";
import { DepositPromoCodeComponent } from "../../deposit-promo-code/deposit-promo-code.component";

const materialModules = [MatCardModule, MatButtonModule, MatIconModule, MatDividerModule, MatDialogModule, MatInputModule, MatFormFieldModule, MatProgressSpinnerModule, MatExpansionModule];
const pipes = [CoinDecimalPipe, CurrencySymbolPipe];

@Component({
	selector: 'app-upi-deposit',
	standalone: true,
	imports: [CommonModule, ...materialModules, ...pipes, DepositPromoCodeComponent, DepositFaqComponent, ReactiveFormsModule, BalanceCardComponent, CdTimerModule, QRCodeModule],
	templateUrl: './upi-deposit.component.html',
	styleUrl: './upi-deposit.component.scss'
})
export class UpiDepositComponent implements OnInit {
	subscriptions: Subscription[] = [];

	upiLoading: boolean = false;
	upiTransactionsLoading = false;
	qrVisible = false;
	qrLoading = false;
	upiTransactions: UPITransaction[] = [];
	upiMinAmount: number = 900;
	upiTransactionIdControl = new FormControl('', [Validators.required, Validators.pattern(/^\d{12}$/)]);
	upiAmountControl = new FormControl(this.upiMinAmount, [Validators.min(this.upiMinAmount)]);
	upiAmountError = '';
	UPIPaymentStatus = UPIPaymentStatus;

	fileControl = new FormControl('');
	file: File | undefined;

	discordSupportLink = DISCORD_SUPPORT_CHANNEL_LINK;

	voucherCode: string = '';
	bonuses: UserDepositBonus[] = [];
	bonusMinAmount: number = 0;
	exchangeRate: number = 0;

	constructor(private api: APIService, private matDialog: MatDialog, private cashInService: CashInService, private coinDecimalPipe: CoinDecimalPipe, private router: Router, private mediaMatcher: MediaMatcher, private stateService: StateService) {

		const sub = cashInService.bonuses$.subscribe((bonuses) => {
			this.bonuses = bonuses;
		});
		this.subscriptions.push(sub);

		this.getExchangeRate();
	}

	ngOnInit(): void {
		const upiSub = this.upiAmountControl.valueChanges.subscribe((val) => {
			if (val !== null) {
				if (val < this.getMinDepositAmount()) {
					this.upiAmountError = `Please enter an amount greater than ₹${this.upiMinAmount}`;
				} else {
					this.upiAmountError = '';
				}
			}
		});
		this.subscriptions.push(upiSub);

		this.getUPITransactions();
	}

	depositViaUPI() {
		if (this.upiTransactionIdControl.valid) {
			this.upiLoading = true;

			const requestBody = new FormData();
			requestBody.append('upiReferenceId', this.upiTransactionIdControl.value || '');
			requestBody.append('qrCodeId', UPI_QR_CODE_ID);
			requestBody.append('amountRequestedInINR', (this.upiAmountControl.value || 0).toString());
			requestBody.append('voucherCode', this.voucherCode);

			if (this.file) {
				requestBody.append('file', this.file);
			}

			this.api.requestUPIDeposit(requestBody).subscribe({
				next: (res: APIResponse<string>) => {
					let dialogRef: MatDialogRef<DialogComponent> | undefined = undefined;
					if (res.success) {
						dialogRef = this.matDialog.open(DialogComponent, getMatDialogConfig({
							success: true,
							title: 'Deposit Initiated!',
							message: 'Deposit has been initiated successfully. Your wallet balance will be updated in few hours.'
						}));
					} else {
						dialogRef = this.matDialog.open(DialogComponent, getMatDialogConfig({
							success: false,
							title: 'Deposit Failed!',
							message: res.body
						}));
					}

					if (dialogRef) {
						const sub = dialogRef.afterClosed().subscribe({
							next: () => {
								this.hideQRCode();
							}
						});
						this.subscriptions.push(sub);
					} else {
						this.hideQRCode();
					}

					this.getUPITransactions();
					this.upiLoading = false;
				},
				error: () => {
					this.upiLoading = false;
					this.matDialog.open(DialogComponent, getMatDialogConfig({
						success: false,
						title: 'Deposit Failed!',
						message: 'Something went wrong! Please try again later...'
					}));
					this.hideQRCode();
				}
			});
		}
	}

	getUPITransactions(): void {
		this.upiTransactionsLoading = true;
		this.api.getUPITransactions().subscribe({
			next: (response) => {
				if (response.success) {
					this.upiTransactions = response.body.content.sort((a, b) => moment(b.createdAt).unix() - moment(a.createdAt).unix());
				}
				this.upiTransactionsLoading = false;
			},
			error: () => {
				this.upiTransactionsLoading = false;
			}
		});
	}

	showQRCode() {
		this.qrVisible = false;
		this.qrLoading = true;

		setTimeout(() => {
			this.qrVisible = true;
			this.qrLoading = false;
		}, 1000);
	}

	hideQRCode() {
		this.qrVisible = false;
		this.qrLoading = false;

		this.resetUpiForm();
	}

	getUpiDetails() {
		return `upi://pay?pa=6205072294@pthdfc&pn=SANGHITA%20DEY&am=${this.upiAmountControl.value}&cu=INR&tn=Deposit%20for%20Solus`;
	}

	private isValidFile(file: File): boolean {
		return file.type.includes('image') && file.size <= 1048576; // 1MB limit
	}

	onFileSelected(event: Event): void {
		const fileInput = event.target as HTMLInputElement;
		if (fileInput.files && fileInput.files.length > 0) {
			const file = fileInput.files[0];
			if (this.isValidFile(file)) {
				this.file = file;
				this.fileControl.setErrors(null);
			} else {
				this.fileControl.setErrors({ 'invalid': true });
			}
		}
	}

	removeSelectedFile() {
		this.file = undefined;
	}

	resetUpiForm() {
		this.fileControl.reset();
		this.removeSelectedFile();
		this.upiTransactionIdControl.reset();
	}

	goToDeposit() {
		this.router.navigate([DEPOSIT]);
	}

	applyBonus(voucherCode: string) {
		this.voucherCode = voucherCode;

		const bonus = this.bonuses.find(b => b.voucherCode === voucherCode);

		if (bonus) {
			this.bonusMinAmount = bonus.minDeposit;
		}
	}

	getExchangeRate() {
		this.api.getSettings().subscribe({
			next: (res: APIResponse<AppConfig[]>) => {
				if (res.success) {
					this.stateService.setConfig(res.body);

					const configAmount = this.stateService.getConfig(AppConfigEnum.EXCHANGE_RATE);
					if (configAmount) {
						this.exchangeRate = Number(configAmount);

						this.upiMinAmount = this.getMinDepositAmount();
						this.upiAmountControl.setValue(this.upiMinAmount);
						this.upiAmountControl.setValidators([Validators.min(this.upiMinAmount)]);
						this.upiAmountControl.updateValueAndValidity();

					} else {
						this.exchangeRate = 0.01111;
					}
				}
			},
			error: () => {
				this.exchangeRate = 0.01111;
			}
		});
	}

	getBonusMinAmount() {
		return this.coinDecimalPipe.transform(this.bonusMinAmount / this.exchangeRate);
	}

	getMinDepositAmount() {
		return Number((PAYPAL_MINIMUM_DEPOSIT_AMOUNT / this.exchangeRate).toFixed(2));
	}
}
