import { MediaMatcher } from '@angular/cdk/layout';
import { CommonModule } from '@angular/common';
import { Component, OnDestroy } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { CASHOUT, CRYPTO } from 'src/constants/ui.routes';
import { CoinDecimalPipe } from 'src/pipes/coin-decimal.pipe';
import { CurrencySymbolPipe } from 'src/pipes/currency-symbol.pipe';
import { StateService } from 'src/service/state.service';
import { Balance, State, SupportedCoin } from 'src/types/app.types';

const materialModules = [MatCardModule, MatButtonModule, MatIconModule, MatTooltipModule];
const pipes = [CoinDecimalPipe, CurrencySymbolPipe];

@Component({
	selector: 'app-balance-card',
	standalone: true,
	imports: [CommonModule, ...materialModules, ...pipes],
	templateUrl: './balance-card.component.html',
	styleUrl: './balance-card.component.scss'
})
export class BalanceCardComponent implements OnDestroy {
	SupportedCoin = SupportedCoin;
	subscriptions: Subscription[] = [];
	loading: boolean = false;
	balance: Balance | undefined;
	state: State;

	constructor(private router: Router, private mediaMatcher: MediaMatcher, private stateService: StateService) {
		this.state = this.stateService.getState();

		const stateSub = this.stateService.state$.subscribe({
			next: (state) => {
				this.state = state;

				if (state.jwt != null) {
					this.sync();
				}
			}
		});
		this.subscriptions.push(stateSub);
	}

	sync() {
		this.loading = true;

		let usdtBalance = this.state.balance?.find((b) => b.symbol === SupportedCoin[SupportedCoin.USDT]);

		if (this.state.user?.affiliate) {
			usdtBalance = this.state.balance?.find((b) => b.symbol === SupportedCoin[this.state.coin]);
		}

		if (usdtBalance) {
			this.balance = usdtBalance;
		}

		this.loading = false;
	}

	syncBalance() {
		this.sync();
		this.stateService.refreshBalance();
	}

	withdrawClick() {
		this.router.navigate([CRYPTO, CASHOUT]);
	}

	historyClick() {
		this.router.navigate([CRYPTO]);
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}
}
