import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { Router } from '@angular/router';
import { CRYPTO, DEPOSIT, PAYPAL, UPI } from 'src/constants/ui.routes';
import { DepositMethods } from 'src/types/app.types';
import { BalanceCardComponent } from "./balance-card/balance-card.component";
import { DepositFaqComponent } from "./deposit-faq/deposit-faq.component";

const materialModules = [MatCardModule];

@Component({
	selector: 'app-deposit',
	standalone: true,
	imports: [CommonModule, ...materialModules, BalanceCardComponent, DepositFaqComponent],
	templateUrl: './deposit.component.html',
	styleUrl: './deposit.component.scss'
})
export class DepositComponent {
	recommendedMethods: DepositMethods[] = [
		{
			label: 'Crypto',
			icon: '../../../assets/crypto.svg',
			click: () => {
				this.router.navigate([DEPOSIT, CRYPTO]);
			}
		},
		/* {
			label: 'Polygon',
			icon: '../../../assets/icons/polygon-color.svg',
			click: () => {
				this.router.navigate([DEPOSIT, POLYGON]);
			}
		}, */
		{
			label: 'PayPal',
			icon: '../../../assets/paypal-icon.webp',
			click: () => {
				this.router.navigate([DEPOSIT, PAYPAL]);
			}
		},
	];

	constructor(private router: Router) {
		const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
		if (timezone.toLowerCase() === 'asia/calcutta' || timezone.toLowerCase() === 'asia/kolkata') {
			this.recommendedMethods.push({
				label: 'UPI',
				icon: '../../../assets/upi-icon.webp',
				click: () => {
					this.router.navigate([DEPOSIT, UPI]);
				}
			});
		}
	}
}
