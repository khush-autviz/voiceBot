import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { Router, RouterModule } from '@angular/router';
import { ReCaptchaV3Service } from 'ng-recaptcha';
import { DialogComponent } from 'src/components/dialog/dialog.component';
import { getMatDialogConfig, recapthcaConfig } from 'src/constants/constants';
import { FORGOT_PASSWORD, LOG_IN } from 'src/constants/ui.routes';
import { APIService } from 'src/service/api.service';
import { APIResponse, ForgotPasswordVerifyOtp } from 'src/types/app.types';

const materialModules = [MatDialogModule, MatFormFieldModule, MatIconModule, MatInputModule, MatButtonModule];

@Component({
	selector: 'app-forgot-password',
	standalone: true,
	imports: [...materialModules, CommonModule, ReactiveFormsModule, RouterModule],
	templateUrl: './forgot-password.component.html',
	styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent {
	LOGIN = LOG_IN;

	hidePassword: boolean = true;
	hideConfirmPassword: boolean = true;
	loading: boolean = false;

	isOTPSent: boolean = false;
	passwordMatchStatus: string = '';

	loginForm: FormGroup = new FormGroup({
		email: new FormControl<string>('', [Validators.required, Validators.email]),
		password: new FormControl<string>('', [Validators.required]),
		confirmPassword: new FormControl<string>('', [Validators.required]),
		otp: new FormControl<string>('', [Validators.required]),
		recaptcha: new FormControl<string>('token', [Validators.required])
	});

	constructor(private api: APIService, private recaptchaService: ReCaptchaV3Service, private router: Router, private matDialog: MatDialog) {
	}

	requestOTP() {
		const email = this.loginForm.value && this.loginForm.value['email'];
		if (!this.loading && email && this.loginForm.get('email')?.valid) {
			this.loading = true;
			this.recaptchaService.execute('forgot_password_request_otp').subscribe({
				next: (token: string) => {
					this.api.forgotPasswordRequestOtp({ email: email, recaptcha: token }).subscribe({
						next: (response: APIResponse<boolean>) => {
							if (response.success && response.body) {
								this.isOTPSent = true;
								this.loginForm.get('email')?.disable();
								this.loginForm.get('otp')?.markAsUntouched();
								this.loginForm.get('password')?.markAsUntouched();
								this.loginForm.get('confirmPassword')?.markAsUntouched();
							}
							else {
								this.matDialog.open(DialogComponent, getMatDialogConfig({
									success: false,
									title: 'Could not send OTP',
									message: new String(response.body).toString()
								}))
							}
							this.loading = false;
						},
						error: (error: HttpErrorResponse) => {
							this.matDialog.open(DialogComponent, getMatDialogConfig({
								success: false,
								title: 'Could not send OTP',
								message: error && error.error && error.error.body ? error.error.body : ''
							}));
							this.loading = false;
						}
					});
				},
				error: () => {
					this.loading = false;
					this.matDialog.open(DialogComponent, recapthcaConfig());
				}
			});

		}
	}

	verifyOTP() {

		const password = this.loginForm.get('password')?.value;
		const confirmPassword = this.loginForm.get('confirmPassword')?.value;

		if (password !== confirmPassword) {
			this.passwordMatchStatus = 'Passwords do not match';
		}
		else {
			this.passwordMatchStatus = '';
		}

		if (!this.loading && password === confirmPassword) {
			this.loading = true;
			this.recaptchaService.execute('forgot_password_verify_otp').subscribe({
				next: (token: string) => {
					const verifyOtpDto: ForgotPasswordVerifyOtp = this.loginForm.getRawValue();
					verifyOtpDto.recaptcha = token;
					this.api.forgotPasswordVerifyOtp(verifyOtpDto).subscribe({
						next: (response: APIResponse<boolean>) => {
							if (response.success && response.body) {
								this.matDialog.open(DialogComponent, getMatDialogConfig({
									success: true,
									title: 'Password Reset Successful',
									message: 'Your password has been reset successfully. Please log in to continue',
									redirect: LOG_IN,
									closeButtonLabel: 'Log In'
								}))
							}
							else {
								this.matDialog.open(DialogComponent, getMatDialogConfig({
									success: false,
									title: 'Could not verify OTP',
									message: new String(response.body).toString()
								}))
							}
							this.loading = false;
						},
						error: (error: HttpErrorResponse) => {
							this.matDialog.open(DialogComponent, getMatDialogConfig({
								success: false,
								title: 'Could not verify OTP',
								message: error && error.error && error.error.body ? error.error.body : ''
							}));
							this.loading = false;
						}
					})
				}
			});
		}

	}

	getDisplayError(formControlName: string, placeholder: string): string {
		if (!this.loginForm.untouched) {
			if (this.loginForm.controls[formControlName].hasError('required')) {
				return `Please enter your ${placeholder}`;
			}
			if (this.loginForm.controls[formControlName].hasError('email')) {
				return `Please enter a valid ${placeholder}`;
			}
			return '';
		}
		else {
			return '';
		}
	}

	forgotPassword() {
		this.router.navigate([FORGOT_PASSWORD], { queryParamsHandling: 'merge' });
	}

}
