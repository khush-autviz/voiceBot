import { CommonModule, DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { Router } from '@angular/router';
import { CRYPTO } from 'src/constants/ui.routes';
import { CoinDecimalPipe } from 'src/pipes/coin-decimal.pipe';
import { StateService } from 'src/service/state.service';
import { Balance, PassbookTransaction, SupportedCoin, TokenTransaction } from 'src/types/app.types';

const materialModules = [MatButtonModule, MatTableModule];
const pipes = [CoinDecimalPipe];

@Component({
	selector: 'app-passbook',
	standalone: true,
	imports: [CommonModule, ReactiveFormsModule, ...materialModules, ...pipes],
	templateUrl: './passbook.component.html',
	styleUrl: './passbook.component.scss'
})
export class PassbookComponent implements OnInit {
	transactions: TokenTransaction[] = [];
	passbook: PassbookTransaction[] = [];
	displayedColumns: string[] = ['timeStamp', 'activity', 'credit', 'debit', 'openingBalance', 'closingBalance'];
	balance: Balance | undefined;

	constructor(private router: Router, private datePipe: DatePipe, private coinDecimalPipe: CoinDecimalPipe, private stateService: StateService) {
		const transactions = this.router.getCurrentNavigation()?.extras.state?.["transactions"];
		const balance = this.router.getCurrentNavigation()?.extras.state?.["balance"];

		if (transactions && transactions.length > 0) {
			this.transactions = transactions;
		}

		if (balance) {
			this.balance = balance;
		}

		if (!transactions || balance === null || balance === undefined) {
			this.router.navigate([CRYPTO]);
		}
	}

	ngOnInit(): void {
		if (this.transactions && this.balance) {
			this.passbook = this.generatePassbookTransactions(this.transactions);
		}
	}

	generatePassbookTransactions(transactions: any[]) {
		const passbook: any[] = [];
		let currentBalance = this.balance?.balance || 0;

		transactions.forEach(transaction => {
			const { timeStamp, value, depositIndicator, cause } = transaction;

			const activity = cause;
			const credit = depositIndicator ? value : 0;
			const debit = depositIndicator ? 0 : -value;
			const amount = depositIndicator ? value : -value;

			const closingBalance = currentBalance;
			currentBalance -= amount;
			const openingBalance = currentBalance;

			const passbookTransaction = {
				timeStamp,
				activity,
				credit,
				debit,
				openingBalance,
				closingBalance
			};

			passbook.push(passbookTransaction);
		});

		return passbook;
	}

	exportToCSV() {
		const data = this.passbook;

		const replacer = (key: string, value: any) => (value === null ? '' : value); // specify how you want to handle null values here

		const header = Object.keys(data[0]);

		const csv = data.map((row: any) => {

			return header.map((fieldName) => {
				let value = row[fieldName];

				switch (fieldName) {
					case this.displayedColumns[0]:
						value = this.datePipe.transform(value, 'dd/MM/yyyy hh:mm:ss a');
						break;
					case this.displayedColumns[2]:
						value = this.coinDecimalPipe.transform(value, { coinType: this.getCoinType(), decimalPlaces: 3 });
						break;
					case this.displayedColumns[3]:
						value = this.coinDecimalPipe.transform(value, { coinType: this.getCoinType(), decimalPlaces: 3 });
						break;
					case this.displayedColumns[4]:
						value = this.coinDecimalPipe.transform(value, { coinType: this.getCoinType(), decimalPlaces: 3 });
						break;
					case this.displayedColumns[5]:
						value = this.coinDecimalPipe.transform(value, { coinType: this.getCoinType(), decimalPlaces: 3 });
						break;
				}

				return JSON.stringify(value, replacer)
			}).join(',')
		});

		const headersToDisplay = ['Timestamp (UTC)', 'Activity', `Credit (${this.getBalanceSymbol()})`, `Debit (${this.getBalanceSymbol()})`, `Opening Balance (${this.getBalanceSymbol()})`, `Closing Balance (${this.getBalanceSymbol()})`];
		csv.unshift(headersToDisplay.join(','));
		const csvArray = csv.join('\r\n');

		const a = document.createElement('a');
		const blob = new Blob([csvArray], { type: 'text/csv' });
		const url = window.URL.createObjectURL(blob);

		a.href = url;
		a.download = `Solus Statement for ${this.stateService.getState().user?.address || ''}`;
		a.click();
		window.URL.revokeObjectURL(url);
		a.remove();
	}

	getBalanceSymbol() {
		return this.balance?.symbol === 'MAINNET_TOKEN' ? 'XSUS' : this.balance?.symbol;
	}

	getCoinType() {
		return this.balance?.symbol === 'MAINNET_TOKEN' ? SupportedCoin.MAINNET_TOKEN : SupportedCoin.USDT;
	}
}
