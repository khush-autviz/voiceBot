import { CommonModule } from '@angular/common';
import { HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { ReCaptchaV3Service } from 'ng-recaptcha';
import { Subscription } from 'rxjs';
import { DialogComponent } from 'src/components/dialog/dialog.component';
import { getMatDialogConfig } from 'src/constants/constants';
import { LOG_IN, MARKETS, ONBOARDING } from 'src/constants/ui.routes';
import { environment } from 'src/environment/environment';
import { APIService } from 'src/service/api.service';
import { StateService } from 'src/service/state.service';
import { APIResponse, JwtResponse, LoginWithGooglePayload, SolusMode, SupportedCoin } from 'src/types/app.types';

const materialModules = [MatProgressBarModule];

@Component({
	selector: 'app-google-signin',
	standalone: true,
	imports: [CommonModule, ...materialModules],
	templateUrl: './google-signin.component.html',
	styleUrl: './google-signin.component.scss'
})
export class GoogleSigninComponent implements OnInit, OnDestroy {

	loading: boolean = false;
	queryParamSub!: Subscription;
	queryParams: HttpParams | undefined;
	referralCode: string | null = null;
	partner: string | null = null;
	platform: string | null = null;
	metadata: string | null = null;
	clickId: string | null = null;
	siteId: string | null = null;


	constructor(private activatedRoute: ActivatedRoute, private recaptchaService: ReCaptchaV3Service, private apiService: APIService, private stateService: StateService, private matDialog: MatDialog, private router: Router) {
		if (!this.activatedRoute.snapshot.queryParams['code']) {
			this.router.navigate([LOG_IN]);
			return;
		}

		if (this.activatedRoute.snapshot.queryParams['state']) {
			this.queryParams = new HttpParams({ fromString: decodeURIComponent(this.activatedRoute.snapshot.queryParams['state']) });
			this.referralCode = this.queryParams.get('referralCode');

			this.partner = this.queryParams.get('partner');
			this.platform = this.queryParams.get('platform');

			// Create an object to store non-null values
			const queryParams: any = {};

			const timestamp = this.queryParams.get('timestamp');
			const deviceType = this.queryParams.get('device_type');
			const browserName = this.queryParams.get('browser_name');
			const osName = this.queryParams.get('os_name');
			const osVersion = this.queryParams.get('os_version');
			const httpCountryCode = this.queryParams.get('http_country_code');
			const httpAcceptLanguage = this.queryParams.get('http_accept_language');
			const ipAddress = this.queryParams.get('ip_address');
			const adUnit = this.queryParams.get('ad_unit');
			const bannerSize = this.queryParams.get('banner_size');

			// Add non-null values to the queryParams object
			if (timestamp !== null) queryParams.timestamp = timestamp;
			if (deviceType !== null) queryParams.device_type = deviceType;
			if (browserName !== null) queryParams.browser_name = browserName;
			if (osName !== null) queryParams.os_name = osName;
			if (osVersion !== null) queryParams.os_version = osVersion;
			if (httpCountryCode !== null) queryParams.http_country_code = httpCountryCode;
			if (httpAcceptLanguage !== null) queryParams.http_accept_language = httpAcceptLanguage;
			if (ipAddress !== null) queryParams.ip_address = ipAddress;
			if (adUnit !== null) queryParams.ad_unit = adUnit;
			if (bannerSize !== null) queryParams.banner_size = bannerSize;

			// Convert the object to a JSON string
			this.metadata = JSON.stringify(queryParams);

			// Affiliate Postback Parameters
			this.clickId = this.queryParams.get('click_id');
			this.siteId = this.queryParams.get('site_id');
		}
	}

	ngOnInit() {
		this.queryParamSub = this.activatedRoute.queryParams.subscribe(params => {
			const code = params['code'];
			if (code !== undefined) {
				this.loading = true;
				this.recaptchaService.execute('google_sign_in').subscribe({
					next: (recaptcha: string) => {
						const payload: LoginWithGooglePayload = {
							code: code,
							recaptcha: recaptcha,
							redirectUri: environment.googleRedirectUri,
							referralCode: this.referralCode || '',
							partner: this.partner || '',
							platform: this.platform || '',
							metadata: this.metadata || '',
							clickId: this.clickId || '',
							siteId: this.siteId || '',
						};
						this.loading = true;
						this.apiService.loginWithGoogle(payload).subscribe({
							next: (response: APIResponse<JwtResponse | string>) => {
								if (response.success) {
									const body = response.body as JwtResponse;
									if (body.firstLogin) {
										this.stateService.onLogin(body.token, ONBOARDING, false, true, SolusMode.PRICE_PREDICTION, SupportedCoin.USDT);
									} else {
										const params: Params = {};
										if (this.queryParams) {
											this.queryParams?.keys().forEach(key => {
												params[key] = this.queryParams?.get(key);
											})
											this.stateService.switchModeViaQueryParams(params);
										}
										this.stateService.onLogin(body.token, params['redirectUri'] || MARKETS, false, false, SolusMode.PRICE_PREDICTION, SupportedCoin.USDT);
									}
								} else {
									this.showErrorDialog(response.body as string);
								}
							},
							error: (error: HttpErrorResponse) => {
								this.loading = false;
								this.showErrorDialog(error.error);
							},
							complete: () => {
								this.loading = false;
							}
						});
					},
					error: () => {
						this.loading = false;
						this.showErrorDialog();
					}
				});
			}
		});
	}

	ngOnDestroy(): void {
		this.queryParamSub.unsubscribe();
	}

	showErrorDialog(error: string = '') {
		this.matDialog.open(DialogComponent, getMatDialogConfig({
			success: false,
			title: 'Could not sign in via Google!',
			message: error || 'Unfortunately, we are facing some issue signing you in using Google. Please try again later or sign in using email address.',
			redirect: LOG_IN,
			mergeQueryParams: false
		}));
	}
}
