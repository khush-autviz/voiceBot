import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { MARKETS } from 'src/constants/ui.routes';
import { MatButtonModule } from '@angular/material/button';

@Component({
    selector: 'app-success-kyc',
    templateUrl: './success-kyc.component.html',
    styleUrls: ['./success-kyc.component.scss'],
    standalone: true,
    imports: [MatButtonModule]
})
export class SuccessKycComponent {

	constructor(private router: Router) {

	}

	onSuccessClick() {
		this.router.navigate([MARKETS]);
	}

}
