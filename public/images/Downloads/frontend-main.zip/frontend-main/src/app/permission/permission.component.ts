import { CommonModule, DatePipe, TitleCasePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, Input, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialog } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { DialogComponent } from 'src/components/dialog/dialog.component';
import { getMatDialogConfig } from 'src/constants/constants';
import { KYC, MARKETS, SUCCESS } from 'src/constants/ui.routes';
import { APIService } from 'src/service/api.service';
import { APIResponse, KycData } from 'src/types/app.types';

@Component({
    selector: 'app-permission',
    templateUrl: './permission.component.html',
    styleUrls: ['./permission.component.scss'],
    standalone: true,
    imports: [
		CommonModule,
        ReactiveFormsModule,
        MatCheckboxModule,
        MatButtonModule,
        MatDividerModule,
        MatProgressSpinnerModule,
        TitleCasePipe,
        DatePipe,
    ],
})
export class PermissionComponent implements OnInit, OnChanges, OnDestroy {

	@Input() kycData!: KycData;
	permissionForm: FormGroup = new FormGroup({});
	accepted: boolean = false;
	loading: boolean = false;
	kycProcessing: boolean = false;
	formChanges!: Subscription;
	isKycClear: boolean = false;
	interval: NodeJS.Timeout | undefined;
	globalInterval: NodeJS.Timeout | undefined;

	permissionList = [
		'I certify that I am NOT a national of the United States of America.',
		'I am not currently or formerly a politically exposed person or public official.',
		'I am not working at and do not have family members working at Solus.',
		'I have read, understand and agree to be bound by all terms, disclosures, certifications, and disclaimers applicable to me, as found on the legal page of the Solus website.',
	];

	constructor(private router: Router, private api: APIService, private matDialog: MatDialog) {
		for (let i = 0; i < this.permissionList.length; i++) {
			const formControl: FormControl = new FormControl<boolean>(false, [Validators.required]);
			this.permissionForm.addControl(`permission_${i}`, formControl);
		}
	}

	ngOnInit(): void {
		this.formChanges = this.permissionForm.valueChanges.subscribe({
			next: (value: any) => {
				this.accepted = true;
				for (const key of Object.keys(value)) {
					this.accepted = this.accepted && value[key];
				}
			}
		})
	}

	ngOnChanges(changes: SimpleChanges): void {
		if (changes['kycData'] && changes['kycData'].currentValue) {
			this.kycData = changes['kycData'].currentValue;

			this.checkKYCChanges();
		}
	}

	checkKYCChanges() {
		this.isKycClear = this.kycData && this.kycData.outcome === 'clear' && this.kycData.documentCheckOutcome === 'clear';
		if (this.isKycClear) {
			clearInterval(this.interval);
			clearInterval(this.globalInterval);
			this.kycProcessing = false;
			this.openSuccessDialog('Your KYC is successfully processed. Thank you!', `${KYC}/${SUCCESS}`);
		}

		this.accepted = this.kycData.signedUserAgreement;

		if (this.accepted) {
			for (let i = 0; i < this.permissionList.length; i++) {
				this.permissionForm.get(`permission_${i}`)?.setValue(true);
			}
			this.permissionForm.disable();
		}
	}

	ngOnDestroy(): void {
		this.formChanges.unsubscribe();
		clearInterval(this.globalInterval);
	}

	complete() {
		this.loading = true;
		this.api.kycSaveUserAgreement().subscribe({
			next: (response: APIResponse<KycData>) => {
				this.loading = false;
				if (response.success) {
					this.kycData = response.body;
					this.checkKYCChanges();
				}
			},
			error: () => {
				this.loading = false;
			}
		});
	}

	onSubmitKYC() {
		this.kycProcessing = true;
		this.api.kycStartCheck().subscribe({
			next: (response: APIResponse<KycData>) => {
				if (response.success) {
					let maxTime: number = 30000;

					this.interval = setInterval(() => {
						maxTime -= 3000;

						if (maxTime <= 0) {
							clearInterval(this.interval);
							this.openErrorDialog('KYC is still in process', 'Your KYC is taking longer than usual to process. You can continue using the application while we process your KYC. Our team will reach you out in case of any problems during KYC processing. Thank you.', MARKETS, 'Return to App', 'Keep Waiting');
						}
					}, 3000);

					this.globalInterval = setInterval(() => {
						this.kycCheckStatus();
					}, 2000);
				}
				else {
					clearInterval(this.interval);
					this.openErrorDialog('Error while completing KYC', response.body.toString().split(":").length > 0 ? response.body.toString().split(":")[1].trim() : response.body.toString());
				}
			},
			error: (error: HttpErrorResponse) => {
				this.kycProcessing = false;
				clearInterval(this.interval);
				this.openErrorDialog('Error while completing KYC', error.error.body.toString());
			}
		})
	}

	openErrorDialog(title: string, message: string, redirect: string = '', firstButtonLabel?: string, closeButtonLabel?: string) {
		return this.matDialog.open(DialogComponent, getMatDialogConfig({
			success: false,
			title: title,
			message: message,
			firstButtonLabel: firstButtonLabel,
			closeButtonLabel: closeButtonLabel ?? 'Okay',
			redirect: redirect || undefined
		}));
	}

	openSuccessDialog(message: string, redirect: string = '') {
		this.matDialog.closeAll();
		return this.matDialog.open(DialogComponent, getMatDialogConfig({
			success: true,
			title: 'KYC Update',
			message: message,
			closeButtonLabel: 'Okay',
			skipLog: true,
			redirect: redirect || undefined
			// redirect: `${KYC}/${SUCCESS}`
		}));
	}

	kycCheckStatus() {
		this.api.kycCheckStatus().subscribe({
			next: (response: APIResponse<KycData>) => {
				if (response.success) {
					this.kycData = response.body;
					this.checkKYCChanges();
				}
				else {
					this.openErrorDialog('KYC Status', 'Could not retrieve KYC status. Please try again later.');
				}
			},
			error: () => {
				this.openErrorDialog('KYC Status', 'Could not retrieve KYC status. Please try again later.');
			}
		});
	}

}
