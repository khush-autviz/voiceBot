

import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, ValidationErrors, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatStepperModule } from '@angular/material/stepper';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import Decimal from 'decimal.js';
import * as moment from 'moment';
import { Subscription } from 'rxjs';
import { LoaderComponent } from 'src/app/loader/loader.component';
import { DialogComponent } from 'src/components/dialog/dialog.component';
import { confirmUpiIdValidator, ethereumAddressValidator, getMatDialogConfig, isKycComplete, positiveNonZeroValidator, upiIdValidator } from 'src/constants/constants';
import { CRYPTO, KYC } from 'src/constants/ui.routes';
import { BalancePipe } from 'src/pipes/balance.pipe';
import { CoinDecimalPipe } from 'src/pipes/coin-decimal.pipe';
import { CurrencySymbolPipe } from 'src/pipes/currency-symbol.pipe';
import { APIService } from 'src/service/api.service';
import { StateService } from 'src/service/state.service';
import { APIResponse, AppConfig, AppConfigEnum, Balance, CashOutStatus, KycData, State, SupportedCoin, TokenWithdrawResponse, UPIPaymentStatus, UPIWithdrawRequest, UPIWithdrawal } from 'src/types/app.types';

const materialModules = [MatDialogModule, MatFormFieldModule, MatIconModule, MatInputModule, MatButtonModule, MatCardModule, MatExpansionModule, MatStepperModule, MatProgressSpinnerModule, MatDividerModule];
const pipes = [CoinDecimalPipe, CurrencySymbolPipe, BalancePipe];

@Component({
	selector: 'app-cashout',
	standalone: true,
	imports: [CommonModule, ReactiveFormsModule, ...materialModules, ...pipes],
	templateUrl: './cashout.component.html',
	styleUrls: ['./cashout.component.scss']
})
export class CashoutComponent implements OnInit, OnDestroy {

	upiRegex = /^[a-zA-Z0-9.-_]{2,256}@[a-zA-Z]{2,64}$/;

	cashoutRequest: FormGroup = new FormGroup({
		'recipient': new FormControl<string>('', [Validators.required, ethereumAddressValidator()]),
		'confirmRecipient': new FormControl<string>('', [Validators.required, ethereumAddressValidator()]),
		'amount': new FormControl<number>(0, [Validators.required, Validators.max(10000)])
	});

	cashoutUpiRequest: FormGroup = new FormGroup({
		'upiId': new FormControl<string>('', [Validators.required, upiIdValidator()]),
		'confirmUpiId': new FormControl<string>('', [Validators.required, upiIdValidator()]),
		'amount': new FormControl<number>(1, [Validators.required, Validators.max(10000), Validators.min(1)]),
	}, {
		validators: [confirmUpiIdValidator]
	});

	state: State;
	stateSub!: Subscription;

	loading: boolean = false;
	withdrawalCharges: number = 0;
	withdrawalAmount: number = 0;
	isKycComplete: boolean = false;
	isCashoutPaused: boolean = false;
	minimumWithdrawalAmount: number = 0;
	subscriptions: Subscription[] = [];
	kycNavigating: boolean = false;

	upiWithdrawalsLoading: boolean = false;
	upiWithdrawals: UPIWithdrawal[] = [];
	upiWithdrawalCharges: number = 0;
	upiWithdrawalAmount: number = 0;

	SupportedCoin = SupportedCoin;
	UPIPaymentStatus = UPIPaymentStatus;

	constructor(private router: Router, private stateService: StateService, private matDialog: MatDialog, private api: APIService, private title: Title) {
		this.title.setTitle('Withdraw / Solus');
		this.state = this.stateService.getState();
		this.cashoutRequest.reset();
	}

	ngOnInit(): void {

		this.stateSub = this.stateService.state$.subscribe({
			next: (state: State) => {
				this.state = state;
				if (state.jwt != null) {
					const balance: Balance | undefined = this.state.balance?.filter(b => b.symbol === SupportedCoin[this.state.coin].toString())?.at(0);
					if (balance !== undefined) {
						const absoluteBalance = balance.balance / Math.pow(10, balance.decimals);
						this.cashoutRequest.get('amount')?.addValidators(Validators.max(absoluteBalance));
						this.cashoutUpiRequest.get('amount')?.addValidators(Validators.max(absoluteBalance));
						if (absoluteBalance < 5) {
							this.cashoutRequest.get('amount')?.setValue(absoluteBalance);
							this.cashoutUpiRequest.get('amount')?.setValue(absoluteBalance);
						}
						this.cashoutRequest.updateValueAndValidity();
						this.cashoutUpiRequest.updateValueAndValidity();
					}

					this.api.getSettings().subscribe({
						next: (res: APIResponse<AppConfig[]>) => {
							if (res.success) {
								this.stateService.setConfig(res.body);

								const configAmount = this.stateService.getConfig(AppConfigEnum.MINIMUM_WITHDRAWAL_PER_CASH_OUT);
								if (configAmount) {
									this.minimumWithdrawalAmount = parseInt(configAmount);
									this.cashoutRequest.controls["amount"].addValidators([Validators.min(this.minimumWithdrawalAmount)]);
									this.cashoutUpiRequest.controls["amount"].addValidators([Validators.min(this.minimumWithdrawalAmount)]);
								} else {
									this.minimumWithdrawalAmount = 0;
									this.cashoutRequest.controls["amount"].addValidators([positiveNonZeroValidator()]);
									this.cashoutUpiRequest.controls["amount"].addValidators([positiveNonZeroValidator()]);
								}

								this.cashoutRequest.updateValueAndValidity();
								this.cashoutUpiRequest.updateValueAndValidity();
							}
						},
						error: () => {
							this.minimumWithdrawalAmount = 0;
							this.cashoutRequest.controls["amount"].addValidators([positiveNonZeroValidator()]);
							this.cashoutUpiRequest.controls["amount"].addValidators([positiveNonZeroValidator()]);
							this.cashoutRequest.updateValueAndValidity();
							this.cashoutUpiRequest.updateValueAndValidity();
						}
					});
				}
			}
		});

		this.api.kycCheckStatus().subscribe({
			next: (response: APIResponse<KycData>) => {
				if (response.success) {
					this.isKycComplete = isKycComplete(response.body);
				}
			}
		});

		const sub = this.cashoutRequest.valueChanges.subscribe((res) => {
			if (res.recipient !== res.confirmRecipient) {
				this.cashoutRequest.controls.confirmRecipient.setErrors({ "walletAddressMatch": true });
			} else {
				this.cashoutRequest.controls.confirmRecipient.setErrors(null);
			}
		});
		this.subscriptions.push(sub);

		this.getUPIWithdrawals();
	}

	ngOnDestroy(): void {
		this.stateSub.unsubscribe();
		this.subscriptions.forEach(sub => sub?.unsubscribe());
	}

	goToKyc(): void {
		this.kycNavigating = true;
		this.router.navigate([KYC]);
	}

	getError(formControlName: string, displayFormControlName: string): string {
		const errors: ValidationErrors | null | undefined = this.cashoutRequest.get(formControlName)?.errors;
		if (errors !== null && errors !== undefined) {
			if (errors['required']) {
				return displayFormControlName + ' is required';
			}
			if (errors['invalidEthereumAddress']) {
				return 'Please enter a valid ethereum wallet address';
			}
			if (errors['min']) {
				return `Minimum withdrawal amount is ${this.minimumWithdrawalAmount} USDT`;
			}
			if (errors['positiveNonZero']) {
				return 'Withdrawal amount should be greater than 0';
			}
			if (errors['max']) {
				return 'Can not exceed your balance';
			}
			if (errors['walletAddressMatch']) {
				return 'Wallet Addresses don\'t match';
			}
			return 'Unknown error';
		}

		return '';
	}

	getErrorUpi(formControlName: string, displayFormControlName: string): string {
		const errors: ValidationErrors | null | undefined = this.cashoutUpiRequest.get(formControlName)?.errors;
		if (errors !== null && errors !== undefined) {
			if (errors['required']) {
				return displayFormControlName + ' is required';
			}
			if (errors['pattern']) {
				return 'Please enter a valid UPI ID';
			}
			if (errors['upiNoMatch']) {
				return 'UPI IDs don\'t match';
			}
			if (errors['min']) {
				return `Minimum withdrawal amount is ${this.minimumWithdrawalAmount} USDT`;
			}
			if (errors['positiveNonZero']) {
				return 'Withdrawal amount should be greater than 0';
			}
			if (errors['max']) {
				return 'Can not exceed your balance';
			}

			return 'Unknown error';
		}

		return '';
	}

	submitCashoutRequest() {
		this.loading = true;
		const loaderRef = this.matDialog.open(LoaderComponent, {
			width: '500px',
			disableClose: true,
			data: {
				title: 'Be patient, transaction processing from chain',
				message: 'Do not leave or refresh this page. We are processing transaction from Polygon chain. This may take a few minutes.'
			}
		});
		this.api.withdrawToken(this.cashoutRequest.value).subscribe({
			next: (response: APIResponse<TokenWithdrawResponse>) => {
				this.loading = false;
				loaderRef.close();
				if (response.success) {
					let success = true;
					let title = '';
					let message = response.body.message;
					if (response.body.status !== CashOutStatus.COMPLETED) {
						success = false;
						title = 'Could not process cashout';
					} else {
						success = true;
						title = 'Cashout Processed';
						message = 'Your cashout request has been submitted successfully';
					}

					const dialogRef = this.matDialog.open(DialogComponent, getMatDialogConfig({ success, title, message }));

					const sub = dialogRef.afterClosed().subscribe(() => {
						this.router.navigate([`/${CRYPTO}`]);
					});
					this.subscriptions.push(sub);
				} else {
					this.matDialog.open(DialogComponent, getMatDialogConfig({
						success: false,
						title: 'Could not process cashout',
						message: response.body as unknown as string || response.body.message
					}));
				}
			},
			error: (error: HttpErrorResponse) => {
				this.loading = false;
				loaderRef.close();
				console.error(error);
				this.matDialog.open(DialogComponent, getMatDialogConfig({
					success: false,
					title: 'Could not process cashout',
					message: error.error || error.message
				}))
			},
		});
	}

	submitCashoutUpiRequest() {
		if (this.cashoutUpiRequest.valid) {
			this.loading = true;
			const loaderRef = this.matDialog.open(LoaderComponent, {
				width: '500px',
				disableClose: true,
				data: {
					title: 'Be patient, withdrawal is initiating',
					message: 'Do not leave or refresh this page. We are initiating your withdrawal. This may take a few minutes.'
				}
			});

			const withdrawRequest: UPIWithdrawRequest = {
				amountInUSDT: this.cashoutUpiRequest.value.amount as number,
				upiId: this.cashoutUpiRequest.value.upiId as string
			}
			this.api.upiWithdrawRequest(withdrawRequest).subscribe({
				next: (response: APIResponse<string>) => {
					this.loading = false;
					loaderRef.close();
					if (response.success) {
						const dialogRef = this.matDialog.open(DialogComponent, getMatDialogConfig({
							success: true,
							title: 'Withdrawal Initiated',
							message: response.body
						}));

						const sub = dialogRef.afterClosed().subscribe(() => {
							this.router.navigate([`/${CRYPTO}`]);
						});

						this.subscriptions.push(sub);
						this.stateService.refreshBalance();
						this.getUPIWithdrawals();
					} else {
						this.matDialog.open(DialogComponent, getMatDialogConfig({
							success: false,
							title: 'Failed',
							message: response.body
						}));
					}
				},
				error: (error: HttpErrorResponse) => {
					this.loading = false;
					loaderRef.close();
					console.error(error);
					this.matDialog.open(DialogComponent, getMatDialogConfig({
						success: false,
						title: 'Failed',
						message: error.error || error.message
					}))
				},
			});
		}
	}

	onStepChange($event: StepperSelectionEvent) {
		if ($event && $event.selectedIndex && $event.selectedIndex > 0) {
			this.api.getWithdrawalCharges(this.cashoutRequest.value).subscribe({
				next: (response: APIResponse<number>) => {
					if (response.success) {
						this.withdrawalCharges = response.body;
						this.withdrawalAmount = new Decimal(this.cashoutRequest.get('amount')?.value).minus(this.withdrawalCharges).toNumber();
					}
				}
			});
		}
	}

	onUPIStepChange($event: StepperSelectionEvent) {
		if ($event && $event.selectedIndex && $event.selectedIndex > 0 && this.cashoutUpiRequest.valid) {
			this.api.getUPIWithdrawalCharges(this.cashoutUpiRequest.get('amount')?.value).subscribe({
				next: (response: APIResponse<number>) => {
					if (response.success) {
						this.upiWithdrawalCharges = response.body;
						this.upiWithdrawalAmount = new Decimal(this.cashoutUpiRequest.get('amount')?.value).minus(this.upiWithdrawalCharges).toNumber();
					}
				}
			});
		}
	}

	openTelegram() {
		window.open('https://t.me/SolusFinance/15770', '_blank');
	}

	openDiscord() {
		window.open('https://discord.gg/khQ8UM8kZZ', '_blank');
	}

	getUPIWithdrawals(): void {
		this.upiWithdrawalsLoading = true;
		this.api.getUPIWithdrawals().subscribe({
			next: (response) => {
				if (response.success) {
					this.upiWithdrawals = response.body.content.sort((a, b) => moment(b.createdAt).unix() - moment(a.createdAt).unix());
				}
				this.upiWithdrawalsLoading = false;
			},
			error: () => {
				this.upiWithdrawalsLoading = false;
			}
		});
	}

	hasValue(formControlName: string) {
		return this.cashoutUpiRequest.get(formControlName)?.value ? true : false;
	}
}
