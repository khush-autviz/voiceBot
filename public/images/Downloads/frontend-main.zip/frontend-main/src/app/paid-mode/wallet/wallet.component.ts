import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnDestroy } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatChipsModule } from '@angular/material/chips';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTabChangeEvent, MatTabsModule } from '@angular/material/tabs';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { BalanceComponent } from 'src/app/balance/balance.component';
import { PAYPAL_REFERENCE_ID, RADOM_DEPOSIT_REFERENCE_ID, UPI_DEPOSIT_REFERENCE_ID, UPI_WITHDRAWAL_REFERENCE_ID, copyToClipboard } from 'src/constants/constants';
import { CASHOUT, CRYPTO, DEPOSIT, PASSBOOK } from 'src/constants/ui.routes';
import { CoinDecimalPipe } from 'src/pipes/coin-decimal.pipe';
import { CoinNamePipe } from 'src/pipes/coin-name.pipe';
import { CurrencySymbolPipe } from 'src/pipes/currency-symbol.pipe';
import { APIService } from 'src/service/api.service';
import { StateService } from 'src/service/state.service';
import { APIResponse, MainnetTokenTransaction, Page, State, SupportedCoin, TokenTransaction, Transaction, TransactionFilter, TransactionType } from 'src/types/app.types';

const materialModules = [MatIconModule, MatButtonModule, MatCardModule, MatChipsModule, MatTabsModule, MatInputModule, MatFormFieldModule, MatDatepickerModule, MatNativeDateModule, MatSnackBarModule];
const pipes = [CoinDecimalPipe, CurrencySymbolPipe];
const components = [BalanceComponent];

@Component({
	selector: 'app-wallet',
	standalone: true,
	imports: [CommonModule, ReactiveFormsModule, ...materialModules, ...pipes, ...components],
	templateUrl: './wallet.component.html',
	styleUrls: ['./wallet.component.scss'],
})
export class WalletComponent implements OnDestroy {
	state: State;
	stateSub: Subscription;
	deposits: TokenTransaction[] = [];
	withdrawals: TokenTransaction[] = [];
	transactions: TokenTransaction[] = [];
	filteredTransactions: any[] = [];
	cashouts: TokenTransaction[] = [];
	dateFilter = new FormGroup({
		start: new FormControl<Date | null>(null),
		end: new FormControl<Date | null>(null)
	});
	maxDate: Date = new Date();
	filtersApplied: boolean = false;
	selectedStatus: TransactionType = TransactionType.All;
	TransactionType = TransactionType;
	mainnetTransactions: MainnetTokenTransaction[] = [];
	TransactionFilter = TransactionFilter;
	selectedTransactionFilter = TransactionFilter.Wallet;
	paypalTransactions: Transaction[] = [];
	PAYPAL_REFERENCE_ID = PAYPAL_REFERENCE_ID;
	SupportedCoin = SupportedCoin;
	demoAccountEnabled = false;
	upiDepositTransactions: Transaction[] = [];
	upiWithdrawalTransactions: Transaction[] = [];
	UPI_DEPOSIT_REFERENCE_ID = UPI_DEPOSIT_REFERENCE_ID;
	UPI_WITHDRAWAL_REFERENCE_ID = UPI_WITHDRAWAL_REFERENCE_ID;
	radomDepositTransactions: Transaction[] = [];
	RADOM_DEPOSIT_REFERENCE_ID = RADOM_DEPOSIT_REFERENCE_ID;

	constructor(private api: APIService, private stateService: StateService, private router: Router, private snackbar: MatSnackBar, private title: Title, private coinPipe: CoinNamePipe) {
		this.title.setTitle('Wallet / Solus');
		this.state = this.stateService.getState();
		this.stateSub = this.stateService.state$.subscribe({
			next: (state: State) => {
				this.state = state;
				if (state.jwt != null) {
					this.toggleDemoAccount();
				}
			}
		});

		this.getDeposits();
		this.getWithdrawals();
		this.getMainnetTransactions();
		this.getPaypalTransactions();
		this.getUPIDepositTransactions();
		this.getUPIWithdrawalTransactions();
		this.getRadomDepositTransactions();
	}


	ngOnDestroy(): void {
		this.stateSub.unsubscribe();
	}

	goToDeposit() {
		this.router.navigate([DEPOSIT]);
	}

	goToWithdraw() {
		this.router.navigate([CRYPTO, CASHOUT]);
	}

	getDeposits() {
		this.api.getDeposits().subscribe({
			next: (response: APIResponse<Page<TokenTransaction>>) => {
				if (response.success) {
					this.deposits = response.body.content.filter(t => t.value !== null && t.value !== undefined);
					this.deposits.forEach((d) => {
						d.depositIndicator = true;
						this.filteredTransactions.push(d);
					});
					this.filteredTransactions.sort((a, b) => b.timeStamp - a.timeStamp);
				}
			},
			error: (error: HttpErrorResponse) => {
				console.error(error);
			},
		});
	}

	getWithdrawals() {
		this.api.getWithdrawals().subscribe({
			next: (response: APIResponse<Page<TokenTransaction>>) => {
				if (response.success) {
					this.withdrawals = response.body.content.filter(t => t.value !== null && t.value !== undefined);
					this.withdrawals.forEach((d) => {
						d.depositIndicator = false;
						this.filteredTransactions.push(d);
					});
					this.filteredTransactions.sort((a, b) => b.timeStamp - a.timeStamp);
				}
			},
		});
	}

	copy(value: string): void {
		copyToClipboard(value);
		this.snackbar.open('Copied!', undefined, {
			duration: 500,
		});
	}

	getAllTransactions(): TokenTransaction[] {
		return this.deposits
			.concat(
				this.withdrawals,
				this.paypalTransactions as unknown as TokenTransaction[],
				this.upiDepositTransactions as unknown as TokenTransaction[],
				this.upiWithdrawalTransactions as unknown as TokenTransaction[],
				this.radomDepositTransactions as unknown as TokenTransaction[],
			)
			.sort((a, b) => b.timeStamp - a.timeStamp);
	}

	getDateErrorText() {
		const startDateError = this.dateFilter.controls.start.errors;
		const endDateError = this.dateFilter.controls.end.errors;

		if (startDateError && endDateError)
			return 'Invalid start and end dates';
		else if (startDateError) return 'Invalid start date';
		else return 'Invalid end date';
	}

	dateChange(startDate: HTMLInputElement, endDate: HTMLInputElement) {
		if (this.dateFilter.valid) {
			if (startDate.value && endDate.value) {
				this.filtersApplied = true;
				this.applyFilters();
			}
		}
	}

	statusChange(status: TransactionType) {
		this.selectedStatus = status;
		this.applyFilters();
	}

	clearFilters() {
		this.filtersApplied = false;

		if (this.selectedTransactionFilter === TransactionFilter.Wallet) {
			this.selectedStatus = TransactionType.All;
		}

		this.dateFilter.reset();
		this.applyFilters();
	}

	applyFilters() {
		const { start, end } = this.dateFilter.value;

		this.filteredTransactions = this.getAllTransactions();

		if (this.selectedStatus && this.selectedStatus !== TransactionType.All) {
			this.filtersApplied = true;
			if (this.selectedStatus === TransactionType.Deposits) {
				this.filteredTransactions = [...this.deposits];
				this.filteredTransactions.push(...this.paypalTransactions);
				this.filteredTransactions.push(...this.upiDepositTransactions);
				this.filteredTransactions.push(...this.radomDepositTransactions);
			} else if (this.selectedStatus === TransactionType.Withdrawals) {
				this.filteredTransactions = [...this.withdrawals];
				this.filteredTransactions.push(...this.upiWithdrawalTransactions);
			} else if (this.selectedStatus === TransactionType.MainnetToken) {
				this.filteredTransactions = this.mainnetTransactions.map((transaction) => {
					return {
						...transaction,
						timeStamp: new Date(transaction.txnDate).getTime(),
						value: transaction.amount,
						depositIndicator: true, // TransactionDirection.RECEIVE
					}
				});
			}
		} else {
			this.filtersApplied = false;
		}

		if (start && end) {
			const startTimestamp = start.setHours(0, 0, 0, 0);
			const endTimestamp = end.setHours(23, 59, 59, 999);

			this.filtersApplied = true;
			this.filteredTransactions = this.filteredTransactions.filter(transaction => (transaction.timeStamp >= startTimestamp && transaction.timeStamp <= endTimestamp));
		}

		this.filteredTransactions.sort((a, b) => b.timeStamp - a.timeStamp);
	}

	getMainnetTransactions() {
		this.api.getTransactions(SupportedCoin.MAINNET_TOKEN).subscribe({
			next: (response: APIResponse<Page<MainnetTokenTransaction>>) => {
				if (response.success) {
					this.mainnetTransactions = response.body.content;
				}
			},
		});
	}

	getPaypalTransactions() {
		this.api.getTransactions(SupportedCoin.USDT, PAYPAL_REFERENCE_ID).subscribe({
			next: (response: APIResponse<Page<MainnetTokenTransaction>>) => {
				if (response.success) {
					this.paypalTransactions = response.body.content.map((transaction) => {
						return {
							...transaction,
							tokenSymbol: this.coinPipe.transform(SupportedCoin.USDT),
							timeStamp: new Date(transaction.txnDate).getTime(),
							value: transaction.amount,
							depositIndicator: true // TransactionDirection.RECEIVE
						}
					});

					this.filteredTransactions.push(...this.paypalTransactions);
					this.filteredTransactions.sort((a, b) => b.timeStamp - a.timeStamp);
				}
			},
		});
	}

	transactionChange(transaction: TransactionFilter) {
		this.selectedTransactionFilter = transaction;

		switch (transaction) {
			case TransactionFilter.Wallet:
				this.statusChange(TransactionType.All);
				break;
			case TransactionFilter.MainnetToken:
				this.statusChange(TransactionType.MainnetToken);
				break;
		}
	}

	getTransactionFilterTitle(transaction: TransactionFilter) {
		switch (transaction) {
			case TransactionFilter.Wallet:
				return 'Transactions';
			case TransactionFilter.MainnetToken:
				return 'Mainnet Token';
		}
	}

	viewPassbook() {
		let transactions = this.filteredTransactions;
		let balance = this.state.balance?.find(balance => balance.symbol === 'USDT');
		if (this.selectedTransactionFilter === TransactionFilter.MainnetToken) {
			balance = this.state.balance?.find(balance => balance.symbol === 'MAINNET_TOKEN');
			transactions = this.filteredTransactions.map((t: MainnetTokenTransaction) => {
				return {
					value: t.amount,
					timeStamp: new Date(t.txnDate).getTime(),
					depositIndicator: true,
					cause: t.cause
				}
			});
			this.router.navigate([CRYPTO, PASSBOOK], { state: { transactions, balance } })
		} else {
			balance = this.state.balance?.find(balance => balance.symbol === 'USDT');
			this.api.getTransactions(SupportedCoin.USDT).subscribe(res => {
				if (res.success) {
					transactions = res.body.content.sort((a, b) => new Date(b.txnDate).getTime() - new Date(a.txnDate).getTime()).map(t => ({
						value: t.amount,
						timeStamp: new Date(t.txnDate).getTime(),
						depositIndicator: this.state.user?.address === t.owner,
						cause: this.getCauseText(t.cause)
					}));

					this.router.navigate([CRYPTO, PASSBOOK], { state: { transactions, balance } })

				} else {
					this.snackbar.open('Could not fetch transactions!');
				}
			});
		}
	}

	getCauseText(cause: string) {
		const activity = cause.split('_').join(' ').toLowerCase();

		switch (cause) {
			case 'PLACE_BET':
				return 'Buy Contract';
			case 'BET_WINNING':
				return 'Contract Winning';
			default:
				if (cause.slice(0, 2) === '0x') {
					return 'Deposit Funds with transaction hash ' + cause;
				}
				return activity.charAt(0).toUpperCase() + activity.slice(1);
		}
	}

	tabChange(e: MatTabChangeEvent) {
		const { tab } = e;

		switch (tab.textLabel) {
			case TransactionFilter.Wallet:
				this.transactionChange(TransactionFilter.Wallet);
				break;
			case TransactionFilter.MainnetToken:
				this.transactionChange(TransactionFilter.MainnetToken);
				break;
		}
	}

	toggleDemoAccount(): void {
		this.demoAccountEnabled = (this.state.coin === SupportedCoin.DEMO_USDT);
	}

	getUPIDepositTransactions() {
		this.api.getTransactions(SupportedCoin.USDT, UPI_DEPOSIT_REFERENCE_ID).subscribe({
			next: (response: APIResponse<Page<MainnetTokenTransaction>>) => {
				if (response.success) {
					this.upiDepositTransactions = response.body.content.map((transaction) => {
						return {
							...transaction,
							tokenSymbol: this.coinPipe.transform(SupportedCoin.USDT),
							timeStamp: new Date(transaction.txnDate).getTime(),
							value: transaction.amount,
							depositIndicator: true // TransactionDirection.RECEIVE
						}
					});

					this.filteredTransactions.push(...this.upiDepositTransactions);
					this.filteredTransactions.sort((a, b) => b.timeStamp - a.timeStamp);
				}
			},
		});
	}

	getUPIWithdrawalTransactions() {
		this.api.getTransactions(SupportedCoin.USDT, UPI_WITHDRAWAL_REFERENCE_ID).subscribe({
			next: (response: APIResponse<Page<MainnetTokenTransaction>>) => {
				if (response.success) {
					this.upiWithdrawalTransactions = response.body.content.map((transaction) => {
						return {
							...transaction,
							tokenSymbol: this.coinPipe.transform(SupportedCoin.USDT),
							timeStamp: new Date(transaction.txnDate).getTime(),
							value: transaction.amount,
							depositIndicator: false // TransactionDirection.SEND
						}
					});

					this.filteredTransactions.push(...this.upiWithdrawalTransactions);
					this.filteredTransactions.sort((a, b) => b.timeStamp - a.timeStamp);
				}
			},
		});
	}

	getRadomDepositTransactions() {
		this.api.getTransactions(SupportedCoin.USDT, RADOM_DEPOSIT_REFERENCE_ID).subscribe({
			next: (response: APIResponse<Page<MainnetTokenTransaction>>) => {
				if (response.success) {
					this.radomDepositTransactions = response.body.content.map((transaction) => {
						return {
							...transaction,
							tokenSymbol: this.coinPipe.transform(SupportedCoin.USDT),
							timeStamp: new Date(transaction.txnDate).getTime(),
							value: transaction.amount,
							depositIndicator: true // TransactionDirection.RECEIVE
						}
					});

					this.filteredTransactions.push(...this.radomDepositTransactions);
					this.filteredTransactions.sort((a, b) => b.timeStamp - a.timeStamp);
				}
			},
		});
	}

}
