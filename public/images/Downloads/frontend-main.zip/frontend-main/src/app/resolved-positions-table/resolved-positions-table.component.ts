import { CommonModule } from '@angular/common';
import { Component, Input, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { PageEvent } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { Subscription } from 'rxjs';
import { PaginationComponent } from 'src/components/pagination/pagination.component';
import { ASSET_MAX_DECIMAL_PLACES, assetsSortByName, DEFAULT_PAGE_SIZE, hasPassed } from 'src/constants/constants';
import { CoinDecimalPipe } from 'src/pipes/coin-decimal.pipe';
import { CurrencySymbolPipe } from 'src/pipes/currency-symbol.pipe';
import { HumanizeDurationPipe } from 'src/pipes/humanize-duration.pipe';
import { APIService } from 'src/service/api.service';
import { MarketService } from 'src/service/market.service';
import { StateService } from 'src/service/state.service';
import { SpotTrade, SpotTradeAsset, SpotTradeStatus, State, SupportedCoin, TradePosition, TradeStats } from 'src/types/app.types';
import { ShareTradeDialogComponent } from '../market-trade-room/share-trade-dialog/share-trade-dialog.component';

const materialModules = [MatIconModule, MatTableModule, MatFormFieldModule, MatButtonModule, MatProgressBarModule, MatSelectModule, MatSortModule, MatTooltipModule];
const pipes = [CurrencySymbolPipe, CoinDecimalPipe, HumanizeDurationPipe];
const components = [PaginationComponent];


@Component({
	selector: 'app-resolved-positions-table[groupedTrades]',
	standalone: true,
	imports: [CommonModule, ReactiveFormsModule, ...materialModules, ...pipes, ...components],
	templateUrl: './resolved-positions-table.component.html',
	styleUrl: './resolved-positions-table.component.scss',
})
export class ResolvedPositionsTableComponent implements OnChanges, OnInit, OnDestroy {
	@Input() groupedTrades: { [key: string]: TradeStats } = {}

	subscriptions: Subscription[] = [];
	columns: string[] = ['placedAt', 'position', 'entryPrice', 'exitPrice', 'cost', 'fees', 'resultType', 'pnl', 'resolvesAt', 'share'];

	state: State;
	loading: boolean = false;
	trades: SpotTrade[] = [];

	assets: SpotTradeAsset[] = [];
	filteredAssets: SpotTradeAsset[] = [];
	asset = new FormControl<number>(-1);

	TradePosition = TradePosition;
	ASSET_MAX_DECIMAL_PLACES = ASSET_MAX_DECIMAL_PLACES;

	currentPageIndex: number = 0;
	itemsPerPage: number = DEFAULT_PAGE_SIZE;
	totalItems: number = 0;

	constructor(private api: APIService, private matDialog: MatDialog, private marketService: MarketService, private stateService: StateService) {
		this.state = this.stateService.getState();
	}

	ngOnChanges(changes: SimpleChanges): void {
		if (changes && changes['groupedTrades'] && changes['groupedTrades'].currentValue != changes['groupedTrades'].previousValue) {
			this.filterAssets();
		}
	}

	ngOnInit(): void {
		const stateSub = this.stateService.state$.subscribe({
			next: (state: State) => {
				this.state = state;

				if (state.jwt != null) {
					this.getResolvedPositions();
				}
			},
		});
		this.subscriptions.push(stateSub);

		const assetsSub = this.marketService.assets$.subscribe((assets) => {
			if (assets.length != this.assets.length) {
				this.assets = assets.sort(assetsSortByName);
				this.filterAssets();
			}
		});
		this.subscriptions.push(assetsSub);
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	filterAssets() {
		const tokens = Object.keys(this.groupedTrades);
		this.filteredAssets = this.assets.filter(a => tokens.includes(a.token));

		if (this.filteredAssets.length > 0) {
			this.asset.setValue(this.filteredAssets[0].id);
			this.onAssetChange();
		}
	}

	getResolvedPositions() {
		if (this.asset.value && this.asset.value > 0) {
			this.loading = true;
			const currencyId = this.state.currencies.find(c => c.symbol === SupportedCoin[this.state.coin])?.id || -1;

			this.api.getSpotTrades({ assetId: this.asset.value, page: this.currentPageIndex, size: this.itemsPerPage, currencyId, tradeStatus: SpotTradeStatus.Closed }).subscribe({
				next: (res) => {
					if (res.success) {
						this.trades = res.body.content;
						this.totalItems = res.body.page.totalElements;
					}

					this.loading = false;
				},
				error: () => {
					this.loading = false;
				}
			});
		}
	}

	hasPassed(date: string): boolean {
		return hasPassed(date);
	}

	shareTrade(trade: SpotTrade) {
		this.matDialog.open(ShareTradeDialogComponent, {
			width: '348px',
			data: {
				trade: trade
			},
			panelClass: 'share-trade-dialog'
		});
	}

	onPageChange(event: PageEvent) {
		this.currentPageIndex = event.pageIndex;
		this.itemsPerPage = event.pageSize;
		this.getResolvedPositions();
	}

	onAssetChange() {
		this.currentPageIndex = 0;
		this.itemsPerPage = DEFAULT_PAGE_SIZE;
		this.getResolvedPositions();
	}
}
