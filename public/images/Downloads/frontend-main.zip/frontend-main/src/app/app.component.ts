import { CommonModule } from '@angular/common';
import { Component, OnDestroy } from '@angular/core';
import { MatIconModule, MatIconRegistry } from '@angular/material/icon';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { Subject, takeUntil } from 'rxjs';
import { NavbarComponent } from 'src/components/navbar/navbar.component';
import { LOG_IN } from 'src/constants/ui.routes';
import { environment } from 'src/environment/environment';
import { StateService } from 'src/service/state.service';

const materialModules = [MatIconModule];
const components = [NavbarComponent];
@Component({
	selector: 'app-root',
	standalone: true,
	imports: [CommonModule, ...materialModules, ...components],
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnDestroy {
	private destroy$ = new Subject<void>();
	state = this.stateService.getState();
	underMaintenance = environment.underMaintenance;
	idleState = 'Not started.';
	timedOut = false;

	private idleDuration = 60 * 5; // 5 minutes
	private timeOutDuration = 10; // 10 seconds

	constructor(
		private stateService: StateService,
		private iconRegistry: MatIconRegistry,
		private idle: Idle
	) {
		this.iconRegistry.setDefaultFontSetClass('material-symbols-outlined');
		this.initializeIdleSettings();
		this.subscribeToState();
	}

	private initializeIdleSettings(): void {
		this.idle.setIdle(this.idleDuration - this.timeOutDuration);
		this.idle.setTimeout(this.timeOutDuration);
		this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

		this.idle.onInterrupt.subscribe(() => this.resetIdle());
		this.idle.onIdleEnd.subscribe(() => this.handleIdleEnd());
		this.idle.onTimeout.subscribe(() => this.handleTimeout());
		this.idle.onIdleStart.subscribe(() => this.updateIdleState('You\'ve gone idle!'));
		this.idle.onTimeoutWarning.subscribe(countdown => this.updateIdleState(`You will time out in ${countdown} seconds!`));
	}

	private subscribeToState(): void {
		this.stateService.state$
			.pipe(takeUntil(this.destroy$))
			.subscribe(state => {
				if (state.jwt) {
					this.state = state;
					this.resetIdle();
				} else {
					this.idle.stop();
				}
			});
	}

	private resetIdle(): void {
		this.idle.watch();
		this.timedOut = false;
	}

	private handleIdleEnd(): void {
		this.updateIdleState('No longer idle.');
		this.resetIdle();
	}

	private handleTimeout(): void {
		this.updateIdleState('Timed out!');
		this.timedOut = true;

		if (this.stateService.getState().jwt) {
			this.stateService.onLogout([LOG_IN]);
		}
	}

	private updateIdleState(message: string): void {
		this.idleState = message;
		console.log(this.idleState);
	}

	ngOnDestroy(): void {
		this.destroy$.next();
		this.destroy$.complete();
	}
}
