import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { SafeUrl } from '@angular/platform-browser';
import { Subscription } from 'rxjs';
import { AvatarPreviewComponent } from 'src/components/avatar-preview/avatar-preview.component';
import { DialogComponent } from 'src/components/dialog/dialog.component';
import { ProfileImageDialogComponent } from 'src/components/profile-image-dialog/profile-image-dialog.component';
import { getMatDialogConfig } from 'src/constants/constants';
import { MARKETS } from 'src/constants/ui.routes';
import { APIService } from 'src/service/api.service';
import { StateService } from 'src/service/state.service';
import { APIResponse, Profile, State } from 'src/types/app.types';

const materialModules = [MatDialogModule, MatFormFieldModule, MatIconModule, MatInputModule, MatButtonModule];
const components = [AvatarPreviewComponent];

@Component({
	selector: 'app-edit-profile',
	standalone: true,
	imports: [CommonModule, ReactiveFormsModule, ...materialModules, ...components],
	templateUrl: './edit-profile.component.html',
	styleUrls: ['./edit-profile.component.scss'],
})
export class EditProfileComponent implements OnInit, OnDestroy {
	state: State;
	stateSub!: Subscription;
	loading: boolean = false;

	editProfileForm: FormGroup = new FormGroup({
		firstName: new FormControl<string>('', [Validators.required]),
		lastName: new FormControl<string>('', [Validators.required]),
		name: new FormControl<string>('', [Validators.required]),
		avatar: new FormControl<string>(''),
		removeAvatar: new FormControl<boolean>(false),
		email: new FormControl<string>({ value: '', disabled: true }, [
			Validators.required,
		]),
	});

	file: File | undefined;

	constructor(
		private stateService: StateService,
		private api: APIService,
		private matDialog: MatDialog
	) {
		this.state = this.stateService.getState();
	}

	ngOnInit(): void {
		this.stateSub = this.stateService.state$.subscribe({
			next: (state: State) => {
				this.state = state;
				this.editProfileForm.patchValue({
					email: this.state.user?.email,
					name: this.state.user?.profile?.name,
					firstName: this.state.user?.profile?.firstName,
					lastName: this.state.user?.profile?.lastName,
					avatar: this.state.user?.profile?.avatar,
				});
			},
		});
	}

	ngOnDestroy(): void {
		if (this.stateSub) {
			this.stateSub.unsubscribe();
		}
	}
	getDisplayError(formControlName: string): string {
		if (this.editProfileForm.untouched) {
			return '';
		}
		if (
			this.editProfileForm.controls[formControlName].hasError('required')
		) {
			return `This field is required`;
		}
		if (this.editProfileForm.controls[formControlName].hasError('email')) {
			return `Enter a valid email address`;
		}
		return '';
	}

	saveProfile() {
		if (this.editProfileForm.valid && !this.loading) {
			this.loading = true;

			const { name, email, firstName, lastName, removeAvatar } = this.editProfileForm.value;
			const formData = new FormData();
			formData.append("name", name);
			formData.append("email", email);
			formData.append("firstName", firstName);
			formData.append("lastName", lastName);
			formData.append("removeAvatar", removeAvatar);

			if (this.file) {
				formData.append("file", this.file);
			}

			this.api.saveProfile(formData).subscribe({
				next: (response: APIResponse<Profile>) => {
					if (response.success) {
						this.stateService.fetchUser();
						this.matDialog.open(
							DialogComponent,
							getMatDialogConfig({
								success: true,
								title: 'Profile Updated',
								message: 'Changes have been saved successfully',
								redirect: MARKETS,
							})
						);
					} else {
						this.matDialog.open(
							DialogComponent,
							getMatDialogConfig({
								success: false,
								title: 'Profile Not Updated',
								message: 'Something went wrong, please try again',
							})
						);
					}
					this.loading = false;
				},
				error: () => {
					this.loading = false;
					this.matDialog.open(
						DialogComponent,
						getMatDialogConfig({
							success: false,
							title: 'Profile Not Updated',
							message: 'Something went wrong, please try again',
						})
					);
				},
			});
		} else {
			this.editProfileForm.markAllAsTouched();
		}
	}

	onEditAvatarClicked(): void {
		const dialogRef = this.matDialog.open(ProfileImageDialogComponent, {
			width: "50%",
			disableClose: true
		});

		dialogRef.afterClosed().subscribe((event: { blob: Blob | null | undefined, url: SafeUrl }) => {
			if (event) {

				if (event.blob) {
					this.file = new File([event.blob], this.state.user?.address + '.png', { type: 'application/image' });
				} else {
					this.file = undefined;
				}

				if (event.url) {
					this.editProfileForm.get('avatar')?.setValue(event.url);
					this.editProfileForm.get('removeAvatar')?.setValue(false);
					this.editProfileForm.updateValueAndValidity();
				}
			}

		});
	}

	removeAvatar() {
		this.editProfileForm.get('avatar')?.setValue("");
		this.editProfileForm.get('removeAvatar')?.setValue(true);
		this.editProfileForm.updateValueAndValidity();
	}
}
