import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { DialogComponent } from 'src/components/dialog/dialog.component';
import { getMatDialogConfig } from 'src/constants/constants';
import { ONBOARDING } from 'src/constants/ui.routes';
import { APIService } from 'src/service/api.service';
import { StateService } from 'src/service/state.service';
import { APIResponse, Profile, State } from 'src/types/app.types';

const materialModules = [MatDialogModule, MatFormFieldModule, MatIconModule, MatInputModule, MatButtonModule];

@Component({
	selector: 'app-profile-details',
	standalone: true,
	imports: [CommonModule, ReactiveFormsModule, ...materialModules,],
	templateUrl: './profile-details.component.html',
	styleUrls: ['./profile-details.component.scss'],
})
export class ProfileDetailsComponent implements OnInit, OnDestroy {
	state: State;
	stateSub!: Subscription;
	loading: boolean = false;
	isEmailExist: boolean = false;

	profileDetailsForm: FormGroup = new FormGroup({
		name: new FormControl<string>('', [Validators.required]),
		email: new FormControl<string>('', [
			Validators.required,
			Validators.email,
		]),
	});

	dialogSubscription!: Subscription;

	constructor(
		private stateService: StateService,
		private api: APIService,
		private matDialog: MatDialog,
		private activatedRoute: ActivatedRoute,
		private router: Router
	) {
		this.state = this.stateService.getState();
	}

	ngOnInit(): void {
		this.stateSub = this.stateService.state$.subscribe({
			next: (state: State) => {
				this.state = state;
				this.isEmailExist = this.state.user && this.state.user.email ? true : false;
				if (this.isEmailExist) {
					this.profileDetailsForm.controls['email'].disable();
				} else {
					this.profileDetailsForm.controls['email'].enable();
				}
				this.profileDetailsForm.patchValue({
					email: this.state.user?.email,
					name: this.state.user?.profile?.name,
				});
			},
		});
	}

	ngOnDestroy(): void {
		if (this.stateSub) {
			this.stateSub.unsubscribe();
		}
	}

	getDisplayError(formControlName: string): string {
		if (this.profileDetailsForm.untouched) {
			return '';
		}
		if (
			this.profileDetailsForm.controls[formControlName].hasError(
				'required'
			)
		) {
			return `This field is required`;
		}
		if (
			this.profileDetailsForm.controls[formControlName].hasError('email')
		) {
			return `Enter a valid email address`;
		}
		return '';
	}

	saveProfile() {
		if (
			this.profileDetailsForm.controls['name'].value != undefined &&
			this.profileDetailsForm.controls['name'].value.trim() !== '' &&
			this.profileDetailsForm.controls['email'].value != undefined &&
			this.profileDetailsForm.controls['email'].value.trim() !== '' &&
			!this.loading
		) {
			this.loading = true;

			const formData = new FormData();
			formData.append("name", this.profileDetailsForm.controls['name'].value.trim());

			this.api.saveProfile(formData).subscribe({
				next: (response: APIResponse<Profile>) => {
					if (response.success) {
						this.stateService.refreshUserBalanceCurrency(false);
						this.loading = false;
						this.stateService.switchModeViaQueryParams(this.activatedRoute.snapshot.queryParams);
						this.router.navigate([this.activatedRoute.snapshot.queryParams['redirectUri'] || ONBOARDING], { replaceUrl: true, state: { showKYC: true } });
					} else {
						this.matDialog.open(
							DialogComponent,
							getMatDialogConfig({
								success: false,
								title: 'Profile Details Not Saved',
								message:
									'Something went wrong, please try again',
							})
						);
					}
				},
				error: () => {
					this.loading = false;
					this.matDialog.open(
						DialogComponent,
						getMatDialogConfig({
							success: false,
							title: 'Profile Details Not Saved',
							message:
								'Something went wrong, please try again',
						})
					);
				},
			});
		}
	}
}
