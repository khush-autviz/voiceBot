import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnDestroy } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import Decimal from 'decimal.js';
import { Subscription } from 'rxjs';
import { CurrencySymbolPipe } from 'src/pipes/currency-symbol.pipe';
import { APIService } from 'src/service/api.service';
import { StateService } from 'src/service/state.service';
import { APIResponse, Balance, State, SupportedCoin } from 'src/types/app.types';

const materialModules = [MatIconModule];
const pipes = [CurrencySymbolPipe];

@Component({
	selector: 'app-balance',
	standalone: true,
	imports: [CommonModule, ...materialModules, ...pipes],
	templateUrl: './balance.component.html',
	styleUrls: ['./balance.component.scss']
})
export class BalanceComponent implements OnDestroy {

	balance: Balance[] = [];
	mainnetToken: Balance | undefined = undefined;
	loading: boolean = true;
	error: string = '';
	state: State;
	stateSub: Subscription;
	usdtDecimals: number = 0;

	SupportedCoin = SupportedCoin;

	constructor(private api: APIService, private stateService: StateService, private matDialog: MatDialog) {
		this.state = this.stateService.getState();
		this.stateSub = this.stateService.state$.subscribe({
			next: (state: State) => {
				this.state = state;
			}
		});
		this.sync();
	}

	getDisplayBalance(balance: number | null, decimals: number | null): string {
		if (balance === null || decimals === null) {
			return '0';
		}
		const balanceDecimal = new Decimal(balance);
		return balanceDecimal.dividedBy(Math.pow(10, decimals)).toString();
	}

	sync() {
		this.loading = true;
		this.api.getBalance().subscribe({
			next: (response: APIResponse<Balance[]>) => {
				if (response.success) {
					const excludeSymbols = ['MAINNET_TOKEN', 'SUS'];
					this.balance = response.body.filter((b) => !excludeSymbols.includes(b.symbol));

					if (this.state.user?.affiliate) {
						this.balance = this.balance.filter(b => b.symbol !== 'USDT').map(b => {
							if (b.symbol === 'DEMO_USDT') {
								b.name = "Real Account";
								b.priority = 1;
							}

							if (b.symbol === 'BONUS_USDT') {
								b.name = "Bonus";
								b.priority = 2;
							}
							return b;
						});
					} else {
						this.balance = this.balance.filter(b => b.symbol !== 'DEMO_USDT').map(b => {
							if (b.symbol === 'USDT') {
								b.name = "Real Account";
								b.priority = 1;
							}

							if (b.symbol === 'BONUS_USDT') {
								b.name = "Bonus";
								b.priority = 2;
							}
							return b;
						});
					}

					this.mainnetToken = response.body.find(b => b.symbol === 'MAINNET_TOKEN');
					this.usdtDecimals = response.body.find(b => b.symbol === 'USDT')?.decimals || 0;

					this.balance.sort((a, b) => {
						if (a.priority != undefined && b.priority != undefined) {
							return a.priority - b.priority;
						}
						return -1;
					});


				} else {
					this.error = response.body.toString();
				}
				this.loading = false;
			},
			error: (err: HttpErrorResponse) => {
				this.error = err.message;
				this.loading = false;
			},
			complete: () => {
				this.loading = false;
			}
		});
	}

	ngOnDestroy(): void {
		this.stateSub.unsubscribe();
	}

	getTokenCoin(token: Balance) {
		return SupportedCoin[token.symbol as keyof typeof SupportedCoin];
	}
}
