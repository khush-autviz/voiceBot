import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { FUTURES, KYC, MARKETS, ONBOARDING } from 'src/constants/ui.routes';
import { StateService } from 'src/service/state.service';
import { SolusMode, SupportedCoin } from 'src/types/app.types';

const materialModules = [MatCardModule, MatIconModule, MatButtonModule];

@Component({
	selector: 'app-choose-product',
	standalone: true,
	imports: [CommonModule, ...materialModules],
	templateUrl: './choose-product.component.html',
	styleUrls: ['./choose-product.component.scss'],
})
export class ChooseProductComponent {

	SolusMode = SolusMode;
	SupportedCoin = SupportedCoin;

	showKYC = false;
	featuresOnKYC = ["Deposit", "Place Order", "Earn Profits", "Withdrawal"];

	constructor(private stateService: StateService, private title: Title, private router: Router) {
		this.title.setTitle('Choose Product / Solus');

		const showKYC = this.router.getCurrentNavigation()?.extras.state?.["showKYC"];

		if (showKYC) {
			this.showKYC = showKYC;
			this.router.navigate([ONBOARDING], { state: undefined });
		}
	}

	changeMode(mode: SolusMode, coin: SupportedCoin): void {
		this.stateService.swichMode(mode, coin);
		this.router.navigate([[mode === SolusMode.FUTURES ? FUTURES : "", MARKETS].join("/")]);
	}

	completeKYC() {
		this.router.navigate([KYC]);
	}

	startOnboarding() {
		this.showKYC = false;
	}
}
