import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { ONBOARDING } from 'src/constants/ui.routes';
import { environment } from 'src/environment/environment';
import { StateService } from 'src/service/state.service';
import { State } from 'src/types/app.types';

const materialModules = [MatCardModule, MatButtonModule];

@Component({
	selector: 'app-link-discord',
	standalone: true,
	imports: [CommonModule, ...materialModules],
	templateUrl: './link-discord.component.html',
	styleUrls: ['./link-discord.component.scss'],
})
export class LinkDiscordComponent implements OnInit, OnDestroy {

	state: State;
	stateSub!: Subscription;

	constructor(private stateService: StateService, private router: Router) {
		this.state = stateService.getState();
	}

	ngOnInit(): void {
		this.stateSub = this.stateService.state$.subscribe({
			next: (state: State) => {
				this.state = state;
			},
		});
	}

	ngOnDestroy(): void {
		this.stateSub.unsubscribe();
	}

	onLinkDiscord(): void {
		window.open(environment.discord, '_blank');
	}

	navigateToNextStep(): void {
		this.router.navigate([ONBOARDING]);
	}

}
