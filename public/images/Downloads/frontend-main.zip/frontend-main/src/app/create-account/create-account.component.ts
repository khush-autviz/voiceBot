import { CommonModule } from '@angular/common';
import { HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Component, OnDestroy, ViewEncapsulation } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { ReCaptchaV3Service } from 'ng-recaptcha';
import { Subscription } from 'rxjs';
import { DialogComponent } from 'src/components/dialog/dialog.component';
import { JWT, REJECTED_EMAIL_DOMAINS_REGEX, getMatDialogConfig, recapthcaConfig } from 'src/constants/constants';
import { LOG_IN, PROFILE_DETAILS } from 'src/constants/ui.routes';
import { environment } from 'src/environment/environment';
import { APIService } from 'src/service/api.service';
import { StateService } from 'src/service/state.service';
import { APIResponse, CreateAccountRequest, JustPassword, JwtResponse, SendOTPResponse } from 'src/types/app.types';

const materialModules = [MatDialogModule, MatFormFieldModule, MatIconModule, MatInputModule, MatButtonModule, MatCheckboxModule];


@Component({
	selector: 'app-create-account',
	standalone: true,
	imports: [...materialModules, CommonModule, ReactiveFormsModule,],
	templateUrl: './create-account.component.html',
	styleUrls: ['./create-account.component.scss'],
	encapsulation: ViewEncapsulation.None
})
export class CreateAccountComponent implements OnDestroy {

	recaptchaError: boolean = false;
	hidePassword: boolean = true;
	waitingForOtp: boolean = false;
	jwtResponse!: JwtResponse;
	paramMapSub: Subscription;
	queryParamMapSub: Subscription;
	displayedMessage: boolean = false;
	termsAndPrivacyControl = new FormControl<boolean>(true, [Validators.requiredTrue]);

	createAccountStage: 'ENTER_EMAIL' | 'ENTER_OTP' | 'SET_PASSWORD' = 'ENTER_EMAIL';

	loginForm: FormGroup = new FormGroup({
		email: new FormControl<string>('', [Validators.required, Validators.email]),
		otp: new FormControl<string>('', [Validators.required]),
		password: new FormControl<string>('', [Validators.required]),
		confirmPassword: new FormControl<string>('', [Validators.required]),
		recaptcha: new FormControl<string>('', [Validators.required]),
		referralCode: new FormControl<string>(''),
		partner: new FormControl<string>(''),
		metadata: new FormControl<string>(''),
		platform: new FormControl<string>(''),
		clickId: new FormControl<string>(''),
		siteId: new FormControl<string>(''),
	});

	constructor(private api: APIService, private recaptchaService: ReCaptchaV3Service, private router: Router, private matDialog: MatDialog, private stateService: StateService, private activatedRoute: ActivatedRoute) {
		this.paramMapSub = this.activatedRoute.paramMap.subscribe({
			next: (paramMap: ParamMap) => {
				this.loginForm.controls['referralCode'].setValue(paramMap.get('referral-code'));

				const referralCode = paramMap.get('referral-code');
				if (referralCode != null) {
					this.api.updateAffiliateClickCount(referralCode).subscribe();
				}
			}
		});

		this.queryParamMapSub = this.activatedRoute.queryParamMap.subscribe({
			next: (paramMap: ParamMap) => {
				this.loginForm.controls['partner'].setValue(paramMap.get('partner'));
				this.loginForm.controls['platform'].setValue(paramMap.get('platform'));

				// Create an object to store non-null values
				const queryParams: any = {};

				const timestamp = paramMap.get('timestamp');
				const deviceType = paramMap.get('device_type');
				const browserName = paramMap.get('browser_name');
				const osName = paramMap.get('os_name');
				const osVersion = paramMap.get('os_version');
				const httpCountryCode = paramMap.get('http_country_code');
				const httpAcceptLanguage = paramMap.get('http_accept_language');
				const ipAddress = paramMap.get('ip_address');
				const adUnit = paramMap.get('ad_unit');
				const bannerSize = paramMap.get('banner_size');

				// Add non-null values to the queryParams object
				if (timestamp !== null) queryParams.timestamp = timestamp;
				if (deviceType !== null) queryParams.device_type = deviceType;
				if (browserName !== null) queryParams.browser_name = browserName;
				if (osName !== null) queryParams.os_name = osName;
				if (osVersion !== null) queryParams.os_version = osVersion;
				if (httpCountryCode !== null) queryParams.http_country_code = httpCountryCode;
				if (httpAcceptLanguage !== null) queryParams.http_accept_language = httpAcceptLanguage;
				if (ipAddress !== null) queryParams.ip_address = ipAddress;
				if (adUnit !== null) queryParams.ad_unit = adUnit;
				if (bannerSize !== null) queryParams.banner_size = bannerSize;

				// Convert the object to a JSON string
				const metadata = JSON.stringify(queryParams);

				this.loginForm.controls['metadata'].setValue(metadata);


				// Affiliate Postback Parameters
				const clickId = paramMap.get('click_id');
				const siteId = paramMap.get('site_id');

				if (clickId !== null) this.loginForm.controls['clickId'].setValue(clickId);
				if (siteId !== null) this.loginForm.controls['siteId'].setValue(siteId);
			}
		});

	}

	get referralCode() {
		return this.loginForm.controls['referralCode'].value;
	}

	doSendOTP() {
		if (!this.isTermsAndPrivacyChecked()) return;

		const email = this.loginForm.controls['email'].value;

		if (REJECTED_EMAIL_DOMAINS_REGEX.test(email)) {
			this.matDialog.open(DialogComponent, getMatDialogConfig({
				success: false,
				title: 'Invalid Email',
				message: 'This email is not allowed. Please try again with a valid email address!',
			}));
			return;
		}

		this.displayedMessage = true;
		this.waitingForOtp = true;
		this.loginForm.controls['email'].disable();
		this.loginForm.controls['referralCode'].disable();
		this.recaptchaService.execute('email_send_otp').subscribe({
			next: (token: string) => {
				const request: CreateAccountRequest = {
					emailAddress: this.loginForm.controls['email'].value,
					otp: 0,
					recaptcha: token,
					referralCode: this.loginForm.controls['referralCode'].value,
					partner: this.loginForm.controls['partner'].value,
					platform: this.loginForm.controls['platform'].value,
					metadata: this.loginForm.controls['metadata'].value,
					clickId: this.loginForm.controls['clickId'].value,
					siteId: this.loginForm.controls['siteId'].value,
				};
				this.api.sendOTP(request).subscribe({
					next: (response: APIResponse<SendOTPResponse>) => {
						const status: SendOTPResponse = response.body;
						if (status.otpRequired) {
							if (status.otpSent) {
								this.createAccountStage = 'ENTER_OTP';
							}
							else {
								this.createAccountStage = 'ENTER_EMAIL';
								this.loginForm.controls['email'].enable();
								this.matDialog.open(DialogComponent, getMatDialogConfig({
									success: false,
									title: 'OTP Not Sent',
									message: 'Could Not Send OTP because of internal server error. Please try again after some time',
								}));
							}
						}
						else {
							this.matDialog.open(DialogComponent, getMatDialogConfig({
								success: false,
								title: 'Please Log In',
								message: request.emailAddress + ' can not be used to sign up as a Solus account already exists with this email address.',
								redirect: LOG_IN
							}));
						}
						this.waitingForOtp = false;
					},
					error: (error: HttpErrorResponse) => {
						this.loginForm.controls['email'].enable();
						this.matDialog.open(DialogComponent, getMatDialogConfig({
							success: false,
							title: 'OTP Not Sent',
							message: error.error || error.error.message
						}));
						this.waitingForOtp = false;
					}
				})
			},
			error: () => {
				this.recaptchaError = true;
				this.matDialog.open(DialogComponent, recapthcaConfig());
				this.waitingForOtp = false;
			}
		});

	}

	doVerifyOTP() {
		if (!this.isTermsAndPrivacyChecked()) return;

		this.displayedMessage = false;
		this.loginForm.controls['email'].disable();
		this.loginForm.controls['otp'].disable();
		this.waitingForOtp = true;
		this.recaptchaService.execute('email_verify_otp').subscribe({
			next: (token: string) => {
				const request: CreateAccountRequest = {
					emailAddress: this.loginForm.controls['email'].value,
					otp: this.loginForm.controls['otp'].value,
					recaptcha: token,
					referralCode: this.loginForm.controls['referralCode'].value,
					partner: this.loginForm.controls['partner'].value,
					platform: this.loginForm.controls['platform'].value,
					metadata: this.loginForm.controls['metadata'].value,
					clickId: this.loginForm.controls['clickId'].value,
					siteId: this.loginForm.controls['siteId'].value,
				}
				this.api.verifyOTP(request).subscribe({
					next: (response: APIResponse<JwtResponse>) => {
						if (response.success) {
							this.waitingForOtp = false;
							this.createAccountStage = 'SET_PASSWORD';
							this.jwtResponse = response.body;
						}
						else {
							this.waitingForOtp = false;
							this.createAccountStage = 'ENTER_EMAIL';
							this.loginForm.controls['otp'].enable();
							this.loginForm.controls['otp'].setValue('');
							this.matDialog.open(DialogComponent, getMatDialogConfig({
								success: false,
								title: 'OTP Not Verified',
								message: new String(response.body).toString()
							}))
						}
					},
					error: (error: HttpErrorResponse) => {
						this.waitingForOtp = false;
						this.createAccountStage = 'ENTER_EMAIL';
						this.loginForm.controls['otp'].enable();
						this.loginForm.controls['otp'].setValue('');
						this.matDialog.open(DialogComponent, getMatDialogConfig({
							success: false,
							title: 'OTP Not Verified',
							message: error.error || error.error.body || error.message
						}));
					}
				});
			},
			error: () => {
				this.matDialog.open(DialogComponent, recapthcaConfig());
				this.waitingForOtp = false;
				this.createAccountStage = 'ENTER_EMAIL';
				this.loginForm.controls['otp'].enable();
				this.loginForm.controls['otp'].setValue('');
			}
		})

	}

	doCreateAccount() {
		if (!this.isTermsAndPrivacyChecked()) return;

		this.displayedMessage = false;
		if (this.loginForm.controls['password'].value === this.loginForm.controls['confirmPassword'].value) {
			this.waitingForOtp = true;
			this.loginForm.controls['password'].disable();
			this.loginForm.controls['confirmPassword'].disable();
			this.recaptchaService.execute('change_password').subscribe({
				next: (token: string) => {
					const request: JustPassword = {
						password: this.loginForm.controls['confirmPassword'].value,
						recaptcha: token
					};
					localStorage.setItem(JWT, this.jwtResponse?.token);
					this.api.setPassword(request).subscribe({
						next: (response: APIResponse<boolean>) => {
							if (response.success) {
								this.stateService.onLogin(this.jwtResponse?.token || '', PROFILE_DETAILS);
							}
							else {
								localStorage.removeItem(JWT);
								this.waitingForOtp = false;
								this.loginForm.controls['password'].enable();
								this.loginForm.controls['confirmPassword'].enable();
								this.matDialog.open(DialogComponent, getMatDialogConfig({
									success: true,
									title: 'Failed',
									message: 'Could not set password, please try again'
								}));
							}
						},
						error: (error: HttpErrorResponse) => {
							localStorage.removeItem(JWT);
							this.waitingForOtp = false;
							this.loginForm.controls['password'].enable();
							this.loginForm.controls['confirmPassword'].enable();
							this.matDialog.open(DialogComponent, getMatDialogConfig({
								success: false,
								title: 'Failed',
								message: error.error || error.message
							}));
						}
					})
				},
				error: () => {
					this.matDialog.open(DialogComponent, recapthcaConfig());
					this.loginForm.controls['password'].enable();
					this.loginForm.controls['confirmPassword'].enable();
					this.waitingForOtp = false;
				}
			})
		}
		else {
			this.matDialog.open(DialogComponent, getMatDialogConfig({
				success: false,
				title: 'Invalid',
				message: 'Passwords Do Not Match'
			}))
		}
	}

	onLogin() {
		this.router.navigate([LOG_IN], { queryParamsHandling: 'merge' });
	}

	ngOnDestroy(): void {
		this.paramMapSub.unsubscribe();
		this.queryParamMapSub.unsubscribe();
	}

	onLoginWithGoogle() {
		if (!this.isTermsAndPrivacyChecked()) return;

		const referralCode = this.loginForm.controls['referralCode'].value;

		const params = new HttpParams({ fromObject: { ...this.activatedRoute.snapshot.queryParams , referralCode} });

		window.open(environment.google + "&state=" + encodeURIComponent(params.toString()), "_self");
	}

	isTermsAndPrivacyChecked() {
		return this.termsAndPrivacyControl.value === true;
	}

}
