import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialog } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTableModule } from '@angular/material/table';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { ChartData, ChartOptions, Plugin } from 'chart.js';
import * as moment from 'moment';
import { BaseChartDirective, NgChartsModule } from 'ng2-charts';
import { Subscription } from 'rxjs';
import { CRYPTO, MARKETS } from 'src/constants/ui.routes';
import { CoinDecimalPipe } from 'src/pipes/coin-decimal.pipe';
import { CurrencySymbolPipe } from 'src/pipes/currency-symbol.pipe';
import { APIService } from 'src/service/api.service';
import { StateService } from 'src/service/state.service';
import { OverAllPortfolio, PortfolioCombinedRequest, PortfolioPieChartData, SpotTradeAssetView, SpotTradePortfolioView, SpotTradeStatus, State, SupportedCoin, TradeStats } from 'src/types/app.types';
import { ResolvedPositionsTableComponent } from '../resolved-positions-table/resolved-positions-table.component';

const materialModules = [MatIconModule, MatCardModule, MatTableModule, MatFormFieldModule, MatDatepickerModule, MatNativeDateModule, MatButtonModule, MatProgressBarModule, MatProgressSpinnerModule, MatDividerModule];
const pipes = [CurrencySymbolPipe, CoinDecimalPipe];
const components = [ResolvedPositionsTableComponent];


@Component({
	selector: 'app-portfolio',
	standalone: true,
	imports: [CommonModule, ReactiveFormsModule, NgChartsModule, ...materialModules, ...pipes, ...components],
	templateUrl: './portfolio.component.html',
	styleUrls: ['./portfolio.component.scss'],
	encapsulation: ViewEncapsulation.None
})
export class PortfolioComponent implements OnInit, OnDestroy {
	COLORS = ['#ff9900', '#ffff00', '#8cc63f', '#39b54a', '#36cca5', '#000099', '#660099', '#cc0099', '#cc0066', '#6666ff', '#85ffff', '#ff6600', '#ffcc00', '#66cc33', '#33cc66', '#33cccc', '#003366', '#993399', '#cc3366', '#ff6699', '#3399ff', '#66ffff'];

	state: State;
	stateSub!: Subscription;
	loading: number = 0;
	groupedTrades: { [key: string]: TradeStats } = {};
	spotTradePortfolioView: SpotTradePortfolioView[] = [];
	spotTradeAssetView: SpotTradeAssetView[] = [];
	showOverallPortfolio: boolean = true;
	overallPortfolio: OverAllPortfolio | undefined = undefined;

	SupportedCoin = SupportedCoin;

	// Portfolio Distribution Doughnut Chart
	public doughnutChartData: ChartData<'doughnut', PortfolioPieChartData[]> = {
		labels: [],
		datasets: [{
			label: 'Invested',
			data: [],
			borderWidth: 0
		}],
	};
	public doughnutChartOptions: ChartOptions<'doughnut'> = {
		animation: { duration: 0 },
		responsive: true,
		maintainAspectRatio: false,
		cutout: '20%',
		parsing: {
			key: 'investedPercentage'
		},
		plugins: {
			tooltip: {
				callbacks: {
					title: (ctx): string => {
						return ctx[0].chart.data.labels?.[ctx[0].dataIndex] as string;
					},
					label: (ctx): string => {
						const data = ctx.chart.data.datasets[0].data?.[ctx.dataIndex] as any;

						return `Invested: $${data?.['invested'] || 0} (${data?.['investedPercentage'] || 0}%)`;
					},
					afterLabel: (ctx): string => {
						return `P&L: $${(ctx.chart.data.datasets[0].data?.[ctx.dataIndex] as any)?.['returns'] || 0}`;
					}
				},
				backgroundColor: '#fff',
				titleColor: '#000',
				bodyColor: '#000',
				displayColors: false
			},
			legend: {
				position: 'bottom',
				onHover: (e, legendItem, legend) => {
					(legend.chart.data.datasets[0].backgroundColor as string[])?.forEach((color: string, index: number, colors: string[]) => {
						colors[index] = index === legendItem.index || color.length === 9 ? color : color + '4D';
					});
					legend.chart.update();

				},
				onLeave: (e, legendItem, legend) => {
					(legend.chart.data.datasets[0].backgroundColor as string[])?.forEach((color, index, colors) => {
						colors[index] = color.length === 9 ? color.slice(0, -2) : color;
					});
					legend.chart.update();
				},
			}
		}
	};

	public doughnutChartPlugins: Plugin<'doughnut'>[] = [
		{
			id: 'legendColor',
			beforeDraw: (c) => {
				const legends = c.legend?.legendItems || [];
				legends.forEach((l) => {
					l.fontColor = '#fff';
				});
			}
		}
	]

	@ViewChild(BaseChartDirective) chart?: BaseChartDirective;

	constructor(private api: APIService, private stateService: StateService, title: Title, private matDialog: MatDialog, private decimalPipe: CoinDecimalPipe, private router: Router, private cdRef: ChangeDetectorRef) {
		title.setTitle('Portfolio / Solus');
		this.state = this.stateService.getState();
	}

	ngOnInit(): void {
		this.stateSub = this.stateService.state$.subscribe({
			next: (state: State) => {
				this.state = state;

				if (state.jwt != null) {
					this.getPortfolio();
				}
			}
		});
	}

	ngOnDestroy(): void {
		if (this.stateSub) {
			this.stateSub.unsubscribe();
		}
	}

	getInvestedAmount(trade: SpotTradeAssetView) {
		return trade.investedAmount;
	}

	getReturns(trade: SpotTradeAssetView) {
		return trade.pnl || 0;
	}

	updateChartOnThemeChange() {
		const length = this.doughnutChartData.datasets[0].data.length;
		if (length > 0) {
			this.doughnutChartData.datasets[0].backgroundColor = this.COLORS.slice(0, length);
			if (this.doughnutChartOptions.plugins?.tooltip) {
				this.doughnutChartOptions.plugins.tooltip.titleColor = '#a252bf';
			}
			this.chart?.render();
			this.cdRef.detectChanges();
		}
	}

	applyFilters(trades: SpotTradeAssetView[]) {
		this.groupedTrades = trades.reduce(
			(acc: { [key: string]: TradeStats }, current) => {
				if (!acc[current.token]) {
					acc[current.token] = {
						id: current.assetId,
						count: 0,
						invested: 0,
						returns: 0
					};
				}

				acc[current.token].count++;
				acc[current.token].invested += this.decimalPipe.transform(this.getInvestedAmount(current));
				acc[current.token].returns += this.decimalPipe.transform(this.getReturns(current));

				return acc;
			},
			{}
		);

		const labels = Object.keys(this.groupedTrades);
		const chartData: PortfolioPieChartData[] = Object.values(this.groupedTrades).map((obj, index) => ({
			label: labels[index],
			invested: obj.invested.toFixed(2),
			investedPercentage: ((obj.count / trades.length) * 100).toFixed(2),
			returns: obj.returns.toFixed(2),
			count: obj.count,
			id: obj.id
		})).sort((a, b) => Number(b.investedPercentage) - Number(a.investedPercentage));

		this.doughnutChartData.datasets[0].data = chartData;
		this.doughnutChartData.labels = chartData.map(row => row.label);

		this.updateChartOnThemeChange();
	}

	onTradeNowClick() {
		this.router.navigate([MARKETS]);
	}

	getPortfolio() {

		if (this.spotTradePortfolioView.length <= 0 && this.spotTradeAssetView.length <= 0) {
			this.loading = 1;
		}

		const dateFormat = 'yyyy-MM-DD HH:mm:ss';
		const startDate = moment.unix(0).format(dateFormat);
		const endDate = moment().format(dateFormat);
		const currencySymbol = SupportedCoin[this.state.coin];
		const mode = this.state.mode;

		const request: PortfolioCombinedRequest = {
			currencySymbol,
			solusMode: mode,
			start: startDate,
			end: endDate,
		}

		this.api.getPortfolioCombined(request).subscribe({
			next: (response) => {
				if (response.success) {
					this.overallPortfolio = response.body.overAllPortfolio;
					this.spotTradePortfolioView = response.body.spotTradePortfolio;
					this.spotTradeAssetView = response.body.assetPortfolio;
					this.applyFilters(this.spotTradeAssetView);
				}

				if (this.loading > 0) {
					this.loading--;
				}
			},
			error: () => {
				if (this.loading > 0) {
					this.loading--;
				}
			}
		});
	}

	get tradeCount() {
		return this.getSpotTradesCount();
	}

	get profitableTradesCount() {
		return this.getSpotTradesCount([SpotTradeStatus.Profit]);
	}

	get profitableTradesPercentage() {
		return this.profitableTradesCount / this.tradeCount * 100;
	}

	get tradesProfit() {
		return this.getSpotTradesProfit();
	}

	getBarColor(value: number, barIndex: number) {
		if (value > 50) return 'green';
		else if (value > 0 && (barIndex === 0 || barIndex === 1)) return 'yellow';
		else if (value < 0 && barIndex === 0) return 'red';
		return '';
	}

	getOverallEarnings() {
		return (this.overallPortfolio?.amountWithdrawn || 0) + (this.overallPortfolio?.withdrawableBalance || 0);
	}

	getNetEarnings() {
		return (this.getOverallEarnings() - (this.overallPortfolio?.amountDeposited || 0));
	}

	goToWallet() {
		this.router.navigate([CRYPTO]);
	}

	getSpotTradesCount(status: SpotTradeStatus[] = [SpotTradeStatus.Profit, SpotTradeStatus.Loss, SpotTradeStatus.Cancelled]) {
		let count = 0;

		this.spotTradePortfolioView.filter(v => status.includes(v.tradeStatus)).forEach((v) => {
			count += v.tradeCount;
		})

		return count;
	}

	getSpotTradesProfit() {
		let pnl = 0;

		this.spotTradePortfolioView.forEach((v) => {
			pnl += v.pnl;
		})

		return pnl;
	}
}
