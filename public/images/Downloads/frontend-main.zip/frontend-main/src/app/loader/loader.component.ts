import { CommonModule } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { LoaderData } from 'src/types/app.types';

const materialModules = [MatProgressSpinnerModule];

@Component({
	selector: 'app-loader',
	standalone: true,
	imports: [CommonModule, ...materialModules],
	templateUrl: './loader.component.html',
	styleUrls: ['./loader.component.scss']
})
export class LoaderComponent {

	constructor(public dialogRef: MatDialogRef<LoaderComponent>, @Inject(MAT_DIALOG_DATA) public data: LoaderData) {
	}

}
