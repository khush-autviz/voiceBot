import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit, Renderer2 } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatProgressBarModule } from '@angular/material/progress-bar';

@Component({
	selector: 'app-support',
	standalone: true,
	imports: [CommonModule, MatProgressBarModule, MatCardModule],
	templateUrl: './support.component.html',
	styleUrl: './support.component.scss'
})
export class SupportComponent implements OnInit, OnDestroy {
	private zammadScript!: HTMLScriptElement;
	private jQueryScript!: HTMLScriptElement;

	loading: boolean = false;

	constructor(private renderer: Renderer2) { }

	ngOnInit(): void {
		// Load jQuery dynamically
		this.loading = true;
		this.jQueryScript = this.renderer.createElement('script');
		this.jQueryScript.src = 'https://code.jquery.com/jquery-3.6.0.min.js';
		this.jQueryScript.onload = () => this.initializeZammad();
		this.renderer.appendChild(document.body, this.jQueryScript);
	}

	initializeZammad(): void {
		// Load Zammad script
		this.zammadScript = this.renderer.createElement('script');
		this.zammadScript.src = '/assets/js/form.js';
		this.zammadScript.onload = () => this.loading = false;
		this.renderer.appendChild(document.body, this.zammadScript);
	}

	ngOnDestroy(): void {
		// Clean up dynamically added scripts when the component is destroyed
		if (this.zammadScript) {
			this.renderer.removeChild(document.body, this.zammadScript);
		}
		if (this.jQueryScript) {
			this.renderer.removeChild(document.body, this.jQueryScript);
		}
	}
}
