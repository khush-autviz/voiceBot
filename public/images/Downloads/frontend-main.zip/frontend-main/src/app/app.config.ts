import { CurrencyPipe, DatePipe } from '@angular/common';
import { HTTP_INTERCEPTORS, provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { APP_INITIALIZER, ApplicationConfig, ErrorHandler, importProvidersFrom } from '@angular/core';
import { MatDialogModule } from '@angular/material/dialog';
import { MAT_FORM_FIELD_DEFAULT_OPTIONS } from '@angular/material/form-field';
import { MAT_SNACK_BAR_DEFAULT_OPTIONS, MatSnackBarModule } from '@angular/material/snack-bar';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { PreloadAllModules, Router, provideRouter, withPreloading } from '@angular/router';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import * as Sentry from "@sentry/angular-ivy";
import { RECAPTCHA_V3_SITE_KEY, RecaptchaV3Module } from 'ng-recaptcha';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { provideToastr } from 'ngx-toastr';
import { environment } from 'src/environment/environment';
import { GlobalErrorHandler } from 'src/error-handler/global-error-handler';
import { AuthGuard } from 'src/guards/auth.guard';
import { NotAuthGuard } from 'src/guards/not-auth.guard';
import { JwtInterceptor } from 'src/interceptor/jwt.interceptor';
import { CoinDecimalPipe } from 'src/pipes/coin-decimal.pipe';
import { CoinNamePipe } from 'src/pipes/coin-name.pipe';
import { routes } from 'src/routes/app.routes';

export const appConfig: ApplicationConfig = {
	providers: [
		provideRouter(routes, withPreloading(PreloadAllModules)),
		provideAnimationsAsync(),
		provideHttpClient(withInterceptorsFromDi()),
		provideToastr({
			positionClass: 'toast-bottom-left'
		}),
		importProvidersFrom(
			NgxSkeletonLoaderModule.forRoot({
				animation: 'pulse', loadingText: 'Loading...', theme: {
					extendsFromRoot: true,
					backgroundColor: "var(--gray)"
				},
			}),
			RecaptchaV3Module,
			MatDialogModule,
			MatSnackBarModule,
			NgIdleKeepaliveModule.forRoot()
		),
		CoinDecimalPipe,
		CurrencyPipe,
		CoinNamePipe,
		DatePipe,
		AuthGuard,
		NotAuthGuard,
		{
			provide: HTTP_INTERCEPTORS,
			useClass: JwtInterceptor,
			multi: true,
		},
		{
			provide: HTTP_INTERCEPTORS,
			useClass: GlobalErrorHandler,
			multi: true,
		},
		{
			provide: RECAPTCHA_V3_SITE_KEY,
			useValue: environment.recaptcha,
		},
		{
			provide: ErrorHandler,
			useValue: Sentry.createErrorHandler({
				showDialog: false,
			}),
		}, {
			provide: Sentry.TraceService,
			deps: [Router],
		},
		{
			provide: APP_INITIALIZER,
			useFactory: () => () => { },
			deps: [Sentry.TraceService],
			multi: true,
		},
		{
			provide: MAT_SNACK_BAR_DEFAULT_OPTIONS,
			useValue: {
				verticalPosition: 'bottom',
				horizontalPosition: 'center',
				duration: 2000
			}
		},
		{
			provide: MAT_FORM_FIELD_DEFAULT_OPTIONS,
			useValue: { appearance: 'outline' },
		},
	],
};
