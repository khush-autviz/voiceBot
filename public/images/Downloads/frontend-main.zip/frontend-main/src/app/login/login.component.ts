import { CommonModule } from '@angular/common';
import { HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Component, OnDestroy } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule, MatDialogRef, MatDialogState } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { ActivatedRoute, Router } from '@angular/router';
import { ReCaptchaV3Service } from 'ng-recaptcha';
import { DialogComponent } from 'src/components/dialog/dialog.component';
import { getMatDialogConfig, recapthcaConfig } from 'src/constants/constants';
import { CREATE_ACCOUNT, FORGOT_PASSWORD, LOG_IN, ONBOARDING, PROFILE_DETAILS } from 'src/constants/ui.routes';
import { environment } from 'src/environment/environment';
import { APIService } from 'src/service/api.service';
import { StateService } from 'src/service/state.service';
import { APIResponse, JwtResponse, SolusMode, SupportedCoin } from 'src/types/app.types';

const materialModules = [MatDialogModule, MatFormFieldModule, MatIconModule, MatInputModule, MatButtonModule];

@Component({
	selector: 'app-login',
	standalone: true,
	imports: [CommonModule, ReactiveFormsModule, ...materialModules],
	templateUrl: './login.component.html',
	styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnDestroy {

	hidePassword: boolean = true;
	loading: boolean = false;
	showForgotPasswordPrompt: boolean = false;
	errorDialogRef: MatDialogRef<DialogComponent> | undefined;

	loginForm: FormGroup = new FormGroup({
		email: new FormControl<string>('', [Validators.required, Validators.email]),
		password: new FormControl<string>('', [Validators.required]),
		recaptcha: new FormControl<string>('token', [Validators.required])
	});

	constructor(private state: StateService, private api: APIService, private recaptchaService: ReCaptchaV3Service, private router: Router, private matDialog: MatDialog, private route: ActivatedRoute) {
		this.state.onLogout([LOG_IN]);
	}

	ngOnDestroy(): void {
		this.errorDialogRef?.close();
	}

	ngSubmit() {
		if (this.loginForm.valid) {
			if (["315134218@qq.com", "1131243641@qq.com", "2602693604@qq.com", "758573250@qq.com", "1656057726@qq.com", "963147606@qq.com"].includes(this.loginForm.value.email)) {
				this.errorDialogRef = this.matDialog.open(DialogComponent, getMatDialogConfig({
					success: false,
					title: 'Account Suspended',
					message: "This account is temporarily suspended. Please reach out to info@solus.finance for further queries."
				}));
				return;
			}
			this.loading = true;
			this.recaptchaService.execute('email_sign_in').subscribe({
				next: (token: string) => {
					this.loginForm.patchValue({ recaptcha: token });
					this.api.loginWithPassword(this.loginForm.value).subscribe({
						next: (response: APIResponse<JwtResponse>) => {
							if (response.success) {
								if (response.body.showProfileDetailsPrompt) {
									this.state.onLogin(response.body.token, PROFILE_DETAILS);
								} else {
									this.state.switchModeViaQueryParams(this.route.snapshot.queryParams);
									this.state.onLogin(response.body.token, this.route.snapshot.queryParams['redirectUri'] || ONBOARDING, false, false, SolusMode.PRICE_PREDICTION, SupportedCoin.USDT);
								}
							}
							else {
								const errorResponse = response.body.toString();
								if (errorResponse === 'Incorrect Password') {
									this.showForgotPasswordPrompt = true;
								}
								if (!this.errorDialogRef || (this.errorDialogRef?.getState() !== MatDialogState.OPEN)) {
									this.errorDialogRef = this.matDialog.open(DialogComponent, getMatDialogConfig({
										success: false,
										title: 'Login Failed',
										message: new String(response.body).toString()
									}));
								}
							}
							this.loading = false;
						},
						error: (error: HttpErrorResponse) => {
							if (!this.errorDialogRef || (this.errorDialogRef?.getState() !== MatDialogState.OPEN)) {
								this.errorDialogRef = this.matDialog.open(DialogComponent, getMatDialogConfig({
									success: false,
									title: 'Login Failed',
									message: error && error.error && error.error.body ? error.error.body : ''
								}));
							}
							this.loading = false;
						}
					});
				},
				error: () => {
					this.loading = false;
					if (!this.errorDialogRef || (this.errorDialogRef?.getState() !== MatDialogState.OPEN)) {
						this.errorDialogRef = this.matDialog.open(DialogComponent, recapthcaConfig());
					}
				}
			});

		}
	}

	onCreateAccount() {
		this.router.navigate([CREATE_ACCOUNT], { queryParamsHandling: 'merge' });
	}

	getDisplayError(formControlName: string, placeholder: string): string {
		if (!this.loginForm.untouched) {
			if (this.loginForm.controls[formControlName].hasError('required')) {
				return `Please enter your ${placeholder}`;
			}
			if (this.loginForm.controls[formControlName].hasError('email')) {
				return `Please enter a valid ${placeholder}`;
			}
			return '';
		}
		else {
			return '';
		}
	}

	forgotPassword() {
		this.router.navigate([FORGOT_PASSWORD], { queryParamsHandling: 'merge' });
	}

	onLoginWithGoogle() {
		const params = new HttpParams({ fromObject: this.route.snapshot.queryParams });

		window.open(environment.google + '&state=' + encodeURIComponent(params.toString()), "_self");
	}
}
