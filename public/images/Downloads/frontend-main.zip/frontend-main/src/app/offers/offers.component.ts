import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, inject, ViewEncapsulation } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { of } from 'rxjs';
import { PromoCodeAlertComponent } from 'src/components/offers/promo-code-alert/promo-code-alert.component';
import { PromoCodeHistoryDialogComponent } from 'src/components/offers/promo-code-history-dialog/promo-code-history-dialog.component';
import { PromoCodePromptComponent } from 'src/components/offers/promo-code-prompt/promo-code-prompt.component';
import { cashbackAlertData, cashbackIconConfig, depositBonusAlertData, depositBonusIconConfig, percentageIconConfig, percentageTurnoverAlertData, riskFreeAlertData, riskFreeIconConfig } from 'src/constants/offers.constants';
import { CoinDecimalPipe } from 'src/pipes/coin-decimal.pipe';
import { CurrencySymbolPipe } from 'src/pipes/currency-symbol.pipe';
import { APIService } from 'src/service/api.service';
import { OffersCardConfig, PromoCodeAlertConfig, PromoCodeHistoryDialogConfig, PromoCodePromptConfig, SupportedCoin, TableColumnConfig } from 'src/types/app.types';
import { OffersCardComponent } from './offers-card/offers-card.component';
import { Router } from '@angular/router';
import { DEPOSIT } from 'src/constants/ui.routes';

const materialModules = [MatIconModule, MatCardModule, MatTableModule, MatTooltipModule, MatSelectModule, MatSnackBarModule, MatDialogModule, MatListModule];
const pipes = [CoinDecimalPipe, CurrencySymbolPipe];

@Component({
	selector: 'app-offers',
	standalone: true,
	imports: [CommonModule, ReactiveFormsModule, ...materialModules, ...pipes, OffersCardComponent],
	templateUrl: './offers.component.html',
	styleUrl: './offers.component.scss',
	encapsulation: ViewEncapsulation.None,
})
export class OffersComponent {
	dialog = inject(MatDialog);
	api = inject(APIService);
	snackbar = inject(MatSnackBar);
	router = inject(Router);

	depositBonusColumns: TableColumnConfig[] = [
		{
			name: 'promocode',
			label: 'Code',
			valueKey: 'voucherCode'
		},
		{
			name: 'minDeposit',
			label: 'Min. Deposit',
			valueKey: 'minDeposit',
			isCurrency: true,
			currency: SupportedCoin.USDT
		},
		{
			name: 'bonusPercentage',
			label: 'Bonus %',
			valueKey: 'bonusPercentage',
			isPercentage: true
		},
	];
	percentageTurnoverColumns: TableColumnConfig[] = [
		{
			name: 'promoCode',
			label: 'Code',
			valueKey: 'promoCode',
			activeClass: 'green',
			activeField: 'status'
		},
		{
			name: 'bonusToBeConverted',
			label: 'Bonus',
			valueKey: 'bonusToBeConverted',
			isCurrency: true,
			currency: SupportedCoin.BONUS_USDT,
			activeClass: 'green',
			activeField: 'status'
		},
	];

	depositBonusHistory: PromoCodeHistoryDialogConfig = {
		displayedColumns: this.depositBonusColumns,
		iconConfig: depositBonusIconConfig,
		title: 'Deposit Bonus',
		getHistory: this.api.getUserDepositBonuses()
	};
	riskFreeHistory: PromoCodeHistoryDialogConfig = {
		displayedColumns: [],
		iconConfig: riskFreeIconConfig,
		title: 'Risk Free',
		getHistory: of({ success: false, body: null })
	};
	cashbackHistory: PromoCodeHistoryDialogConfig = {
		displayedColumns: [],
		iconConfig: cashbackIconConfig,
		title: 'Cashback',
		getHistory: of({ success: false, body: null })
	};
	percentageTurnoverHistory: PromoCodeHistoryDialogConfig = {
		displayedColumns: this.percentageTurnoverColumns,
		iconConfig: percentageIconConfig,
		title: 'Percentage of Turnover',
		getHistory: this.api.getTurnoverBonusStatus(),
	};

	// Offers Card Config
	offers: OffersCardConfig[] = [
		{
			iconConfig: depositBonusIconConfig,
			title: 'Deposit Bonus',
			supportIcon: 'contact_support',
			comingSoonIcon: 'timer',
			comingSoonText: 'Coming Soon',
			historyIcon: 'history',
			historyText: 'Show all history',
			showHistory: false,
			showCodeInput: true,
			promoCodeButtonText: 'Deposit Now',
			showComingSoon: false,
			historyDisplayedColumns: this.depositBonusColumns,
			promoCodeAlert: () => this.handlePromoCodeAlert(depositBonusAlertData),
			promoCodeHistory: () => this.handlePromoCodeHistory(this.depositBonusHistory),
			promoCodePrompt: () => this.goToDeposit(),
			getHistory: this.api.getUserDepositBonuses()
		},
		{
			iconConfig: percentageIconConfig,
			title: 'Percentage of Turnover',
			supportIcon: 'contact_support',
			comingSoonIcon: 'timer',
			comingSoonText: 'Coming Soon',
			historyIcon: 'history',
			historyText: 'Show all history',
			promoCodeButtonText: 'Enter Promo code',
			showComingSoon: false,
			historyDisplayedColumns: this.percentageTurnoverColumns,
			promoCodeAlert: () => this.handlePromoCodeAlert(percentageTurnoverAlertData),
			promoCodeHistory: () => this.handlePromoCodeHistory(this.percentageTurnoverHistory),
			promoCodePrompt: () => this.handlePromoCodePrompt({
				title: 'Percentage of Turnover',
				tradeIdInput: false,
				apply: (code: string) => this.api.applyTurnoverBonus(code)
			}),
			getHistory: this.api.getTurnoverBonusStatus(),
			showHistory: true,
			showCodeInput: true,
		},
		{
			iconConfig: riskFreeIconConfig,
			title: 'Risk Free',
			supportIcon: 'contact_support',
			comingSoonIcon: 'timer',
			comingSoonText: 'Coming Soon',
			historyIcon: 'history',
			historyText: 'Show all history',
			promoCodeButtonText: 'Enter Promo code',
			showComingSoon: true,
			historyDisplayedColumns: [],
			promoCodeAlert: () => this.handlePromoCodeAlert(riskFreeAlertData),
			promoCodeHistory: () => this.handlePromoCodeHistory(this.riskFreeHistory),
			promoCodePrompt: () => this.handlePromoCodePrompt({
				title: 'Risk Free',
				tradeIdInput: true
			}),
			getHistory: of({ success: false, body: null }),
			showHistory: false,
			showCodeInput: true,
		},
		{
			iconConfig: cashbackIconConfig,
			title: 'Cashback',
			supportIcon: 'contact_support',
			comingSoonIcon: 'timer',
			comingSoonText: 'Coming Soon',
			historyIcon: 'history',
			historyText: 'Show all history',
			promoCodeButtonText: 'Enter Promo code',
			showComingSoon: true,
			historyDisplayedColumns: [],
			promoCodeAlert: () => this.handlePromoCodeAlert(cashbackAlertData),
			promoCodeHistory: () => this.handlePromoCodeHistory(this.cashbackHistory),
			promoCodePrompt: () => this.handlePromoCodePrompt({
				title: 'Cashback',
				tradeIdInput: true
			}),
			getHistory: of({ success: false, body: null }),
			showHistory: false,
			showCodeInput: true,
		},
	];



	handlePromoCodeAlert(dialogData: PromoCodeAlertConfig) {
		this.dialog.open(PromoCodeAlertComponent, { width: '287px', data: dialogData });
	}

	handlePromoCodeHistory(history: PromoCodeHistoryDialogConfig) {
		this.dialog.open(PromoCodeHistoryDialogComponent, { width: '400px', data: history });
	}

	handlePromoCodePrompt(dialogData: PromoCodePromptConfig) {
		const dialogRef = this.dialog.open(PromoCodePromptComponent, {
			width: '400px',
			panelClass: 'matModalContainer',
			data: dialogData
		});

		dialogRef.afterClosed().subscribe((form: { code: string, tradeId: number }) => {
			if (form) {
				const { code } = form;

				if (dialogData.apply) {
					dialogData.apply(code.toUpperCase()).subscribe({
						next: (res) => {
							if (res.success) {
								this.snackbar.open(res.body, undefined, { panelClass: ['snackbar-success'] });
							} else {
								this.snackbar.open(res.body, undefined, { panelClass: ['snackbar-error'] });
							}
							this.offers[1].getHistory = this.api.getTurnoverBonusStatus()
						},
						error: (err: HttpErrorResponse) => {
							console.error(err);
							this.snackbar.open(err.error?.body || err.error?.message || 'Failed to activate promo code', undefined, { panelClass: ['snackbar-error'] });
						}
					});
				}
			}
		});
	}

	goToDeposit() {
		this.router.navigate([DEPOSIT]);
	}

}
