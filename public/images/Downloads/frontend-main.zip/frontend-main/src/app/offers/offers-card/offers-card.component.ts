import { CommonModule } from '@angular/common';
import { Component, inject, input, OnChanges, OnInit, output, SimpleChanges, ViewEncapsulation } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { DomSanitizer } from '@angular/platform-browser';
import { Observable, of } from 'rxjs';
import { CoinDecimalPipe } from 'src/pipes/coin-decimal.pipe';
import { CurrencySymbolPipe } from 'src/pipes/currency-symbol.pipe';
import { APIResponse, TableColumnConfig } from 'src/types/app.types';

const materialModules = [MatIconModule, MatCardModule, MatTableModule, MatTooltipModule, MatSelectModule, MatSnackBarModule, MatDialogModule, MatInputModule, MatMenuModule, MatListModule, MatButtonModule];

@Component({
	selector: 'app-offers-card',
	standalone: true,
	imports: [CommonModule, ...materialModules, CoinDecimalPipe, CurrencySymbolPipe],
	templateUrl: './offers-card.component.html',
	styleUrl: './offers-card.component.scss',
	encapsulation: ViewEncapsulation.None,
})
export class OffersCardComponent implements OnInit, OnChanges {

	iconConfig = input.required<{
		icon: string;
		class: string;
	}>({ alias: 'iconConfig' });

	title = input.required<string>({ alias: 'title' });
	supportIcon = input.required<string>({ alias: 'supportIcon' });
	comingSoonIcon = input.required<string>({ alias: 'comingSoonIcon' });
	comingSoonText = input.required<string>({ alias: 'comingSoonText' });
	historyIcon = input.required<string>({ alias: 'historyIcon' });
	historyText = input.required<string>({ alias: 'historyText' });
	promoCodeButtonText = input.required<string>({ alias: 'promoCodeButtonText' });
	showComingSoon = input<boolean>(false, { alias: 'showComingSoon' });
	showHistory = input<boolean>(false, { alias: 'showHistory' });
	showCodeInput = input<boolean>(false, { alias: 'showCodeInput' });
	historyDataSource: any[] = [];
	historyDisplayedColumns = input<TableColumnConfig[]>([], { alias: 'historyDisplayedColumns' });
	getHistory = input<Observable<APIResponse<any>>>(of({ success: false, body: null }), { alias: 'getHistory' });
	loading: boolean = false;

	promoCodeAlert = output<void>({ alias: 'promoCodeAlert' });
	promoCodeHistory = output<void>({ alias: 'promoCodeHistory' });
	promoCodePrompt = output<void>({ alias: 'promoCodePrompt' });

	sanitizer = inject(DomSanitizer);

	ngOnInit(): void {
		this.getHistoryData();
	}

	ngOnChanges(changes: SimpleChanges): void {
		if (changes) {
			this.getHistoryData();
		}
	}

	getHistoryData() {
		this.loading = true;
		this.getHistory().subscribe({
			next: (res) => {
				if (res.success) {
					this.historyDataSource = res.body;
				} else {
					this.historyDataSource = [];
				}
				this.loading = false;
			},
			error: () => {
				this.historyDataSource = [];
				this.loading = false;
			}
		});
	}

	getColumns() {
		return this.historyDisplayedColumns().map(x => x.name);
	}

	emitPromoCodeAlert() {
		this.promoCodeAlert.emit();
	}

	emitPromoCodeHistory() {
		this.promoCodeHistory.emit();
	}

	emitPromoCodePrompt() {
		this.promoCodePrompt.emit();
	}

	getActiveClass(column: any, element: any) {
		if (column.activeField) {
			if (element[column.activeField] === 'ACTIVE' ) {
				return column.activeClass;
			}
		}
		return '';
	}
}
