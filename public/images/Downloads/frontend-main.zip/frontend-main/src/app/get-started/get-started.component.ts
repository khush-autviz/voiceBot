import { animate, style, transition, trigger } from '@angular/animations';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { Component, HostListener, OnDestroy, ViewChild } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { CarouselComponent, CarouselModule, OwlOptions, SlidesOutputData } from 'ngx-owl-carousel-o';
import { Subscription } from 'rxjs';
import { CREATE_ACCOUNT, LOG_IN, MARKETS } from 'src/constants/ui.routes';
import { StateService } from 'src/service/state.service';
import { State } from 'src/types/app.types';

const materialModules = [CarouselModule];
@Component({
	selector: 'app-get-started',
	standalone: true,
	imports: [CommonModule, RouterModule, NgOptimizedImage,...materialModules],
	templateUrl: './get-started.component.html',
	styleUrls: ['./get-started.component.scss'],
	animations: [
		trigger(
			'inOutAnimation',
			[
				transition(
					':enter',
					[
						style({ opacity: 0, transform: 'scale(0,0)' }),
						animate('0.3s ease-in',
							style({ opacity: 1, transform: 'scale(1,1)' }))
					]
				),
			]
		)
	]
})

export class GetStartedComponent implements OnDestroy {
	public currSlideIndex: number = 0;
	public slides = [
		{
			id: '1',
			title: 'Futures Made Easy',
			description: 'Start Futures like Spot Trading'
		},
		{
			id: '2',
			title: 'You are Protected',
			description: 'Controlled Loss, Small Investment, Big Returns'
		},
		{
			id: '3',
			title: 'Trade More for Less',
			description: 'No Gas Fees, Convert Rewards to Investments'
		},
		{
			id: '4',
			title: 'Community Driven Trading',
			description: 'Collaborate, Compete, Excel'
		}
	]
	public customOptions: OwlOptions = {
		loop: true,
		mouseDrag: true,
		touchDrag: true,
		slideTransition: 'linear',
		autoplay: true,
		autoplaySpeed: 500,
		autoplayHoverPause: false,
		dots: false,
		navSpeed: 6000,
		fluidSpeed: true,
		nav: false,
		autoHeight: false,
		startPosition: this.currSlideIndex,
		responsive: {
			0: {
				items: 1,
			},
		},
	}

	get isLastSlide(): boolean {
		return this.slides.length - 1 === this.currSlideIndex
	}

	@HostListener('window:keyup', ['$event'])
	keyEvent(event: KeyboardEvent) {
		if (!this.isTouchScreen() && event.keyCode === 37 || event.keyCode === 39) {
			// left
			if (event.keyCode === 37 && this.currSlideIndex > 0) {
				this.goTo(this.currSlideIndex - 1)
			}
			// right
			if (event.keyCode === 39 && !this.isLastSlide) {
				this.goTo(this.currSlideIndex + 1)
			}
		}
	}

	@ViewChild('owl') carousel?: CarouselComponent;

	state: State;
	stateSub: Subscription;

	constructor(private router: Router, private stateService: StateService, private route: ActivatedRoute) {
		this.state = this.stateService.getState();
		this.stateSub = this.stateService.state$.subscribe({
			next: (state: State) => {
				this.state = state;
				this.goToFeedIfLoggedIn();
			}
		});
		this.goToFeedIfLoggedIn();
	}

	goToFeedIfLoggedIn() {
		if (this.state.jwt) {
			this.stateService.switchModeViaQueryParams(this.route.snapshot.queryParams);
			this.router.navigate([this.route.snapshot.queryParams['redirectUri'] || MARKETS]);
		}
	}

	translated(e: SlidesOutputData): void {
		this.currSlideIndex = e.startPosition as number;
	}

	private isTouchScreen(): boolean {
		return ('ontouchstart' in window) ||
			(navigator?.maxTouchPoints > 0) ||
			((navigator as any)?.msMaxTouchPoints > 0);
	}

	goToLogin(): void {
		this.router.navigate([LOG_IN], { queryParamsHandling: 'merge' });
	}

	goToRegistr(): void {
		this.router.navigate([CREATE_ACCOUNT], { queryParamsHandling: 'merge' });
	}

	goToLast(): void {
		this.currSlideIndex = this.slides.length - 1;
		this.carousel?.to(this.slides[this.currSlideIndex].id);
	}

	goTo(index: number): void {
		this.currSlideIndex = index;
		this.carousel?.to(this.slides[index].id)
	}

	ngOnDestroy(): void {
		this.stateSub.unsubscribe();
	}

}
