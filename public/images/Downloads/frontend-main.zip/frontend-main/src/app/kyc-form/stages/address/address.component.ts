import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatOption } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { City, Country, ICity, ICountry, IState, State } from 'country-state-city';
import { Subscription } from 'rxjs';
import { DialogComponent } from 'src/components/dialog/dialog.component';
import { getMatDialogConfig } from 'src/constants/constants';
import { APIService } from 'src/service/api.service';
import { APIResponse, KnowYourCustomer, KycAddressDetails, KycData } from 'src/types/app.types';

const materialModules = [MatFormFieldModule, MatInputModule, MatAutocompleteModule, MatSelectModule, MatButtonModule];
@Component({
	selector: 'app-address',
	templateUrl: './address.component.html',
	styleUrls: ['./address.component.scss'],
	standalone: true,
	imports: [
		CommonModule,
		ReactiveFormsModule,
		...materialModules
	],
})
export class AddressComponent implements OnInit, OnChanges, OnDestroy {

	constructor(public api: APIService, private matDialog: MatDialog) { }

	private countries: ICountry[] = [];
	filteredCountries: ICountry[] = [];

	private states: IState[] = [];
	filteredStates: IState[] = [];

	private cities: ICity[] = [];
	filteredCities: ICity[] = [];

	loading: boolean = false;
	@Input() form!: FormGroup;
	@Input() kyc!: KnowYourCustomer;
	@Input() kycData!: KycData;
	@Output() nextClicked = new EventEmitter<number>();

	dialogSubscription!: Subscription;

	ngOnInit(): void {
		this.countries = Country.getAllCountries();
	}

	ngOnChanges(changes: SimpleChanges): void {
		if (changes['kyc'] && changes['kyc'].currentValue) {
			if (this.countries.length <= 0) {
				this.countries = Country.getAllCountries();
			}

			this.kyc = changes['kyc'].currentValue;
			this.form.patchValue(this.kyc);
			for (const country of this.countries) {
				if (country.name === this.kyc.country) {
					this.states = State.getStatesOfCountry(country.isoCode);
					this.form.patchValue({ country: country });
				}
			}
			for (const state of this.states) {
				if (state.name === this.kyc.state) {
					const country = this.form?.get('country')?.value as ICountry;
					this.cities = City.getCitiesOfState(country.isoCode, state.isoCode);
					this.form.patchValue({ state: state });
				}
			}
			for (const city of this.cities) {
				if (city.name === this.kyc.city) {
					this.form.patchValue({ city: city });
				}
			}
		}
		if (changes['kycData'] && changes['kycData'].currentValue) {
			this.kycData = changes['kycData'].currentValue;
			if (this.kycData.clientId === null || this.kycData.checkId !== null) {
				this.form.disable();
			}
			else {
				this.form.enable();
			}
		}
	}

	ngOnDestroy(): void {
		this.dialogSubscription?.unsubscribe();
	}

	navigateToIDProof(): void {
		if (this.form.valid) {
			this.loading = true;
			const body: KycAddressDetails = {
				addressLine: this.form.get('addressLine')?.value,
				country: (this.form.get('country')?.value as ICountry).name,
				state: (this.form.get('state')?.value as IState)?.name || 'NA',
				city: (this.form.get('city')?.value as ICity)?.name || 'NA',
				postalCode: this.form.get('postalCode')?.value,
				stateCode: (this.form.get('state')?.value as IState)?.isoCode || 'NA',
				countryCode: (this.form.get('country')?.value as ICountry).isoCode,
			}
			this.api.kycSaveAddressDetails(body).subscribe({
				next: (response: APIResponse<KnowYourCustomer>) => {
					this.loading = false;
					if (response.success) {
						this.dialogSubscription = this.matDialog.open(DialogComponent, getMatDialogConfig({
							title: 'Success',
							message: 'Address Details Saved!',
							success: true,
							skipLog: true
						}))
							.afterClosed()
							.subscribe({
								next: () => {
									this.nextClicked.emit(2);
								}
							});
					}
					else {
						let message = response.body.toString();
						if (message.includes('https://api.complycube.com')) {
							message = 'We were not able to validate your address. Please enter valid address details!';
						}
						this.matDialog.open(DialogComponent, getMatDialogConfig({
							title: 'Address details not saved',
							message: message,
							success: false,
						}));
					}
				},
				error: () => {
					this.loading = false;
				}
			});
		}

	}

	onStateChange() {
		if (this.form.get('state')?.value) {
			this.cities = City.getCitiesOfState(this.form.get('state')?.value.countryCode, this.form.get('state')?.value.isoCode);
		} else {
			this.cities = [];
		}
	}

	getDisplayError(formControlName: string): string {
		if (this.form.untouched) {
			return '';
		}
		if (this.form.controls[formControlName].hasError('required')) {
			return `This field is required`;
		}
		if (this.form.controls[formControlName].hasError('address')) {
			return `Please enter a valid address`;
		}
		if (this.form.controls[formControlName].hasError('city')) {
			return `Please enter a valid city`;
		}
		if (this.form.controls[formControlName].hasError('country')) {
			return `Please enter a valid country`;
		}
		if (this.form.controls[formControlName].hasError('postalCode')) {
			return `Please enter a valid postal code`;
		}
		return '';
	}

	showName(obj: ICountry | IState | ICity): string {
		return obj && obj.name;
	}

	countrySelected(option: MatOption) {
		const country = option.value as ICountry;
		this.states = State.getStatesOfCountry(country.isoCode);
		this.cities = [];
		this.form.get('state')?.reset();
		this.form.get('city')?.reset();
	}

	stateSelected(option: MatOption) {
		const state = option.value as IState;
		const country = this.form?.get('country')?.value as ICountry;
		this.cities = City.getCitiesOfState(country.isoCode, state.isoCode);
	}

	countryUpdated(event: any) {
		const countryName = event.target.value;
		if (countryName === null || countryName == '' || countryName == ' ') {
			this.filteredCountries = this.countries;
		}
		else {
			this.filteredCountries = this.countries.filter(country => country.name.toLowerCase().includes(countryName.toLowerCase()));
		}
	}

	stateUpdated(event: any) {
		const stateName = event.target.value;
		if (stateName === null || stateName == '' || stateName == ' ') {
			this.filteredStates = this.states;
		}
		else {
			this.filteredStates = this.states.filter(state => state.name.toLowerCase().includes(stateName.toLowerCase()));
		}
	}

	cityUpdated(event: any) {
		const cityName = event.target.value;
		if (cityName === null || cityName == '' || cityName == ' ') {
			this.filteredCities = this.cities;
		}
		else {
			this.filteredCities = this.cities.filter(city => city.name.toLowerCase().includes(cityName.toLowerCase()));
		}
	}

}
