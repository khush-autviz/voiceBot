import { CommonModule, Location } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatTabsModule } from '@angular/material/tabs';
import { ActivatedRoute, Params, Router } from '@angular/router';
import * as moment from 'moment';
import { Subscription } from 'rxjs';
import { DialogComponent } from 'src/components/dialog/dialog.component';
import { getMatDialogConfig } from 'src/constants/constants';
import { DEPOSIT, KYC, MARKETS, SUCCESS } from 'src/constants/ui.routes';
import { APIService } from 'src/service/api.service';
import { APIResponse, Balance, KnowYourCustomer, KycData } from 'src/types/app.types';
import * as NUMBER_VALIDATORS from '../../validators/number-validators';
import { PermissionComponent } from '../permission/permission.component';
import { AddressComponent } from './stages/address/address.component';
import { IdProofComponent } from './stages/id-proof/id-proof.component';
import { PersonalDetailsComponent } from './stages/personal-details/personal-details.component';

const materialModules = [MatButtonModule, MatIconModule, MatTabsModule, MatCardModule, MatProgressBarModule];
const components = [PersonalDetailsComponent, AddressComponent, IdProofComponent, PermissionComponent];
@Component({
	selector: 'app-kyc-form',
	templateUrl: './kyc-form.component.html',
	styleUrls: ['./kyc-form.component.scss'],
	standalone: true,
	imports: [CommonModule, ...materialModules, ...components],
})
export class KycFormComponent implements OnInit, OnDestroy {

	stepIndex: number = 0;
	form: FormGroup;
	stepSub!: Subscription;

	kycData!: KycData;
	kyc!: KnowYourCustomer;
	loading: boolean = false;

	hasEnoughBalance: boolean = false;

	constructor(private fb: FormBuilder, private router: Router, private route: ActivatedRoute, private api: APIService, private matDialog: MatDialog, private location: Location) {
		this.form = this.fb.group({
			personalDetails: this.fb.group({
				firstName: ['', [Validators.required, this.validateText]],
				lastName: ['', [Validators.required, this.validateText]],
				gender: ['', Validators.required],
				dateOfBirth: ['', [Validators.required, this.validateDOB]],
				phoneNumberPrefix: ['', [Validators.required, NUMBER_VALIDATORS.countryCodeValidator()]],
				phoneNumber: ['', [Validators.required]],
				emailId: ['', [Validators.required, Validators.email]],
			}),
			addressDetails: this.fb.group({
				addressLine: ['', Validators.required],
				country: ['', Validators.required],
				state: [''],
				city: [''],
				postalCode: ['', Validators.required],
			})
		});
	}

	get detailsForm(): FormGroup {
		return this.form.get('personalDetails') as FormGroup;
	}

	get addressForm(): FormGroup {
		return this.form.get('addressDetails') as FormGroup;
	}

	get idProofForm(): FormGroup {
		return this.form.get('idDetails') as FormGroup;
	}

	ngOnInit(): void {
		this.stepSub = this.route.queryParams.subscribe((params: Params) => {
			if (params['step']) {
				this.stepIndex = Number(params['step']);
			}
		});
		this.loading = true;
		this.api.kycCheckStatus().subscribe({
			next: (response: APIResponse<KycData>) => {
				if (response.success) {
					this.kycData = response.body;

					const isKycClear = this.kycData && this.kycData.outcome === 'clear' && this.kycData.documentCheckOutcome === 'clear';
					if (isKycClear) {
						this.loading = false;
						this.router.navigate([KYC, SUCCESS]);
					} else {
						this.api.getKycDetails().subscribe({
							next: (response: APIResponse<KnowYourCustomer>) => {
								if (response.success) {
									this.kyc = response.body;
								}
							}
						});
						this.api.getBalance().subscribe({
							next: (response: APIResponse<Balance[]>) => {
								if (response.success) {
									for (const balance of response.body) {
										if (balance.symbol === 'USDT') {
											const absoluteBalance = balance.balance / Math.pow(10, balance.decimals);
											if (absoluteBalance > 1.2) {
												this.hasEnoughBalance = true;
											}
										}
									}
								}
								this.loading = false;
							}
						})
					}
				}
				else {
					this.matDialog.open(DialogComponent, getMatDialogConfig({
						success: false,
						title: 'KYC Status',
						message: 'Could not retrieve KYC status. Please try again later.'
					}));
					this.loading = false;
				}
			},
			error: () => {
				this.loading = false;
				this.matDialog.open(DialogComponent, getMatDialogConfig({
					success: false,
					title: 'KYC Status',
					message: 'Could not retrieve KYC status. Please try again later.'
				}));
			}
		});
	}

	ngOnDestroy(): void {
		this.stepSub.unsubscribe();
	}

	changeStep(index: number): void {
		this.api.kycCheckStatus().subscribe({
			next: (response: APIResponse<KycData>) => {
				if (response.success) {
					this.kycData = response.body;
				}
			}
		})
		this.stepIndex = index;
		this.router.navigate([], { queryParams: { step: this.stepIndex } });
	}

	validateText(control: AbstractControl): { [key: string]: boolean } | null {
		const textOnlyRegex = /^[A-Za-z ]+$/; // Regular expression for text-only
		if (!textOnlyRegex.test(control.value)) {
			return { invalidText: true }; // Validation failed
		}
		return null; // Validation passed
	}

	validateDOB(control: FormControl) {
		const selectedDate = moment(control.value).startOf('day');
		const currentDate = moment().startOf('day');
		if (selectedDate.isAfter(currentDate) || selectedDate.isSame(currentDate)) {
			return { futureDate: true }; // Return an error if DOB is in the future or the same as the current date
		}
		return null; // Validation passes
	}

	continueToDeposit() {
		this.router.navigate([DEPOSIT]);
	}

	onClickedBackBtn() {
		this.router.navigate([MARKETS]);
	}

	openSuccessDialog(message: string, redirect: string = '') {
		this.matDialog.closeAll();
		return this.matDialog.open(DialogComponent, getMatDialogConfig({
			success: true,
			title: 'KYC Update',
			message: message,
			closeButtonLabel: 'Okay',
			skipLog: true,
			redirect: redirect || undefined
			// redirect: `${KYC}/${SUCCESS}`
		}));
	}
}
