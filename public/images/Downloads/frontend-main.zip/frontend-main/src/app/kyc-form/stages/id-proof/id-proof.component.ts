import { Component, EventEmitter, HostListener, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { DialogComponent } from 'src/components/dialog/dialog.component';
import { getMatDialogConfig } from 'src/constants/constants';
import { APIService } from 'src/service/api.service';
import { APIResponse, ComplyCubeDocumentCapture, KnowYourCustomer, KycData } from 'src/types/app.types';
import { MatButtonModule } from '@angular/material/button';


@Component({
    selector: 'app-id-proof',
    templateUrl: './id-proof.component.html',
    styleUrls: ['./id-proof.component.scss'],
    standalone: true,
    imports: [MatButtonModule],
})
export class IdProofComponent implements OnInit, OnChanges {

	@Input() kyc!: KnowYourCustomer;
	@Input() kycData!: KycData;
	@Output() nextClicked = new EventEmitter<number>();

	token: string = '';
	loading: boolean = false;
	uploadButtonDisabled: boolean = true;
	checkButtonDisabled: boolean = true;

	documentCapture: ComplyCubeDocumentCapture | null = null;
	dialogSubscription: Subscription | undefined;

	constructor(private api: APIService, private matDialog: MatDialog, private router: Router) {}

	ngOnInit(): void {
		this.mountComplyCubeSDK();
	}

	ngOnChanges(changes: SimpleChanges): void {
		if (changes['kycData'] && changes['kycData'].currentValue) {
			this.kycData = changes['kycData'].currentValue;
			this.uploadButtonDisabled = this.kycData.documentId != null;
		}
	}

	onUploadDocument() {
		this.loading = true;
		this.api.kycGetSdkToken().subscribe({
			next: (response: APIResponse<string>) => {
				if (response.success) {
					this.token = response.body;
					complycubeSDK.startVerification(this.token);
				}
				else {
					this.openErrorDialog('Please check if you have entered personal details and address information.');
				}
			},
			error: () => {
				this.openErrorDialog('We\'re having technical difficulties processing this request.');
			},
			complete: () => {
				this.loading = false;
			}
		});

	}

	mountComplyCubeSDK() {
		this.mountJavascript("https://assets.complycube.com/web-sdk/v1/complycube.min.js");
		this.mountStyleSheets("https://assets.complycube.com/web-sdk/v1/style.css");
	}

	mountJavascript(url: string) {
		let isFound = false;
		const scripts = document.getElementsByTagName("script")
		for (let i = 0; i < scripts.length; ++i) {
			if (scripts[i].getAttribute('src') != null && scripts[i].getAttribute('src')?.includes("complycube")) {
				isFound = true;
			}
		}
		if (!isFound) {
			const dynamicScripts = [url];
			for (let i = 0; i < dynamicScripts.length; i++) {
				const node = document.createElement('script');
				node.src = dynamicScripts[i];
				node.type = 'text/javascript';
				node.async = false;
				node.charset = 'utf-8';
				document.getElementsByTagName('head')[0].appendChild(node);
			}
		}
	}

	mountStyleSheets(url: string) {
		let isFound = false;
		const stylesheets = document.getElementsByTagName("link");
		for (let i = 0; i < stylesheets.length; ++i) {
			if (stylesheets[i].getAttribute('rel') != null && stylesheets[i].getAttribute('rel') != 'stylesheet') {
				continue;
			}
			if (stylesheets[i].getAttribute('complycube') != null && stylesheets[i].getAttribute('href')?.includes("complycube")) {
				isFound = true;
			}
		}
		if (!isFound) {
			const dynamicScripts = [url];
			for (let i = 0; i < dynamicScripts.length; i++) {
				const node = document.createElement('link');
				node.href = dynamicScripts[i];
				node.rel = 'stylesheet';
				node.charset = 'utf-8';
				document.getElementsByTagName('head')[0].appendChild(node);
			}
		}
	}

	@HostListener('window:complycube:complete', ['$event'])
	onComplyCubeComplete(event: CustomEvent) {
		this.documentCapture = event.detail;
		if(this.documentCapture !== null) {
			this.loading = true;
			this.api.kycSaveDocumentCapture(this.documentCapture).subscribe({
				next: (response: APIResponse<KycData>) => {
					this.loading = false;
					if(response.success) {
						this.kycData = response.body;
						this.uploadButtonDisabled = true;
						const dialogRef = this.openSuccessDialog('We have received your documents');

						this.dialogSubscription = dialogRef.afterClosed().subscribe(() => {
							this.nextClicked.emit(3);
						});

						if (this.kycData.documentId && !this.kycData.checkId) {
							this.checkButtonDisabled = false;
						}
					}
					else {
						this.openErrorDialog('Something went wrong while uploading your documents');
					}
				},
				error: () => {
					this.loading = false;
					this.openErrorDialog('We\'re having technical difficulties processing this request.');
				}
			});
		}
	}

	@HostListener('window:complycube:close', ['$event'])
	onComplyCubeClose(event: CustomEvent) {
		if(this.documentCapture === null) {
			this.openErrorDialog('We could\'t collect your KYC documents since you left the document upload midway.');
		}
	}

	@HostListener('window:complycube:error', ['$event'])
	onComplyCubeError(event: CustomEvent) {
		this.openErrorDialog(event.detail.message);
	}

	@HostListener('window:complycube:exit', ['$event'])
	onComplyCubeExit(event: CustomEvent) {
		this.openErrorDialog(event.detail.message);
	}

	openErrorDialog(message: string) {
		this.matDialog.open(DialogComponent, getMatDialogConfig({
			success: false,
			title: 'Error while completing KYC',
			message: message,
			closeButtonLabel: 'Okay'
		}));
	}

	openSuccessDialog(message: string) {
		return this.matDialog.open(DialogComponent, getMatDialogConfig({
			success: true,
			title: 'KYC Update',
			message: message,
			closeButtonLabel: 'Okay',
			skipLog: true
		}));
	}
}
