import { AsyncPipe, CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatNativeDateModule, MatOptionModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { Observable, Subscription, map, startWith } from 'rxjs';
import { COUNTRY_CODES } from 'src/assets/country-codes';
import { DialogComponent } from 'src/components/dialog/dialog.component';
import { getMatDialogConfig } from 'src/constants/constants';
import { APIService } from 'src/service/api.service';
import { APIResponse, CountryCode, KnowYourCustomer, KycData } from 'src/types/app.types';

const materialModules = [MatFormFieldModule, MatInputModule, MatRadioModule, MatDatepickerModule, MatNativeDateModule, MatAutocompleteModule, MatOptionModule, MatButtonModule];
@Component({
	selector: 'app-personal-details',
	templateUrl: './personal-details.component.html',
	styleUrls: ['./personal-details.component.scss'],
	standalone: true,
	imports: [
		CommonModule,
		ReactiveFormsModule,
		AsyncPipe,
		...materialModules
	],
})
export class PersonalDetailsComponent implements OnInit, OnChanges, OnDestroy {

	@Output() nextClicked = new EventEmitter<number>();

	@Input() form!: FormGroup;
	@Input() kyc!: KnowYourCustomer;
	@Input() kycData!: KycData;

	filteredCodes!: Observable<CountryCode[]>;
	loading: boolean = false;
	dialogSubscription!: Subscription;

	get countryCodes(): CountryCode[] {
		return COUNTRY_CODES;
	}

	constructor(private api: APIService, private matDialog: MatDialog) { }

	ngOnChanges(changes: SimpleChanges): void {
		if (changes['kyc'] && changes['kyc'].currentValue) {
			this.form?.patchValue(changes['kyc'].currentValue);
		}
		if (changes['kycData'] && changes['kycData'].currentValue) {
			this.kycData = changes['kycData'].currentValue;
			if (this.kycData.checkId) {
				this.form.disable();
			}
		}
	}

	ngOnInit(): void {
		this.filteredCodes = this.form?.get('phoneNumberPrefix')!.valueChanges.pipe(
			startWith(''),
			map((phoneNumberPrefix: string) => phoneNumberPrefix ? this._filterCodes(phoneNumberPrefix) : this.countryCodes.slice())
		);
	}

	ngOnDestroy(): void {
		this.dialogSubscription?.unsubscribe();
	}

	formatNumber(): void {
		const phoneNumber: number = this.form?.get('phoneNumber')?.value;
		if (phoneNumber !== undefined) {
			const valueArray = phoneNumber.toString().split('').filter((char: any) => char !== '-');
			const formattedArray = [];
			if (!!valueArray?.length) {
				for (let i = 0; i <= valueArray?.length; i++) {
					formattedArray.push(valueArray[i]);
					if (i === 1 || i === 4) {
						formattedArray.push('-');
						continue;
					} else {
						continue;
					}
				}
				this.form?.get('phoneNumber')?.setValue(formattedArray.join(''));
			}
		}
	}

	getDisplayError(formControlName: string): string {
		if (this.form.untouched) {
			return '';
		}
		if (this.form.controls[formControlName].hasError('required')) {
			return `This field is required`;
		}
		if (this.form.controls[formControlName].hasError('invalidText')) {
			return `This field can not contain numbers`;
		}
		if (this.form.controls[formControlName].hasError('futureDate')) {
			return `Date of Birth must not be a future date`;
		}
		if (this.form.controls[formControlName].hasError('email')) {
			return `Enter a valid email address`;
		}
		return '';
	}

	savePersonalDetails() {
		if (this.form.valid && !this.loading) {
			this.loading = true;
			this.api.kycSavePersonalDetails(this.form.value).subscribe({
				next: (response: APIResponse<KnowYourCustomer>) => {
					this.loading = false;
					if (response.success) {
						this.dialogSubscription = this.matDialog.open(DialogComponent, getMatDialogConfig({
							title: 'Success',
							message: 'Personal Details Saved!',
							success: true,
							skipLog: true
						}))
							.afterClosed()
							.subscribe({
								next: () => {
									this.nextClicked.emit(1);
								}
							});
					}
					else {
						this.loading = false;
						this.matDialog.open(DialogComponent, getMatDialogConfig({
							title: 'Personal details not saved',
							message: response.body.toString().split(":")[1] ? response.body.toString().split(":")[1] : response.body.toString().split(":")[0],
							success: false,
						}));
					}
				},
				error: (err: HttpErrorResponse) => {
					this.loading = false;
				}
			});
		}
		else {
			this.form.markAllAsTouched();
		}
	}

	private _filterCodes(value: string): any[] {
		return this.countryCodes.filter((countryCode: CountryCode) =>
			(countryCode.code + countryCode.name).toLowerCase().includes(value)
		);
	}
}
