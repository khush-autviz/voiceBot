import { CommonModule } from '@angular/common';
import { Component, OnDestroy } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { ActivatedRoute, Router } from '@angular/router';
import { DEPOSIT, LOG_IN, MARKETS, PAYPAL_PAYMENT_CANCELLED, PAYPAL_PAYMENT_STATUS, RADOM_PAYMENT_FAILED, RADOM_PAYMENT_SUCCESS } from 'src/constants/ui.routes';
import { APIService } from 'src/service/api.service';
import { StateService } from 'src/service/state.service';
import { PaymentStatus } from 'src/types/app.types';

const materialModules = [MatIconModule, MatProgressSpinnerModule];

@Component({
	selector: 'app-payment-status',
	standalone: true,
	imports: [CommonModule, ...materialModules],
	templateUrl: './payment-status.component.html',
	styleUrl: './payment-status.component.scss'
})
export class PaymentStatusComponent implements OnDestroy {
	loading: boolean = true;
	status: PaymentStatus = PaymentStatus.Processing;
	PaymentStatus = PaymentStatus;
	timeout: NodeJS.Timeout | undefined;

	constructor(private router: Router, private route: ActivatedRoute, private api: APIService, private stateService: StateService) {
		const url = this.router.url;
		const params = this.route.snapshot.queryParams;

		if (url.includes(PAYPAL_PAYMENT_STATUS)) {
			const { token } = params;
			if (token) {
				this.api.completePayPalPayment(token).subscribe({
					next: (res) => {
						if (res.success) {
							if (res.body.isSuccess) {
								this.stateService.refreshUserBalanceCurrency();
								this.status = PaymentStatus.Success;
							} else {
								this.status = PaymentStatus.Failed;
							}
						} else {
							this.status = PaymentStatus.Failed;
						}
						this.loading = false;
						this.setRedirectTimer();
					},
					error: () => {
						this.status = PaymentStatus.Failed;
						this.loading = false;
						this.setRedirectTimer();
					}
				});
			}
		} else if (url.includes(PAYPAL_PAYMENT_CANCELLED)) {
			const { token } = params;
			if (token) {
				this.api.cancelPayPalPayment(token).subscribe({
					next: () => {
						this.status = PaymentStatus.Cancelled;
						this.loading = false;
						this.setRedirectTimer();
					},
					error: () => {
						this.status = PaymentStatus.Failed;
						this.loading = false;
						this.setRedirectTimer();
					}
				});
			}
		} else if (url.includes(RADOM_PAYMENT_SUCCESS)) {
			this.status = PaymentStatus.Success;
			this.loading = false;
			this.setRedirectTimer();
		} else if (url.includes(RADOM_PAYMENT_FAILED)) {
			this.status = PaymentStatus.Failed;
			this.loading = false;
			this.setRedirectTimer();
		} else {
			this.loading = false;
			this.router.navigate([LOG_IN]);
		}
	}

	ngOnDestroy(): void {
		clearTimeout(this.timeout);
	}

	setRedirectTimer() {
		setTimeout(() => {
			this.router.navigate([DEPOSIT]);
		}, 7000);
	}

	getTitle() {
		switch (this.status) {
			case PaymentStatus.Processing:
				return 'Payment is processing...';
			case PaymentStatus.Success:
				return 'Payment Successful';
			case PaymentStatus.Failed:
				return 'Payment Failed';
			case PaymentStatus.Cancelled:
				return 'Payment Cancelled';
			default:
				return 'Payment is processing...';
		}
	}

	getMessage() {
		switch (this.status) {
			case PaymentStatus.Processing:
				return 'Please wait! Do not refresh or close this window!';
			case PaymentStatus.Failed:
				return 'Sorry, deposit failed! We encountered some issue during the transaction. Your money, if debited, will be refunded in 7-8 working days. You are being redirected to application, please wait!';
			case PaymentStatus.Cancelled:
				return 'Looks like the payment has been cancelled due to some reason. Your money, if debited, will be refunded in 7-8 working days.';
			default:
				return 'Please wait! Do not refresh or close this window!';
		}
	}

	getRedirectMessage() {
		switch (this.status) {
			case PaymentStatus.Success:
				return 'You are being redirected to application, please wait!';
			case PaymentStatus.Failed:
				return 'You are being redirected to application, please wait!';
			case PaymentStatus.Cancelled:
				return 'You are being redirected to application, please wait!';
			default:
				return '';
		}
	}
}
