import { BreakpointObserver, BreakpointState } from '@angular/cdk/layout';
import { CommonModule } from '@angular/common';
import { Component, OnDestroy, ViewEncapsulation } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTableModule } from '@angular/material/table';
import { Title } from '@angular/platform-browser';
import { Subscription } from 'rxjs';
import { DialogComponent } from 'src/components/dialog/dialog.component';
import { copyToClipboard, facebook, getMatDialogConfig, reddit, shareReferralLink, telegram, twitter, whatsapp } from 'src/constants/constants';
import { environment } from 'src/environment/environment';
import { CoinDecimalPipe } from 'src/pipes/coin-decimal.pipe';
import { CurrencySymbolPipe } from 'src/pipes/currency-symbol.pipe';
import { APIService } from 'src/service/api.service';
import { StateService } from 'src/service/state.service';
import { APIResponse, Page, ReferralDto, ReferralRewardsDto, ReferralSocials, ReferralTransaction, State, SupportedCoin, Transaction } from 'src/types/app.types';

const materialModules = [MatIconModule, MatCardModule, MatTableModule, MatSnackBarModule];
const pipes = [CoinDecimalPipe, CurrencySymbolPipe];

@Component({
	selector: 'app-referral',
	standalone: true,
	imports: [CommonModule, ...materialModules, ...pipes],
	templateUrl: './referral.component.html',
	styleUrls: ['./referral.component.scss'],
	encapsulation: ViewEncapsulation.None
})
export class ReferralComponent implements OnDestroy {
	isMobileDevice: boolean = false;
	breakpointSubscription: Subscription;

	referralBannerDark = '../../assets/referral-banner-dark.webp';
	referralBanner = this.referralBannerDark;

	referralOfferDark = '../../assets/referral-offer-dark.webp';
	referralOffer = this.referralOfferDark;

	socials = [whatsapp, twitter, facebook, reddit, telegram];

	referrals: ReferralDto = {
		referralCommision: 0,
		referralCount: 0,
		referrals: []
	};

	referralRewards: ReferralRewardsDto = {
		mainnetReferralCommission: 0,
		referralCommission: 0,
		referralReward: 0,
		referralUsdtTradeVolume: 0
	};

	state: State;
	stateSubscription: Subscription;
	referralLink: string = '';
	referralCode: string = '';
	successfulReferrals: number = 0;
	tradeVolume: number = 0;
	usdtEarnings: number = 0;
	mainnetTokenEarnings: number = 0;

	displayedColumns: string[] = ['date', 'investedBy', 'amount'];
	referralTransactions: ReferralTransaction[] = [];

	SupportedCoin = SupportedCoin;

	constructor(private api: APIService, private matDialog: MatDialog, private stateService: StateService, private snackbar: MatSnackBar, private title: Title, private breakpointObserver: BreakpointObserver) {
		this.title.setTitle('Referrals / Solus');

		this.breakpointSubscription = this.breakpointObserver.observe(["(max-width: 576px)"]).subscribe((result: BreakpointState) => {
			if (result.matches) {
				this.isMobileDevice = true;
			} else {
				this.isMobileDevice = false;
			}
		});

		this.api.referral().subscribe({
			next: (response: APIResponse<ReferralDto>) => {
				if (response.success) {
					this.referrals = response.body;
					this.successfulReferrals = this.referrals.referrals.filter(referral => referral.usdtTrades > 0).length;
					this.referrals.referrals.forEach(referral => {
						this.tradeVolume += (referral.usdtTradeVolume || 0);
					});
				}
				else {
					this.showErrorDialog()
				}
			},
			error: () => {
				this.showErrorDialog()
			}
		});

		this.api.referralTransactions().subscribe({
			next: (response: APIResponse<ReferralTransaction[]>) => {
				if (response.success) {
					this.referralTransactions = response.body;

					this.usdtEarnings = 0;
					this.referralTransactions.forEach((transaction: ReferralTransaction) => {
						this.usdtEarnings += transaction.amount * 0.02;
					});
				}
				else {
					this.referralTransactions = [];
					this.showErrorDialog();
				}
			},
			error: () => {
				this.referralTransactions = [];
				this.showErrorDialog();
			}
		});

		this.api.referralRewards().subscribe({
			next: (response: APIResponse<ReferralRewardsDto>) => {
				if (response.success) {
					this.referralRewards = response.body;
				}
				else {
					this.showErrorDialog();
				}
			},
			error: () => {
				this.showErrorDialog();
			}
		});

		this.api.referralRewardsMainnetToken().subscribe({
			next: (response: APIResponse<Page<Transaction>>) => {
				if (response.success) {
					this.mainnetTokenEarnings = 0;
					response.body.content.forEach(transaction => {
						this.mainnetTokenEarnings += transaction.amount;
					});
				}
				else {
					this.showErrorDialog();
				}
			},
			error: () => {
				this.showErrorDialog();
			}
		});

		this.api.referralRewardsUsdt().subscribe({
			next: (response: APIResponse<Page<Transaction>>) => {
				if (response.success) {
					this.usdtEarnings = 0;
					response.body.content.forEach(transaction => {
						this.usdtEarnings += transaction.amount;
					});
				}
				else {
					this.showErrorDialog();
				}
			},
			error: () => {
				this.showErrorDialog();
			}
		});


		this.state = this.stateService.getState();
		this.stateSubscription = this.stateService.state$.subscribe({
			next: (state: State) => {
				this.state = state;
				this.referralLink = `${environment.frontend}/invite/${state.user?.referralCode}`;
				this.referralCode = state.user?.referralCode || '';
			}
		});
	}

	ngOnDestroy(): void {
		this.stateSubscription.unsubscribe();
		this.breakpointSubscription.unsubscribe();
	}

	copy(value: string): void {
		copyToClipboard(value);
		this.snackbar.open('Copied!', undefined, {
			duration: 500,
		});
	}

	share(social: ReferralSocials) {
		this.snackbar.open('Thanks!', undefined, { duration: 500 });
		window.open(shareReferralLink(social, this.referralLink, 'Check Solus out, they\'re really simplifying derivatives! Use my signup link to receive tokens on your first transaction: '), '_blank');
	}

	showErrorDialog() {
		this.matDialog.open(DialogComponent, getMatDialogConfig({
			success: false,
			title: 'Could not fetch your referral details',
			message: 'Something went wrong while fetching your referral details!'
		}));
	}

}
