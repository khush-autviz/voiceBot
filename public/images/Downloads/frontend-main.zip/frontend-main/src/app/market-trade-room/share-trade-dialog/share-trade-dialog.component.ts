import { CommonModule } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { APIService } from 'src/service/api.service';
import { SpotTrade } from 'src/types/app.types';

const materialModules = [MatIconModule, MatButtonModule, MatProgressSpinnerModule, MatSnackBarModule, MatDialogModule];

@Component({
	selector: 'app-share-trade-dialog',
	standalone: true,
	imports: [CommonModule, ...materialModules],
	templateUrl: './share-trade-dialog.component.html',
	styleUrl: './share-trade-dialog.component.scss'
})
export class ShareTradeDialogComponent implements OnInit {
	trade: SpotTrade;

	imageLoading: boolean = false;
	image: SafeUrl | undefined;
	imageBlob: Blob | undefined;
	error: string | undefined;

	constructor(@Inject(MAT_DIALOG_DATA) public data: { trade: SpotTrade }, private snackbar: MatSnackBar, private api: APIService, private sanitizer: DomSanitizer) {
		this.trade = this.data?.trade;
	}

	ngOnInit(): void {
		this.imageLoading = true;
		this.api.getSpotTradeScreenshot(this.trade.id).subscribe({
			next: (res) => {
				this.imageBlob = res;
				const objectURL = URL.createObjectURL(res);
				this.image = this.sanitizer.bypassSecurityTrustUrl(objectURL);
				this.imageLoading = false;
				this.error = undefined;
			}, error: () => {
				this.error = 'Failed to load the image. Please try again later.';
				this.imageLoading = false;
			}
		})
	}

	downloadImage() {
		if (this.imageBlob) {
			const link = document.createElement('a');
			link.download = `solus-trade-${new Date(this.trade.exitedAt).getTime()}.jpeg`;
			link.href = URL.createObjectURL(this.imageBlob);
			link.click();
		} else {
			this.snackbar.open('Error while downloading the image! Please try again later.', undefined, {
				panelClass: 'snackbar-error',
			});
		}
	}

	async shareImage() {
		if (this.imageBlob) {
			try {
				const file = new File([this.imageBlob], `solus-trade-${new Date(this.trade.exitedAt).getTime()}.jpeg`, { type: this.imageBlob.type });
				const data = { files: [file] };

				if (!(navigator.canShare(data))) {
					this.showShareErrorSnackbar();
				}

				await navigator.share(data);
			} catch (error) {
				this.showShareErrorSnackbar();
			}
		} else {
			this.showShareErrorSnackbar();
		}
	}

	showShareErrorSnackbar() {
		this.snackbar.open('Error while sharing the image! Please try again later.', undefined, {
			verticalPosition: 'top',
			horizontalPosition: 'right',
			panelClass: 'snackbar-error',
		});
	}
}
