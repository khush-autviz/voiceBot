import { BreakpointObserver } from '@angular/cdk/layout';
import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { Moment } from 'moment';
import { ReCaptchaV3Service } from 'ng-recaptcha';
import { Observable, retry, Subscription } from 'rxjs';
import { DialogComponent } from 'src/components/dialog/dialog.component';
import { ASSET_MAX_DECIMAL_PLACES, LAST_TRADE_ASSET_VARIATION, SOLUS_OTC_PREFIX, getBalanceOfCoin, hasPassed } from 'src/constants/constants';
import { DEPOSIT } from 'src/constants/ui.routes';
import { ImageErrorDirective } from 'src/directives/image-error.directive';
import { CoinDecimalPipe } from 'src/pipes/coin-decimal.pipe';
import { APIService } from 'src/service/api.service';
import { MarketService } from 'src/service/market.service';
import { StateService } from 'src/service/state.service';
import { WebsocketService } from 'src/service/web-socket.service';
import { BinanceMiniTicker, BinanceStreamMessage, SolusCurrency, SolusStreamMessage, SpotTradeAsset, SpotTradeRequest, State, SupportedCoin, TradePosition } from 'src/types/app.types';

const materialModules = [MatIconModule, MatCardModule, MatFormFieldModule, MatInputModule, MatButtonModule, MatMenuModule, MatSelectModule, MatTooltipModule, MatSnackBarModule];

@Component({
	selector: 'app-market-info',
	standalone: true,
	imports: [CommonModule, ImageErrorDirective, ReactiveFormsModule, ...materialModules],
	templateUrl: './market-info.component.html',
	styleUrl: './market-info.component.scss',
	encapsulation: ViewEncapsulation.None
})
export class MarketInfoComponent implements OnInit, OnDestroy {

	state: State | undefined;
	asset: SpotTradeAsset | undefined;

	subscriptions: Subscription[] = [];

	miniTicker!: BinanceMiniTicker | SolusStreamMessage['k'];
	priceStream!: Subscription;
	isBinanceSocketConnected: boolean = false;
	isSolusSocketConnected: boolean = false;
	isLoading: boolean = true;
	isPlacingTrade: boolean = false;

	tradeDuration = new FormControl(0, [Validators.required, Validators.min(1)]);
	tradeAmount = new FormControl(1, [Validators.required, Validators.min(1)]);

	walletBalance: number = 0;
	currency: SolusCurrency | undefined;

	TradePosition = TradePosition;
	ASSET_MAX_DECIMAL_PLACES = ASSET_MAX_DECIMAL_PLACES;

	isMobileDevice: boolean = false;

	tradeFreezeDialog: MatDialogRef<DialogComponent> | undefined;

	assets$: Observable<SpotTradeAsset[]> | undefined;
	selectedAsset: SpotTradeAsset | undefined;

	constructor(private marketService: MarketService, private stateService: StateService, private webSocketService: WebsocketService, private coinDecimal: CoinDecimalPipe, private recaptchaService: ReCaptchaV3Service, private api: APIService, private snackbar: MatSnackBar, private breakpointObserver: BreakpointObserver, private matDialog: MatDialog, private router: Router) {
		this.state = this.stateService.getState();
		const stateSub = this.stateService.state$.subscribe((state) => {
			this.state = state;

			this.walletBalance = this.coinDecimal.transform(getBalanceOfCoin(state.balance, state.coin));

			this.currency = this.state.currencies.find((c) => c.symbol === SupportedCoin[this.state?.coin || 3]);
		});
		this.subscriptions.push(stateSub);

		const sub = this.breakpointObserver.observe('only screen and (orientation: landscape) and (max-height: 575.98px)').subscribe({
			next: (breakpointState) => {
				this.isMobileDevice = breakpointState.matches;
			}
		});
		this.subscriptions.push(sub);

		this.assets$ = this.marketService.assets$;
		const selectedAssetSub = this.marketService.selectedAsset$.subscribe({
			next: (asset) => {
				this.selectedAsset = asset;
			}
		});
		this.subscriptions.push(selectedAssetSub);
	}

	get isWebSocketConnected() {
		return this.asset?.tradingViewSymbol.includes(SOLUS_OTC_PREFIX) ? this.isSolusSocketConnected : this.isBinanceSocketConnected;
	}

	ngOnInit(): void {
		const binanceSocketSub = this.marketService.isBinanceSocketConnected$.subscribe((connected) => {
			this.isBinanceSocketConnected = connected;
		});
		this.subscriptions.push(binanceSocketSub);

		const solusSocketSub = this.marketService.isSolusSocketConnected$.subscribe((connected) => {
			this.isSolusSocketConnected = connected;
		});
		this.subscriptions.push(solusSocketSub);

		const subSelectedAsset = this.marketService.selectedAsset$.subscribe((asset) => {
			if (asset) {

				setTimeout(() => {
					const lastTradeAssetVariationId = localStorage.getItem(LAST_TRADE_ASSET_VARIATION);
					let variationId: number | null = null;
					if (lastTradeAssetVariationId != null) {
						const variation = asset.variations.find(v => v.id === Number(lastTradeAssetVariationId));

						if (variation) {
							variationId = variation.id;

							asset.selectedVariation = variation;
						}
					}
					this.tradeDuration.setValue(variationId != null ? variationId : (asset.selectedVariation?.id || 0));
					this.tradeDuration.updateValueAndValidity();

					const minInvAmount = variationId != null ? asset.variations.find(v => v.id === Number(variationId))?.minInvestmentAmount : asset.selectedVariation.minInvestmentAmount;
					const maxInvAmount = variationId != null ? asset.variations.find(v => v.id === Number(variationId))?.maxInvestmentAmount : asset.selectedVariation.maxInvestmentAmount;

					this.tradeAmount.setValidators([Validators.required, Validators.min(this.coinDecimal.transform(minInvAmount || 0)), Validators.max(this.coinDecimal.transform(maxInvAmount || 0))]);
					// this.tradeAmount.setValue(this.coinDecimal.transform(minInvAmount || 0));
					this.tradeAmount.updateValueAndValidity();
				}, 0);

				this.asset = asset;


				// Spot Price Web Socket
				this.priceStream = this.webSocketService.getWebSocketStream(this.asset.tradingViewSymbol.includes(SOLUS_OTC_PREFIX))?.pipe(retry({ delay: 3000 })).subscribe({
					next: (data: BinanceStreamMessage | SolusStreamMessage) => {

						if (!this.asset?.tradingViewSymbol.includes(SOLUS_OTC_PREFIX)) {
							const ticker = data as BinanceStreamMessage;
							if (ticker.data) {
								this.isLoading = false;
								this.miniTicker = ticker.data;
							}
						} else {
							const ticker = data as SolusStreamMessage;
							if (ticker.k) {
								this.isLoading = false;
								this.miniTicker = ticker.k;
							}
						}
					}
				});
			}
		});
		this.subscriptions.push(subSelectedAsset);
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach(sub => sub?.unsubscribe());
	}

	placeTrade(position: TradePosition) {
		console.log('Trade Place Button Clicked');

		if (this.validateInputs() === true) {
			this.isPlacingTrade = true;
			if (this.asset) {
				const trade: SpotTradeRequest = {
					variationId: this.asset.selectedVariation?.id || 0,
					tradePosition: position,
					recaptcha: '',
					amount: (this.tradeAmount.value || 1) * Math.pow(10, this.currency?.decimals || 6),
					entryPrice: this.miniTicker.c,
					entryAt: new Date(),
					authHeader: `Bearer ${this.state?.jwt || ''}`
				};
				this.marketService.placeSpotTrade(trade);
			}
		} else {
			this.showErrorSnackbar('Could not place trade! Please check if the duration and amount are valid.');
		}
	}

	validateInputs() {

		const minimumInvestment = this.coinDecimal.transform(this.asset?.selectedVariation?.minInvestmentAmount || 1000000);
		const maximumInvestment = this.coinDecimal.transform(this.asset?.selectedVariation?.maxInvestmentAmount || 100000000);

		if (!this.asset?.selectedVariation?.isActive) {
			return `Trades are temporarily disabled for this duration. Please try again later.`;
		}

		if (!this.tradeAmount.value || this.tradeAmount.value < minimumInvestment) {
			return `Please enter a trade amount greater than $${minimumInvestment}.`;
		}

		if (!this.tradeAmount.value || this.tradeAmount.value > maximumInvestment) {
			return `Please enter a trade amount less than $${maximumInvestment}.`;
		}

		if (this.tradeAmount.value > this.walletBalance) {
			return 'You do not have enough Wallet balance to buy this trade. Deposit now.';
		}

		if (!this.isWebSocketConnected || this.miniTicker == null || this.miniTicker == undefined) {
			return 'We are facing some issues while fetching the live prices. Please refresh the browser tab and try again. If you still face issues, please get in touch with us at info@solus.finance';
		}

		return true;
	}

	hasPassed(date: string): boolean {
		return hasPassed(date);
	}

	getCountDownStartTime(dateTime: string) {
		const date: Moment = moment(dateTime);
		return date.diff(moment(), 'seconds');
	}

	getWinMultiplierValue() {
		return ((this.asset?.selectedVariation?.winMultiplier || 0) * 100);
	}

	showErrorSnackbar(message: string) {
		this.snackbar.open(message, undefined, {
			verticalPosition: this.isMobileDevice ? 'top' : 'bottom',
			panelClass: ['snackbar-error', this.isMobileDevice ? 'snackbar-mobile' : 'snackbar'],
		});
	}

	getTime(seconds: number) {
		const duration = moment.duration(seconds, 'seconds');
		const timeString = moment.utc(duration.asMilliseconds()).format('HH:mm:ss');
		return timeString;
	}

	getValidationErrorMessage(): string {
		const validationResult = this.validateInputs();

		if (validationResult !== true) {
			return validationResult;
		} else {
			return '';
		}
	}

	changeVariation(event: MatSelectChange) {
		const selectedVariation = this.asset?.variations.find(variation => variation.id === event.value);
		if (this.asset && selectedVariation) {
			this.asset.selectedVariation = selectedVariation;
			localStorage.setItem(LAST_TRADE_ASSET_VARIATION, selectedVariation.id.toString());
			this.marketService.changeSelectedAsset(this.asset);
		}
	}

	changeSelectedAsset(asset: SpotTradeAsset) {
		this.marketService.changeSelectedAsset(asset);
	}


	depositClick() {
		this.router.navigate([DEPOSIT]);
	}

	hideMobileKeyboardOnReturn(amountInput: HTMLInputElement): void {
		amountInput.blur();
	}

	playAudio() {
		const audio = new Audio();
		audio.src = "assets/sounds/trade-notification.mp3";
		audio.load();
		audio.play();
	}
}
