import { CommonModule } from '@angular/common';
import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { CdTimerModule, TimeInterface } from 'angular-cd-timer';
import * as moment from 'moment';
import { ReCaptchaV3Service } from 'ng-recaptcha';
import { InfiniteScrollDirective } from 'ngx-infinite-scroll';
import { Observable, retry, Subscription } from 'rxjs';
import { DialogComponent } from 'src/components/dialog/dialog.component';
import { ASSET_MAX_DECIMAL_PLACES, SOLUS_OTC_PREFIX, getMatDialogConfig, hasPassed } from 'src/constants/constants';
import { CoinDecimalPipe } from 'src/pipes/coin-decimal.pipe';
import { CurrencySymbolPipe } from 'src/pipes/currency-symbol.pipe';
import { HumanizeDurationPipe } from 'src/pipes/humanize-duration.pipe';
import { APIService } from 'src/service/api.service';
import { MarketService } from 'src/service/market.service';
import { WebsocketService } from 'src/service/web-socket.service';
import { APIResponse, BinanceMiniTicker, BinanceStreamMessage, CancelSpotTradeRequest, SolusStreamMessage, SpotTrade, SpotTradeAsset, TradePosition } from 'src/types/app.types';
import { ShareTradeDialogComponent } from '../share-trade-dialog/share-trade-dialog.component';


const materialModules = [MatIconModule, MatTableModule, MatFormFieldModule, MatButtonModule, MatProgressBarModule, MatTooltipModule, MatProgressSpinnerModule, MatSortModule];
const pipes = [CurrencySymbolPipe, CoinDecimalPipe, HumanizeDurationPipe];

@Component({
	selector: 'app-market-positions-table',
	standalone: true,
	imports: [CommonModule, ReactiveFormsModule, CdTimerModule, InfiniteScrollDirective, ...materialModules, ...pipes],
	templateUrl: './market-positions-table.component.html',
	styleUrl: './market-positions-table.component.scss',
})
export class MarketPositionsTableComponent implements OnInit, OnDestroy {
	@Input() openPositions: boolean = true;

	trades: MatTableDataSource<SpotTrade> = new MatTableDataSource<SpotTrade>([]);
	openTrades: SpotTrade[] = [];

	columns: string[] = [];
	openPositionsColumns = ['placedAt', 'position', 'entryPrice', 'currentPrice', 'cost', 'fees', 'resolvesIn', 'expectedPnl', 'pnlAfterSale', 'cancel'];
	closePositionsColumns = ['placedAt', 'position', 'entryPrice', 'exitPrice', 'cost', 'resultType', 'pnl', 'resolvesAt', 'share'];

	subscriptions: Subscription[] = [];

	openPositionsLoading$: Observable<boolean>;
	resolvedPositionsLoading$: Observable<boolean>;

	asset: SpotTradeAsset | undefined;
	priceStream!: Subscription;
	miniTicker!: BinanceMiniTicker | SolusStreamMessage['k'];

	TradePosition = TradePosition;
	ASSET_MAX_DECIMAL_PLACES = ASSET_MAX_DECIMAL_PLACES;

	currentPageIndex: number = 0;
	itemsPerPage: number = 50;

	constructor(private api: APIService, private recaptcha: ReCaptchaV3Service, private matDialog: MatDialog, private marketService: MarketService, private webSocketService: WebsocketService) {
		this.openPositionsLoading$ = this.marketService.openPositionsLoading$;
		this.resolvedPositionsLoading$ = this.marketService.resolvedPositionsLoading$;
	}

	ngOnInit(): void {
		const subSelectedAsset = this.marketService.selectedAsset$.subscribe((asset) => {
			if (asset) {
				this.asset = asset;

				if (this.openPositions) {
					// Spot Price Web Socket
					this.priceStream = this.webSocketService.getWebSocketStream(this.asset?.tradingViewSymbol.includes(SOLUS_OTC_PREFIX))?.pipe(retry({ delay: 3000 })).subscribe({
						next: (data: BinanceStreamMessage | SolusStreamMessage) => {

							if (!this.asset?.tradingViewSymbol.includes(SOLUS_OTC_PREFIX)) {
								const ticker = data as BinanceStreamMessage;
								if (ticker.data) {
									this.miniTicker = ticker.data;
								}
							} else {
								const ticker = data as SolusStreamMessage;
								if (ticker.k) {
									this.miniTicker = ticker.k;
								}
							}
						}
					});
					this.subscriptions.push(this.priceStream);

					this.columns = this.openPositionsColumns;
					const sub = this.marketService.openTrades$.subscribe((positions) => {
						if (positions) {
							this.trades.data = positions;
						}
					});
					this.subscriptions.push(sub);
				} else {
					this.columns = this.closePositionsColumns;
					this.trades.data = this.marketService.closeTrades;
					const sub = this.marketService.closeTrades$.subscribe((positions) => {
						if (positions) {
							this.trades.data = positions;
						}
					});
					this.subscriptions.push(sub);
				}
			}
		});
		this.subscriptions.push(subSelectedAsset);
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	hasPassed(date: string): boolean {
		return hasPassed(date);
	}

	confirm(index: number) {
		this.trades.data[index].isConfirmDelete = true;
	}

	cancel(tradeId: number, tradeIndex: number) {
		this.trades.data[tradeIndex].isCancelling = true;
		const request: CancelSpotTradeRequest = {
			spotTradeId: tradeId,
			recaptcha: '',
			exitAt: new Date(),
			exitPrice: this.miniTicker.c
		};
		this.api.cancelSpotTrade(request).subscribe({
			next: (response: APIResponse<SpotTrade>) => {
				if (!response.success) {
					this.trades.data[tradeIndex].isCancelling = false;
					this.matDialog.open(DialogComponent, getMatDialogConfig({
						success: false,
						title: 'Exit Failed',
						message: response.body as unknown as string || 'Exit failed due to some error!'
					}));
				}
				this.marketService.cancelTrade(tradeId);
			},
			error: () => {
				this.trades.data[tradeIndex].isCancelling = false;
			}
		});
	}

	getResolvesInPercentage(resolvesAt: string) {
		const exitingAt = moment(resolvesAt);
		const currentTime = moment();

		// Remaining time is totalDuration - elapsed time
		const remainingSec = Math.max(exitingAt.diff(currentTime, 'seconds'), 0);

		const formatTime = (time: number): string => (time < 10 ? `0${time}` : `${time}`);

		// Calculate remaining hours, minutes, and seconds
		const hours = formatTime(Math.floor(remainingSec / 3600));
		const minutes = formatTime(Math.floor((remainingSec % 3600) / 60));
		const seconds = formatTime(remainingSec % 60);

		return `${hours}:${minutes}:${seconds}`;
	}

	ontick(event: TimeInterface) {
		console.log(event);
	}

	checkTwoThirdIntervalPassed(exitingAt: moment.Moment, enteredAt: moment.Moment, expiresAt: moment.Moment) {
		const totalSeconds = Math.abs(enteredAt.diff(moment(expiresAt), 'seconds'));
		const twoThirdInterval = (2 * totalSeconds) / 3;
		const passedSeconds = Math.abs(enteredAt.diff(exitingAt, 'seconds'));

		return twoThirdInterval <= passedSeconds;
	}

	checkIntervalPassed(trade: SpotTrade) {
		return this.checkTwoThirdIntervalPassed(moment(), moment(trade.enteredAt), moment(trade.expiresAt));
	}

	shareTrade(trade: SpotTrade) {
		this.matDialog.open(ShareTradeDialogComponent, {
			width: '348px',
			data: {
				trade: trade
			},
			panelClass: 'share-trade-dialog'
		});
	}

	onScroll() {
		if (!this.openPositions) {
			this.currentPageIndex++;
			this.marketService.getResolvedPositions(false, this.currentPageIndex, this.itemsPerPage, true);
		}
	}
}
