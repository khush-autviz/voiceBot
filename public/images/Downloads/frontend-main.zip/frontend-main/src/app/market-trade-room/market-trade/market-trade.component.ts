import { BreakpointObserver } from '@angular/cdk/layout';
import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnDestroy, OnInit, TemplateRef, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatChipsModule } from '@angular/material/chips';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule, MatMenuTrigger } from '@angular/material/menu';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar, MatSnackBarModule, MatSnackBarRef } from '@angular/material/snack-bar';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { Title } from '@angular/platform-browser';
import { Subscription } from 'rxjs';
import { IChartingLibraryWidget, ResolutionString } from 'src/assets/js/charting_library/charting_library';
import { TvChartContainerComponent } from 'src/components/tv-chart-container/tv-chart-container.component';
import { assetsSortByName } from 'src/constants/constants';
import { ImageErrorDirective } from 'src/directives/image-error.directive';
import { APIService } from 'src/service/api.service';
import { MarketService } from 'src/service/market.service';
import { StateService } from 'src/service/state.service';
import { TvChartService } from 'src/service/tv-chart.service';
import { Asset, SpotTradeAsset } from 'src/types/app.types';
import { MarketInfoComponent } from '../market-info/market-info.component';
import { MarketPositionsTableComponent } from '../market-positions-table/market-positions-table.component';

const materialModules = [MatCardModule, MatIconModule, MatMenuModule, MatFormFieldModule, MatInputModule, MatTableModule, MatTabsModule, MatSelectModule, MatButtonModule, MatChipsModule, MatSnackBarModule];
const components = [TvChartContainerComponent, MarketInfoComponent, MarketPositionsTableComponent];

@Component({
	selector: 'app-market-trade',
	standalone: true,
	imports: [CommonModule, ImageErrorDirective, ReactiveFormsModule, ...materialModules, ...components],
	templateUrl: './market-trade.component.html',
	styleUrls: ['./market-trade.component.scss'],
	encapsulation: ViewEncapsulation.None
})
export class MarketTradeComponent implements OnInit, OnDestroy {
	assets: SpotTradeAsset[] = [];
	asset!: Asset;
	timezone: string = '';
	isMobileDevice: boolean = false;
	columns: string[] = ['name', 'profit'];
	variations = new Set<number>();
	dataSource: Partial<SpotTradeAsset>[] = [];
	filteredDataSource: Partial<SpotTradeAsset>[] = [];
	searchAssetControl = new FormControl('');
	assetHistory: SpotTradeAsset[] = [];
	subscriptions: Subscription[] = [];

	_tvWidget: IChartingLibraryWidget | undefined;
	resolutionTimes: { label: string, value: string }[] = [
		{
			label: '1m',
			value: '1'
		},
		{
			label: '5m',
			value: '5'
		},
		{
			label: '15m',
			value: '15'
		},
	];

	@ViewChild('menuTrigger') trigger!: MatMenuTrigger;

	@ViewChild('otcSnackbarTemplate', { static: true })
	otcSnackbarTemplate!: TemplateRef<any>;

	snackbarRef!: MatSnackBarRef<any>;
	snackbarOpened: boolean = false;

	constructor(private api: APIService, private title: Title, private marketService: MarketService, private breakpointObserver: BreakpointObserver, private cd: ChangeDetectorRef, private stateService: StateService, private tvChartService: TvChartService, private snackbar: MatSnackBar) {

		const sub = this.breakpointObserver.observe('only screen and (orientation: landscape) and (max-height: 575.98px)').subscribe({
			next: (breakpointState) => {
				this.isMobileDevice = breakpointState.matches;
			}
		});
		this.subscriptions.push(sub);

		const assetsSub = this.marketService.assets$.subscribe({
			next: (assets) => {
				this.assets = assets.sort(assetsSortByName);

				this.dataSource = [];

				this.assets.forEach((asset) => {
					let profits = {};
					asset.variations.forEach((variation) => {
						const duration = variation.duration / 60;

						profits = { ...profits, [duration]: variation.isActive ? variation.winMultiplier : 0 };

						this.variations.add(duration);
					});

					this.dataSource.push({ ...asset, profits });
				});

				this.filteredDataSource = this.dataSource;
				this.sortFilteredDataSource();

				this.columns = ['name'];
				this.variations.forEach(v => {
					const variationPresent = this.dataSource.some(row => {
						if ((row.profits?.[v] || 0) > 0) {
							return true;
						}
						return false;
					});

					if (variationPresent) {
						this.columns.push(`profit_${v}m`);
					}
				});
			}
		});
		this.subscriptions.push(assetsSub);

		const assetHistorySub = this.marketService.assetHistory$.subscribe((assetHistory) => {
			this.assetHistory = assetHistory;
		});
		this.subscriptions.push(assetHistorySub);
	}

	ngOnInit(): void {
		this.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone.replace("Calcutta", "Kolkata");

		const sub = this.marketService.selectedAsset$.subscribe((asset: Asset | undefined) => {
			if (asset) {
				let newAsset = false;
				if (this.asset?.id !== asset.id) {
					newAsset = true;
				}

				this.asset = asset;

				this.title.setTitle(this.asset.name + ' / Solus');


				// * DEPRECATED: This is not being used in the app right now
				// this.api.getNews(this.asset.token, 5).subscribe({
				// 	next: (response: PanicNews) => {
				// 		this.assetNews = response?.results || [];
				// 	}
				// });

				if (newAsset) {
					this.cd.detectChanges();

					if (!this.snackbarOpened && asset.token.toLowerCase().includes('otc')) {
						this.snackbarRef = this.snackbar.openFromTemplate(this.otcSnackbarTemplate, { duration: 6000, horizontalPosition: 'center', verticalPosition: 'top', panelClass: 'snackbar-info', });

						const snackbarOpenSub = this.snackbarRef.afterOpened().subscribe(() => {
							this.snackbarOpened = true;
						});
						this.subscriptions.push(snackbarOpenSub);

						const snackbarDismissedSub = this.snackbarRef.afterDismissed().subscribe(() => {
							this.snackbarOpened = false;
						});
						this.subscriptions.push(snackbarDismissedSub);
					}
				}
			}
		});
		this.subscriptions.push(sub);

		const formControlSub = this.searchAssetControl.valueChanges.subscribe((value) => {
			if (value && value.length > 0) {
				this.filteredDataSource = this.dataSource.filter((asset) => asset.name?.toLowerCase()?.includes(value.toLowerCase()) || asset.token?.toLowerCase()?.includes(value.toLowerCase()));
			} else {
				this.filteredDataSource = this.dataSource;
			}
			this.sortFilteredDataSource();

		});
		this.subscriptions.push(formControlSub);

		const tvSub = this.tvChartService.tvWidget$.subscribe({
			next: (tvWidget) => {
				if (tvWidget) {
					this._tvWidget = tvWidget;
				}
			}
		});
		this.subscriptions.push(tvSub);
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach(sub => sub.unsubscribe());
	}

	onNewsItemClick(url: string) {
		window.open(url, '_blank');
	}

	menuDisableClose(event: any) {
		event.stopPropagation();
	}

	changeSelectedAsset(asset: SpotTradeAsset) {
		this.trigger.closeMenu();
		this.marketService.changeSelectedAsset(asset);
	}

	toggleIndicators() {
		this._tvWidget?.activeChart?.()?.executeActionById('insertIndicator');
	}

	setResolutionTime(time: string) {
		this._tvWidget?.activeChart?.()?.setResolution(time as ResolutionString);
	}

	getCurrentResolutionTime() {
		try {
			return this._tvWidget?.activeChart?.()?.resolution();
		} catch (error) {
			return '1';
		}
	}

	removeAssetHistory(assetId: number) {
		this.marketService.removeAssetHistory(assetId);
	}

	sortFilteredDataSource() {
		this.filteredDataSource = this.filteredDataSource.sort((a, b) => {
			// Check if both items have profits and use the first key in profits for comparison
			if (a.profits && b.profits) {
				const variationA = Object.keys(a.profits)[0];
				const variationB = Object.keys(b.profits)[0];

				const profitA = a.profits?.[variationA] || 0;
				const profitB = b.profits?.[variationB] || 0;

				// If profits are different, sort by profits in descending order
				if (profitA !== profitB) {
					return profitB - profitA; // Sort by profits, descending
				}
			}

			// If profits are the same (or don't exist), sort by token alphabetically
			return (a.token || '').localeCompare(b.token || '');
		});
	}

	checkAssetDisable(row: Partial<SpotTradeAsset>) {
		if (row && row.profits) {
			return Object.values(row.profits).every(v => v === 0);
		}
		return false;
	}
}
