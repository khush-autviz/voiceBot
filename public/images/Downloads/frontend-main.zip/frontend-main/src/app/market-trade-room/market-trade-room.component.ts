import { CommonModule } from '@angular/common';
import { Component, OnDestroy, ViewEncapsulation } from '@angular/core';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatDrawerMode, MatSidenavModule } from '@angular/material/sidenav';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { DEPOSIT } from 'src/constants/ui.routes';
import { MarketService } from 'src/service/market.service';
import { StateService } from 'src/service/state.service';
import { SocialButton, SpotTradeAsset } from 'src/types/app.types';
import { MarketTradeComponent } from './market-trade/market-trade.component';

const materialModules = [MatProgressBarModule, MatSidenavModule];
const components = [MarketTradeComponent];

@Component({
	selector: 'app-market-trade-room',
	standalone: true,
	imports: [CommonModule, ...materialModules, ...components],
	templateUrl: './market-trade-room.component.html',
	styleUrls: ['./market-trade-room.component.scss'],
	encapsulation: ViewEncapsulation.None,
})
export class MarketTradeRoomComponent implements OnDestroy {
	navbarMode: MatDrawerMode = 'side';
	navbarOpen: boolean = true;
	socials: SocialButton[] = [
		{
			title: 'Follow @SolusFinance',
			logo: '../../assets/twitter.svg',
			link: 'https://rebrand.ly/96cadu1',
			theme: '#1DA1F2',
			color: '#FFF',
		},
		{
			title: 'Join Our Telegram',
			logo: '../../assets/telegram.svg',
			link: 'https://rebrand.ly/uc60li1',
			theme: 'linear-gradient(180deg, #2AABEE 0%, #229ED9 100%)',
			color: '#FFF',
		},
	];

	assets: SpotTradeAsset[] = [];
	selectedAsset$: Observable<SpotTradeAsset | undefined>;
	loading$: Observable<boolean>;

	subscriptions: Subscription[] = [];

	constructor(private router: Router, title: Title, private marketService: MarketService, private stateService: StateService) {
		title.setTitle('Markets / Solus');

		const sub = this.marketService.assets$.subscribe({
			next: (assets) => {
				this.assets = assets.sort((a, b) => {
					// Remove 'OTC' from the end if it exists
					const aBase = a.name.replace(/ OTC$/, '');
					const bBase = b.name.replace(/ OTC$/, '');

					// If the base names are the same but one is OTC, place the OTC version after
					if (aBase === bBase) {
						if (a.name.endsWith("OTC")) return -1;
						if (b.name.endsWith("OTC")) return 1;
					}

					// Otherwise, sort by base name
					return aBase.localeCompare(bBase);
				});
			}
		});
		this.subscriptions.push(sub);
		this.selectedAsset$ = this.marketService.selectedAsset$;
		this.loading$ = this.marketService.loading$;
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach((sub) => sub.unsubscribe());
	}

	goToDeposit() {
		this.router.navigate([DEPOSIT]);
	}

	changeSelectedAsset(asset: SpotTradeAsset) {
		this.marketService.changeSelectedAsset(asset);
	}

	open() {
		this.navbarOpen = !this.navbarOpen;
	}

	openSocial(link: string) {
		window.open(link, '_blank');
	}

	depositClick() {
		this.router.navigate([DEPOSIT]);
	}

}
