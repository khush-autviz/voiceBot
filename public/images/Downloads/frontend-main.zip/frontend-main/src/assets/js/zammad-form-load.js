

// Initialize Zammad form once the script is loaded
function waitForEl(selector, callback, maxTimes) {
	if (document.querySelector(selector)) {
		callback();
	} else if (maxTimes > 0) {
		maxTimes--;
		setTimeout(function () {
			waitForEl(selector, callback, maxTimes);
		}, 100);
	}
}

waitForEl(
	"#zammad-feedback-form",
	function () {
		var zammadElement = document.querySelector("#zammad-feedback-form");

		if (zammadElement) {
			zammadElement.ZammadForm({
				messageTitle: "Feedback Form",
				messageSubmit: "Submit",
				messageThankYou:
					"Thank you for your inquiry (#%s)! We'll contact you as soon as possible.",
				modal: false,
				debug: true,
				showTitle: true,
				attachmentSupport: true,
				noCSS: true,
			});
		}
	},
	10
);
