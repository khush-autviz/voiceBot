var complycubeSDK = {
    complycube: {},
    startVerification: (token) => startVerification(token),
}

function startVerification(token)  {
    complycubeSDK.complycube = ComplyCube.mount({
        token: token,
        containerId: 'complycube-mount',
        disableClientAnalytics: false,
        onComplete: onComplete,
        onModalClose: closeModal,
        onError: onError,
        onExit: onExit,
    });
}

function onComplete(data) {
    returnToAngular('complete', data);
    closeModal();
}
 
function closeModal() {
    returnToAngular('close', null);
    complycubeSDK.complycube.updateSettings({ isModalOpen: false })
}

function onError(error) {
    returnToAngular('error', error);
}

function onExit(cause) {
    returnToAngular('exit', cause);
}

function returnToAngular(name, data) {
    var event = new CustomEvent(`complycube:${name}`, { detail: data, bubbles: false, cancelable: false });
    window.dispatchEvent(event);
}

var cobrand = {
    branding : {
        appearance: {
            primaryButtonColor: '#461f54',
            primaryButtonHoverColor: '#371743',
            primaryButtonBorderColor: '#7e6287',
            documentSelectorActiveBorderColor: '#461f54',
            documentSelectorHoverBorderColor: '#461f54',
            linkHoverColor: '#7e6287',
            linkUnderlineColor: '#7e6287',
            cameraButtonHoverColor: '#461f54'
        },
        textBrand: 'KYC for Solus is'
    },
}