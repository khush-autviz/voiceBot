import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { map } from 'rxjs';
import { FUTURES, MARKETS, ONBOARDING } from 'src/constants/ui.routes';
import { StateService } from 'src/service/state.service';
import { SolusMode } from 'src/types/app.types';

export const marketModeGuard: (mode: SolusMode) => CanActivateFn = (mode: SolusMode) => (route, state) => {
	const stateService = inject(StateService);
	const router = inject(Router);

	return stateService.state$.pipe(map((appState) => {
		if (appState.mode === mode) {
			return true;
		} else if (appState.mode === SolusMode.FUTURES) {
			return router.createUrlTree([FUTURES, MARKETS]);
		} else if (appState.mode === SolusMode.PRICE_PREDICTION) {
			return router.createUrlTree([MARKETS]);
		}

		return router.createUrlTree([ONBOARDING]);
	}));
};
