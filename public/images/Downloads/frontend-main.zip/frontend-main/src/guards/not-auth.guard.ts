import { Injectable, OnDestroy } from "@angular/core";
import { Router, UrlTree } from "@angular/router";
import { Observable, map } from "rxjs";
import { StateService } from "src/service/state.service";
import { MARKETS } from "src/constants/ui.routes";

@Injectable({
	providedIn: 'root'
})
export class NotAuthGuard implements OnDestroy {

	constructor(private stateService: StateService, private router: Router) {
	}

	canActivate(): Observable<boolean | UrlTree> {
		return this.stateService.state$.pipe(
			map(state => {
				return state.jwt !== null ? this.router.createUrlTree([MARKETS]) : true
			})
		);
	}

	ngOnDestroy(): void {
	}

}
