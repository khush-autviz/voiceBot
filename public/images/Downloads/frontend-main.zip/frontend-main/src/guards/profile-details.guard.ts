import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { map } from 'rxjs';
import { MARKETS, PROFILE_DETAILS } from 'src/constants/ui.routes';
import { APIService } from 'src/service/api.service';
import { StateService } from 'src/service/state.service';
import { User } from 'src/types/app.types';

export const profileDetailsGuard: CanActivateFn = (route, state) => {
	const api = inject(APIService);
	const router = inject(Router);
	const appState = inject(StateService).getState();

	return api.getUser(appState.coin, true).pipe(
		map(res => {
			if(res.success) {
				const user = res.body;

				if (userProfileExists(user)) {
					if(route.routeConfig?.path === PROFILE_DETAILS) {
						return router.createUrlTree([MARKETS]);
					}
					return true;
				} else {
					if(route.routeConfig?.path === PROFILE_DETAILS) {
						return true;
					}
				}
			}
			return router.createUrlTree([PROFILE_DETAILS], { queryParamsHandling: 'merge' });
		})
	);
};

const userProfileExists = (user: User) => {
	if (user) {
		const { email, profile } = user;

		if (email && profile) {
			const { name } = profile;

			return email && name;
		}
	}
	return false;
}

