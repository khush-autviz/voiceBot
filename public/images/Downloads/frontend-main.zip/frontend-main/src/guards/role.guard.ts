import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { map } from 'rxjs';
import { APIService } from 'src/service/api.service';
import { StateService } from 'src/service/state.service';
import { UserRole } from 'src/types/app.types';

export const roleGuard: (roles: UserRole[], alternateRoute: string) => CanActivateFn = (roles: UserRole[], alternateRoute: string) => (route, state) => {
	const api = inject(APIService);
	const router = inject(Router);
	const appState = inject(StateService).getState();

	return api.getUser(appState.coin, true).pipe(
		map(res => {
			if (res.success) {
				const user = res.body;
				const isAffiliate = user.affiliate;
				const userRole = isAffiliate ? UserRole.AFFILIATE_USER : UserRole.GENERIC_USER;

				if (roles.includes(userRole)) {
					return true;
				} else {
					return router.createUrlTree([alternateRoute]);
				}
			}
			return router.createUrlTree([alternateRoute]);
		})
	);
};
