import { Injectable, OnDestroy } from "@angular/core";
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot, UrlTree } from "@angular/router";
import { Observable, map } from "rxjs";
import { StateService } from "src/service/state.service";
import { LOG_IN } from "src/constants/ui.routes";

@Injectable({
	providedIn: 'root'
})
export class AuthGuard implements OnDestroy {

	constructor(private stateService: StateService, private router: Router) {
	}

	canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean | UrlTree> {
		return this.stateService.state$.pipe(
			map(appState => {
				if (appState.jwt === null) {
					return this.router.createUrlTree([LOG_IN], { queryParams: { redirectUri: state.url }, queryParamsHandling: 'merge' })
				} else {
					return true;
				}
			})
		);
	}

	ngOnDestroy(): void {
	}

}
