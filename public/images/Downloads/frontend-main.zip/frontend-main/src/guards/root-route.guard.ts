import { inject } from '@angular/core';
import { ActivatedRoute, CanActivateFn, Router } from '@angular/router';
import { LOG_IN, MARKETS } from 'src/constants/ui.routes';
import { StateService } from 'src/service/state.service';

export const rootRouteGuard: CanActivateFn = (route, state) => {
	const stateService = inject(StateService);
	const router = inject(Router);

	const logoutValue = route.queryParams['logout'];
	if (logoutValue == 1) {
		stateService.onLogout([LOG_IN]);
		return false;
	}

	if (stateService.getState().jwt) {
		stateService.switchModeViaQueryParams(route.queryParams);
		router.navigate([route.queryParams['redirectUri'] || MARKETS]);
		return false;
	}
	return true;
};
