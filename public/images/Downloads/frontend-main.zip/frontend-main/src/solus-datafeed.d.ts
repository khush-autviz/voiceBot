declare module 'solus-datafeed';
