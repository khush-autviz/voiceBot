import { HttpErrorResponse } from '@angular/common/http';
import { Injectable, OnDestroy } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { BehaviorSubject, Subscription } from 'rxjs';
import { DialogComponent } from 'src/components/dialog/dialog.component';
import { getMatDialogConfig } from 'src/constants/constants';
import { environment } from 'src/environment/environment';
import { APIResponse, PolygonScanResponse, State, Transaction, UserDepositBonus } from 'src/types/app.types';
import { APIService } from './api.service';
import { StateService } from './state.service';

@Injectable({
	providedIn: 'root'
})
export class CashInService implements OnDestroy {
	depositAddress: string = '';
	depositAddress$ = new BehaviorSubject<string>(this.depositAddress);

	transaction: Transaction | undefined = undefined;
	transaction$ = new BehaviorSubject<Transaction | undefined>(this.transaction);

	depositStatusInterval: NodeJS.Timeout | undefined;
	depositAddressInterval: NodeJS.Timeout | undefined;

	state: State;

	subscriptions: Subscription[] = [];

	bonuses: UserDepositBonus[] = [];
	bonuses$ = new BehaviorSubject<UserDepositBonus[]>(this.bonuses);

	voucherCode: string = '';

	constructor(private api: APIService, private matDialog: MatDialog, private stateService: StateService) {
		this.state = stateService.getState();
		const sub = this.stateService.state$.subscribe({
			next: (state: State) => {
				this.state = state;
				if (this.state.jwt !== null) {
					if (!this.depositAddressInterval && !this.depositAddress) {
						clearInterval(this.depositAddressInterval);
						this.startDepositAddressFetch();
					}
				} else {
					this.destroyDepositStatusCheck();
					clearInterval(this.depositAddressInterval);
				}
			}
		});
		this.subscriptions.push(sub);
	}

	startDepositAddressFetch() {
		this.depositAddressInterval = setInterval(() => {
			if (this.depositAddress) {
				clearInterval(this.depositAddressInterval);
				return;
			}

			this.api.getDepositAddress().subscribe({
				next: (response: APIResponse<string>) => {
					if (response.success) {
						if (this.depositAddress !== response.body) {
							this.depositAddress = response.body;
							this.depositAddress$.next(this.depositAddress);
						}
						clearInterval(this.depositAddressInterval);
					} else {
						if (environment.production) {
							this.createDepositAddress();
						} else {
							this.mockDepositAddress();
						}
					}
				}
			});
		}, 5000);
	}

	getDepositAddress() {
		this.api.getDepositAddress().subscribe({
			next: (response: APIResponse<string>) => {
				if (response.success) {
					this.depositAddress = response.body;
					this.depositAddress$.next(this.depositAddress);
				}
			}
		});
	}

	createDepositAddress() {
		this.api.createDepositAddress().subscribe({
			next: (response: APIResponse<string>) => {
				if (response.success) {
					if (this.depositAddress !== response.body) {
						this.depositAddress = response.body;
						this.depositAddress$.next(this.depositAddress);
					}
				}
			},
			error: (err: HttpErrorResponse) => {
				if (err.status !== 504) {
					this.matDialog.open(DialogComponent, getMatDialogConfig({
						success: false,
						title: 'Could not create Deposit Address',
						message: err.message
					}));
				}
			}
		});
	}

	mockDepositAddress() {
		if (!this.depositAddress) {
			this.depositAddress = '0xFeAf2e00DC0037C78B3cAF003E560267A083f2c5';
			this.depositAddress$.next(this.depositAddress);
		}
	}

	checkDepositStatus(address: string) {
		this.destroyDepositStatusCheck();

		this.depositStatusInterval = setInterval(() => {
			this.api.getPolygonScanTransactions(address).subscribe({
				next: (response: PolygonScanResponse) => {
					if (environment.production) {
						if (response && response.status && response.result && Array.isArray(response.result) && response.result.length > 0) {
							response.result.forEach(transaction => {
								// TODO: Need to make this synchronous
								this.claimDepositByHash(transaction.hash);
							});
						}
					}
				}
			});
		}, 10000);
	}

	claimDepositByHash(hash: string) {
		this.api.getDepositTokenFromHash({ transactionHash: hash }, this.voucherCode).subscribe({
			next: (res: APIResponse<Transaction>) => {
				if (res.success) {
					if (this.transaction?.txnId !== res.body.txnId) {
						this.transaction = res.body;
						this.transaction$.next(this.transaction);
					}
				}
			}
		});
	}

	destroyDepositStatusCheck() {
		clearInterval(this.depositStatusInterval);
	}

	resetTransaction() {
		this.transaction = undefined;
		this.transaction$.next(undefined);
	}

	setBonuses(bonuses: UserDepositBonus[]) {
		this.bonuses = bonuses;
		this.bonuses$.next(this.bonuses);
	}

	ngOnDestroy(): void {
		clearInterval(this.depositStatusInterval);
		clearInterval(this.depositAddressInterval);

		this.subscriptions.forEach(sub => sub.unsubscribe());
	}
}
