import { HttpErrorResponse } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { MatDialog, MatDialogRef, MatDialogState } from "@angular/material/dialog";
import { ActivatedRoute, Params, Router } from "@angular/router";
import * as moment from "moment";
import { BehaviorSubject, forkJoin } from "rxjs";
import { DialogComponent } from "src/components/dialog/dialog.component";
import { COIN, INITIAL_STATE, JWT, JWT_CREATED_AT, MODE, getMatDialogConfig } from "src/constants/constants";
import { FUTURES, LOG_IN, MARKETS, ONBOARDING, PROFILE_DETAILS } from "src/constants/ui.routes";
import { APIResponse, AppConfig, AppConfigEnum, Balance, SolusCurrency, SolusMode, State, SupportedCoin, User } from "src/types/app.types";
import { APIService } from "./api.service";

@Injectable({
	providedIn: 'root',
})
export class StateService {

	private state: State = { ...INITIAL_STATE };
	public state$: BehaviorSubject<State> = new BehaviorSubject<State>(this.state);
	public loginViaWallet: boolean = false;
	public appConfig: AppConfig[] = [];

	accountSuspendDialogRef: MatDialogRef<DialogComponent> | undefined;

	constructor(private api: APIService, private router: Router, private matDialog: MatDialog, private route: ActivatedRoute) {
		const coin: string | null = this.getStringFromLocalStorage(COIN);
		this.state.coin = coin === null ? SupportedCoin.USDT : SupportedCoin[coin as keyof typeof SupportedCoin];
		this.state.jwt = this.getStringFromLocalStorage(JWT);
		const mode: string | null = this.getStringFromLocalStorage(MODE);
		this.state.mode = mode === null ? SolusMode.PRICE_PREDICTION : SolusMode[mode as keyof typeof SolusMode];
		if (this.state.jwt === null) {
			this.state$.next(this.state);
		}
		else {
			this.refreshUserBalanceCurrency();
		}

		this.state$.subscribe((state) => {
			if (state && state.jwt != null) {
				if (["315134218@qq.com", "1131243641@qq.com", "2602693604@qq.com", "758573250@qq.com", "1656057726@qq.com", "963147606@qq.com"].includes(state?.user?.email || '')) {
					this.onLogout();
					if (this.accountSuspendDialogRef?.getState() !== MatDialogState.OPEN) {
						this.accountSuspendDialogRef = this.matDialog.open(DialogComponent, getMatDialogConfig({
							success: false,
							title: 'Account Suspended',
							message: "This account is temporarily suspended. Please reach out to info@solus.finance for further queries."
						}));
					}
				}
			}

			if (state && state.user) {
				if (this.userProfileExists(state.user)) {
					if (this.route.routeConfig?.path === PROFILE_DETAILS) {
						this.router.navigate([MARKETS]);
					}
				} else {
					if (this.route.routeConfig?.path !== PROFILE_DETAILS) {
						this.router.navigate([PROFILE_DETAILS], { queryParamsHandling: 'merge' });
					}
				}
			}
		});
	}

	private getStringFromLocalStorage(key: string): string | null {
		return localStorage.getItem(key);
	}

	public fetchUser() {
		this.api.getUser(this.state.coin, false).subscribe({
			next: (response: APIResponse<User>) => {
				if (response.success) {
					this.state.user = response.body;
					this.state$.next(this.state);
				}
			},
			error: (err: HttpErrorResponse) => {
				if (err.status === 403) {
					this.onLogout([LOG_IN]);
				}
			}
		});
	}

	public onLogin(jwt: string, route: string = MARKETS, usingWallet: boolean = false, showKYC: boolean = false, mode?: SolusMode, coin?: SupportedCoin) {
		this.loginViaWallet = usingWallet;
		localStorage.setItem(JWT, jwt);
		localStorage.setItem(JWT_CREATED_AT, moment().format('DD-MM-YYYY HH:mm:ss').toString());
		this.state.jwt = jwt;
		if (mode && coin) {
			this.swichMode(mode, coin);
			this.router.navigate([route === ONBOARDING ? [mode === SolusMode.FUTURES ? FUTURES : "", MARKETS].join("/") : ("/" + route)]);
		} else {
			localStorage.setItem(MODE, this.state.mode);
			this.refreshUserBalanceCurrency();
			this.router.navigate([route], { state: { showKYC }, queryParamsHandling: 'merge' });
		}
	}

	public onLogout(next: string[] = []) {
		this.api.clearCache();
		localStorage.clear();
		this.state.jwt = null;
		this.state$.next(this.state);
		if (next.length > 0) {
			this.router.navigate(next, { queryParamsHandling: 'merge' });
		}
	}

	public getState() {
		return this.state;
	}

	swichMode(mode: SolusMode, coin: SupportedCoin | undefined = undefined) {
		this.state.mode = mode;
		localStorage.setItem(MODE, this.state.mode);
		if (coin != undefined) {
			this.state.coin = coin;
			localStorage.setItem(COIN, SupportedCoin[this.state.coin]);
		}
		this.refreshUserBalanceCurrency();
	}

	public refreshUserBalanceCurrency(returnedCached: boolean = true) {
		forkJoin([this.api.getUser(this.state.coin, returnedCached), this.api.getBalance(), this.api.getCurrencies()])
			.subscribe({
				next: ([user, balance, currencies]: [APIResponse<User>, APIResponse<Balance[]>, APIResponse<SolusCurrency[]>]) => {
					this.state.user = user.body;
					this.state.balance = balance.body;
					this.state.currencies = currencies.body;
					this.state$.next(this.state);
				}
			});
	}

	public refreshBalance() {
		this.api.getBalance().subscribe({
			next: (balance: APIResponse<Balance[]>) => {
				this.state.balance = balance.body;
				this.state$.next(this.state);
			},
			error: (err) => {
				console.error('Failed to refresh balance', err);
			}
		});
	}

	switchModeViaQueryParams(queryParams: Params) {
		const redirectUri = queryParams['redirectUri'];

		if (redirectUri) {
			const mode = queryParams['mode'];
			const coin = queryParams['coin'];

			let switchMode = INITIAL_STATE.mode;
			switch (mode) {
				case 'PP':
					switchMode = SolusMode.PRICE_PREDICTION;
					break;
				case 'SP':
					switchMode = SolusMode.FUTURES;
					break;
			}

			let switchCoin = INITIAL_STATE.coin;
			switch (coin) {
				case 'SUS':
					switchCoin = SupportedCoin.SUS;
					break;
				case 'USDT':
					switchCoin = SupportedCoin.USDT;
					break;
			}

			this.state.mode = switchMode;
			localStorage.setItem(MODE, this.state.mode);
			this.state.coin = switchCoin;
			localStorage.setItem(COIN, SupportedCoin[this.state.coin]);
		}
	}

	public getConfig(configKey: AppConfigEnum) {
		return this.appConfig.find(config => config.key === configKey)?.value || null;
	}

	public setConfig(config: AppConfig[]) {
		this.appConfig = config;
	}


	private userProfileExists(user: User) {
		if (user) {
			const { email, profile } = user;

			if (email && profile) {
				const { name } = profile;

				return email && name;
			}
		}
		return false;
	}
}

