import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { IChartingLibraryWidget } from 'src/assets/js/charting_library/charting_library';

@Injectable({
	providedIn: 'root'
})
export class TvChartService {
	private _tvWidget: IChartingLibraryWidget | undefined;
	tvWidget$ = new BehaviorSubject<IChartingLibraryWidget | undefined>(undefined);

	setTVWidget(value: IChartingLibraryWidget) {
		this._tvWidget = value;
		this.tvWidget$.next(this._tvWidget);
	}
}
