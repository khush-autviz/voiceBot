import { HttpClient, HttpContext } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EventSourcePolyfill, MessageEvent } from 'event-source-polyfill';
import { Observable, map, of } from 'rxjs';
import {
	AFFILIATE_REFERRAL,
	AFFILIATE_UPDATE_CLICK_COUNT,
	APPLY_TURNOVER_BONUS,
	ASSETS_BY_ID,
	BALANCE,
	CURRENCY,
	DELETE_ACCOUNT,
	DEMO_RELOAD,
	DEPOSIT_ADDRESS,
	DEPOSIT_UPI,
	DEPOSIT_USDT,
	DEPOSIT_USDT_V2,
	ERROR_LOG,
	FORGOT_PASSWORD_REQUEST_OTP,
	FORGOT_PASSWORD_VERIFY_OTP,
	GET_TURNOVER_BONUS,
	KYC_ALL,
	KYC_START_CHECK,
	KYC_STATUS,
	KYC_STEP_1,
	KYC_STEP_2,
	KYC_STEP_3,
	KYC_STEP_4,
	KYC_TOKEN,
	LISTED_ASSETS,
	LOGIN_WITH_EMAIL,
	LOGIN_WITH_GOOGLE,
	PAYPAL_CANCEL,
	PAYPAL_COMPLETE,
	PAYPAL_INIT,
	POLYGONSCAN_TRANSACTIONS,
	PORTFOLIO_COMBINED,
	RADOM_CREATE_SESSION,
	REFERRAL,
	REFERRAL_TRANSACTIONS,
	REWARDS,
	REWARDS_MAINNET_TOKEN,
	REWARDS_USDT,
	SAVE_PROFILE,
	SCREENSHOT_CAPTURE,
	SEND_OTP,
	SETTINGS,
	SET_PASSWORD,
	SPOT_TRADES,
	SPOT_TRADE_VARIATION,
	TRADE_UPDATES,
	TRANSACTIONS,
	UPI_WITHDRAWAL_CHARGES,
	UPI_WITHDRAWAL_REQUEST,
	USER_DEPOSIT_BONUS,
	USER_INFO_CURRENCY,
	USER_VERIFY_OTP,
	VERIFY_OTP,
	WITHDRAW_UPI,
	WITHDRAW_USDT,
	WITHDRAW_USDT_CHARGES
} from 'src/constants/api.routes';
import { assetsSortByName } from 'src/constants/constants';
import { BYPASS_AUTH_HEADER } from 'src/interceptor/jwt.interceptor';
import {
	APIResponse,
	AppConfig,
	Asset,
	Balance,
	CancelSpotTradeRequest,
	CompletedOrder,
	ComplyCubeDocumentCapture,
	CreateAccountRequest,
	ForgotPasswordRequestOtp,
	ForgotPasswordVerifyOtp,
	JustPassword,
	JwtResponse,
	KnowYourCustomer,
	KycAddressDetails,
	KycData,
	KycPersonalDetails,
	LoginWithGooglePayload,
	MatDialogData,
	Page,
	PasswordLoginRequest,
	PaymentOrder,
	PolygonScanResponse,
	PortfolioCombinedRequest,
	PortfolioCombinedResponse,
	Profile,
	PromoStatusDTO,
	RadomSessionResponse,
	ReferralDto,
	ReferralRewardsDto,
	ReferralTransaction,
	SendOTPResponse,
	SolusCurrency,
	SpotTrade,
	SpotTradeEventType,
	SpotTradeQueryParams,
	SpotTradeRequest,
	SpotTradeVariation,
	SupportedCoin,
	TokenTransaction,
	TokenWithdrawResponse,
	TokenWithdrawalDto,
	Transaction,
	TransactionHashDto,
	TurnoverBonus,
	UPITransaction,
	UPIWithdrawRequest,
	UPIWithdrawal,
	User,
	UserAffiliateReferralDTO,
	UserDepositBonus
} from 'src/types/app.types';

@Injectable({
	providedIn: 'root',
})
export class APIService {

	constructor(private http: HttpClient) {
	}

	private cache: Map<string, APIResponse<any>> = new Map();

	private cached<T>(url: string, returnCached: boolean = true): Observable<APIResponse<T>> {
		const cachedValue: APIResponse<T> | undefined = this.cache.get(url);
		if (cachedValue !== undefined && returnCached) {
			return of(cachedValue);
		} else {
			return this.http.get<APIResponse<T>>(url).pipe(
				map((response: APIResponse<T>) => {
					this.cache.set(url, response);
					return response;
				})
			);
		}
	}

	public clearCache(url: string | null = null): void {
		if (url === null) {
			this.cache.clear();
		} else {
			this.cache.delete(url);
		}
	}

	public log(data: MatDialogData) {
		return this.http.post(ERROR_LOG, data);
	}

	public sendOTP(request: CreateAccountRequest): Observable<APIResponse<SendOTPResponse>> {
		return this.http.post<APIResponse<SendOTPResponse>>(SEND_OTP, request);
	}

	public verifyOTP(request: CreateAccountRequest, loginViaWallet: boolean = false): Observable<APIResponse<JwtResponse>> {
		return this.http.post<APIResponse<JwtResponse>>(loginViaWallet ? USER_VERIFY_OTP : VERIFY_OTP, request);
	}

	public loginWithGoogle(request: LoginWithGooglePayload): Observable<APIResponse<JwtResponse>> {
		return this.http.post<APIResponse<JwtResponse>>(LOGIN_WITH_GOOGLE, request);
	}

	public getBalance(): Observable<APIResponse<Balance[]>> {
		return this.http.get<APIResponse<Balance[]>>(BALANCE);
	}

	public loginWithPassword(loginRequest: PasswordLoginRequest): Observable<APIResponse<JwtResponse>> {
		return this.http.post<APIResponse<JwtResponse>>(LOGIN_WITH_EMAIL, loginRequest);
	}

	public saveProfile(formData: FormData): Observable<APIResponse<Profile>> {
		return this.http.post<APIResponse<Profile>>(SAVE_PROFILE, formData);
	}

	public setPassword(password: JustPassword): Observable<APIResponse<boolean>> {
		return this.http.post<APIResponse<boolean>>(SET_PASSWORD, password);
	}

	public forgotPasswordRequestOtp(body: ForgotPasswordRequestOtp): Observable<APIResponse<boolean>> {
		return this.http.post<APIResponse<boolean>>(FORGOT_PASSWORD_REQUEST_OTP, body);
	}

	public forgotPasswordVerifyOtp(body: ForgotPasswordVerifyOtp): Observable<APIResponse<boolean>> {
		return this.http.post<APIResponse<boolean>>(FORGOT_PASSWORD_VERIFY_OTP, body);
	}

	/** REFERRAL START */

	public referral(): Observable<APIResponse<ReferralDto>> {
		return this.http.get<APIResponse<ReferralDto>>(REFERRAL);
	}

	public referralTransactions(): Observable<APIResponse<ReferralTransaction[]>> {
		return this.http.get<APIResponse<ReferralTransaction[]>>(REFERRAL_TRANSACTIONS);
	}

	public referralRewards(): Observable<APIResponse<ReferralRewardsDto>> {
		return this.http.get<APIResponse<ReferralRewardsDto>>(REWARDS);
	}

	public referralRewardsMainnetToken(): Observable<APIResponse<Page<Transaction>>> {
		return this.http.get<APIResponse<Page<Transaction>>>(REWARDS_MAINNET_TOKEN);
	}

	public referralRewardsUsdt(): Observable<APIResponse<Page<Transaction>>> {
		return this.http.get<APIResponse<Page<Transaction>>>(REWARDS_USDT);
	}

	/** REFERRAL END */

	/** KYC START */

	public getKycDetails(): Observable<APIResponse<KnowYourCustomer>> {
		return this.http.get<APIResponse<KnowYourCustomer>>(KYC_ALL);
	}

	public kycSavePersonalDetails(personalDetails: KycPersonalDetails): Observable<APIResponse<KnowYourCustomer>> {
		return this.http.post<APIResponse<KnowYourCustomer>>(KYC_STEP_1, personalDetails);
	}

	public kycSaveAddressDetails(addressDetails: KycAddressDetails): Observable<APIResponse<KnowYourCustomer>> {
		return this.http.post<APIResponse<KnowYourCustomer>>(KYC_STEP_2, addressDetails);
	}

	public kycSaveDocumentCapture(documentCapture: ComplyCubeDocumentCapture): Observable<APIResponse<KycData>> {
		return this.http.post<APIResponse<KycData>>(KYC_STEP_3, documentCapture);
	}

	public kycSaveUserAgreement(): Observable<APIResponse<KycData>> {
		return this.http.post<APIResponse<KycData>>(KYC_STEP_4, {});
	}

	public kycStartCheck(): Observable<APIResponse<KycData>> {
		return this.http.get<APIResponse<KycData>>(KYC_START_CHECK);
	}

	public kycCheckStatus(): Observable<APIResponse<KycData>> {
		return this.http.get<APIResponse<KycData>>(KYC_STATUS);
	}

	public kycGetSdkToken(): Observable<APIResponse<string>> {
		return this.http.get<APIResponse<string>>(KYC_TOKEN);
	}

	/** KYC END */


	/**  CASH IN / CASH OUT START */

	public getDeposits(): Observable<APIResponse<Page<TokenTransaction>>> {
		return this.http.get<APIResponse<Page<TokenTransaction>>>(DEPOSIT_USDT);
	}

	public getWithdrawals(): Observable<APIResponse<Page<TokenTransaction>>> {
		return this.http.get<APIResponse<Page<TokenTransaction>>>(WITHDRAW_USDT);
	}

	public withdrawToken(dto: TokenWithdrawalDto): Observable<APIResponse<TokenWithdrawResponse>> {
		return this.http.post<APIResponse<TokenWithdrawResponse>>(WITHDRAW_USDT, dto);
	}

	public getWithdrawalCharges(dto: TokenWithdrawalDto): Observable<APIResponse<number>> {
		return this.http.post<APIResponse<number>>(WITHDRAW_USDT_CHARGES, dto);
	}

	public getTransactions(coin: SupportedCoin, referenceId?: number): Observable<APIResponse<Page<Transaction>>> {
		return this.http.get<APIResponse<Page<Transaction>>>(TRANSACTIONS(coin, referenceId));
	}

	/**  CASH IN / CASH OUT END */

	/** CACHED API CALLS START **/

	public getUser(coin: SupportedCoin, returnCached: boolean = true): Observable<APIResponse<User>> {
		return this.cached(USER_INFO_CURRENCY(coin), returnCached);
	}

	public getAssetById(id: number): Observable<APIResponse<Asset>> {
		return this.cached(ASSETS_BY_ID(id));
	}

	public getListedAssets(): Observable<APIResponse<Asset[]>> {
		return this.cached(LISTED_ASSETS);
	}

	public getCurrencies(): Observable<APIResponse<SolusCurrency[]>> {
		return this.cached(CURRENCY);
	}

	/** CACHED API CALLS END **/

	/** SETTINGS START */

	public getSettings(): Observable<APIResponse<AppConfig[]>> {
		return this.http.get<APIResponse<AppConfig[]>>(SETTINGS);
	}

	/** SETTINGS END */

	/** PORTFOLIO START */

	public getPortfolioCombined(request: PortfolioCombinedRequest): Observable<APIResponse<PortfolioCombinedResponse>> {
		return this.http.post<APIResponse<PortfolioCombinedResponse>>(PORTFOLIO_COMBINED, request);
	}

	/** PORTFOLIO END */

	/** DEPOSIT START */

	public getDepositAddress(): Observable<APIResponse<string>> {
		return this.http.get<APIResponse<string>>(DEPOSIT_ADDRESS);
	}

	public createDepositAddress(): Observable<APIResponse<string>> {
		return this.http.post<APIResponse<string>>(DEPOSIT_ADDRESS, {});
	}

	public getPolygonScanTransactions(address: string): Observable<PolygonScanResponse> {
		return this.http.get<PolygonScanResponse>(POLYGONSCAN_TRANSACTIONS(address), { context: new HttpContext().set(BYPASS_AUTH_HEADER, true) });
	}

	public getDepositTokenFromHash(transactionHashDto: TransactionHashDto, voucherCode: string): Observable<APIResponse<Transaction>> {
		return this.http.post<APIResponse<Transaction>>(DEPOSIT_USDT_V2, transactionHashDto, {
			params: {
				voucherCode
			}
		});
	}

	public initPayPalPayment(currencyCode: string, amount: number, voucherCode: string): Observable<APIResponse<PaymentOrder>> {
		return this.http.post<APIResponse<PaymentOrder>>(PAYPAL_INIT, {}, {
			params: {
				currencyCode,
				amount,
				voucherCode
			}
		});
	}

	public completePayPalPayment(trxId: string): Observable<APIResponse<CompletedOrder>> {
		return this.http.post<APIResponse<CompletedOrder>>(PAYPAL_COMPLETE, {}, {
			params: {
				trxId
			}
		});
	}

	public cancelPayPalPayment(trxId: string): Observable<APIResponse<void>> {
		return this.http.post<APIResponse<void>>(PAYPAL_CANCEL, {}, {
			params: {
				trxId
			}
		});
	}

	/** DEPOSIT END */

	/** SPOT TRADING START */

	public getSpotTradeVariations(currencyId: number): Observable<APIResponse<Page<SpotTradeVariation>>> {
		return this.http.get<APIResponse<Page<SpotTradeVariation>>>(SPOT_TRADE_VARIATION, { params: { currencyId } });
	}

	public placeSpotTrade(spotTradeRequest: SpotTradeRequest): Observable<APIResponse<SpotTrade>> {
		return this.http.post<APIResponse<SpotTrade>>(SPOT_TRADES, spotTradeRequest);
	}

	public cancelSpotTrade(spotTradeRequest: CancelSpotTradeRequest): Observable<APIResponse<SpotTrade>> {
		return this.http.put<APIResponse<SpotTrade>>(SPOT_TRADES, spotTradeRequest);
	}

	public getSpotTrades(spotTradeQueryParams: SpotTradeQueryParams): Observable<APIResponse<Page<SpotTrade>>> {
		return this.http.get<APIResponse<Page<SpotTrade>>>(SPOT_TRADES, {
			params: spotTradeQueryParams
		});
	}

	/** SPOT TRADING END */

	/** DEMO RELOAD START */

	public reloadDemoAccount(): Observable<APIResponse<Balance>> {
		return this.http.put<APIResponse<Balance>>(DEMO_RELOAD, {});
	}

	/** DEMO RELOAD END */

	/** AFFILIATE START */


	public updateAffiliateClickCount(referralCode: string): Observable<APIResponse<number>> {
		return this.http.put<APIResponse<number>>(AFFILIATE_UPDATE_CLICK_COUNT(referralCode), {});
	}

	public getAffiliateBonusData() {
		return this.http.get<APIResponse<UserAffiliateReferralDTO>>(AFFILIATE_REFERRAL);
	}


	/** AFFILIATE END */

	/** DEPOSIT - UPI START */

	public getUPITransactions(): Observable<APIResponse<Page<UPITransaction>>> {
		return this.http.get<APIResponse<Page<UPITransaction>>>(DEPOSIT_UPI);
	}

	public requestUPIDeposit(requestBody: FormData): Observable<APIResponse<string>> {
		return this.http.post<APIResponse<string>>(DEPOSIT_UPI, requestBody);
	}

	/** DEPOSIT - UPI END */

	/** Trade Share START */

	public getSpotTradeScreenshot(tradeId: number) {
		return this.http.get(SCREENSHOT_CAPTURE(tradeId), {
			responseType: 'blob'
		});
	}

	/** Trade Share END */

	/** UPI Withdraw START */

	public getUPIWithdrawals(): Observable<APIResponse<Page<UPIWithdrawal>>> {
		return this.http.get<APIResponse<Page<UPIWithdrawal>>>(WITHDRAW_UPI);
	}

	public upiWithdrawRequest(withdrawRequest: UPIWithdrawRequest) {
		return this.http.post<APIResponse<string>>(UPI_WITHDRAWAL_REQUEST, withdrawRequest);
	}

	public getUPIWithdrawalCharges(amount: number): Observable<APIResponse<number>> {
		return this.http.get<APIResponse<number>>(UPI_WITHDRAWAL_CHARGES(amount));
	}

	/** UPI Withdraw END */

	/** User Deposit Bonus START */

	public getUserDepositBonuses(): Observable<APIResponse<UserDepositBonus[]>> {
		return this.http.get<APIResponse<UserDepositBonus[]>>(USER_DEPOSIT_BONUS);
	}

	/** User Deposit Bonus END */

	/** Percentage Turnover START */

	public getTurnoverBonusStatus(): Observable<APIResponse<PromoStatusDTO[]>> {
		return this.http.get<APIResponse<PromoStatusDTO[]>>(GET_TURNOVER_BONUS);
	}

	public applyTurnoverBonus(code: string): Observable<APIResponse<TurnoverBonus>> {
		return this.http.post<APIResponse<TurnoverBonus>>(APPLY_TURNOVER_BONUS(code), {});
	}

	/** Percentage Turnover END */

	/** Radom Payment START */

	public initRadomPayment(network: string, amount: number, asset: string, voucherCode: string): Observable<APIResponse<RadomSessionResponse>> {
		return this.http.post<APIResponse<RadomSessionResponse>>(RADOM_CREATE_SESSION, {
			network,
			total: amount,
			asset: asset,
			voucherCode
		});
	}

	/** Radom Payment END */

	/** Delete Account START */

	public deleteAccount(): Observable<APIResponse<boolean>> {
		return this.http.delete<APIResponse<boolean>>(DELETE_ACCOUNT);
	}

	/** Delete Account END */

	/** SSE for Trade Updates START */

	public getTradeUpdates(token: string) {
		return new Observable<MessageEvent>(observer => {
			const eventSource = new EventSourcePolyfill(TRADE_UPDATES(token));

			eventSource.addEventListener(SpotTradeEventType.ResolvedTrade, function (event) {
				observer.next(event as MessageEvent);
			});

			eventSource.addEventListener(SpotTradeEventType.RefundedTrade, function (event) {
				observer.next(event as MessageEvent);
			});

			// Handle any errors
			eventSource.onerror = error => {
				observer.error(error);
				eventSource.close();
			};

			// Cleanup event source when unsubscribed
			return () => {
				eventSource.close();
			};
		});


		/* return this.http.get(TRADE_UPDATES, {
			responseType: 'text',  // We expect text stream data
			observe: 'events',       // Observe the body (text stream)
			reportProgress: true,   // Used to get continuous stream updates
			headers: {
				'Accept': 'text/event-stream'
			}
		}); */
	}

	/** SSE for Trade Updates END */

}
