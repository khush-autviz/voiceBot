import { Injectable } from '@angular/core';
import { BehaviorSubject, filter, map, Observable, retry } from 'rxjs';
import { webSocket, WebSocketSubject } from 'rxjs/webSocket';
import { environment } from 'src/environment/environment';
import { WebSocketResponse } from 'src/types/app.types';

@Injectable({
	providedIn: 'root',
})
export class WebsocketService {

	private binanceSocket$: WebSocketSubject<any>;
	private solusSocket$: WebSocketSubject<any>;
	private appSocket$: WebSocketSubject<any>;

	private binanceConnected$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
	private solusConnected$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
	private appConnected$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

	constructor() {
		this.binanceSocket$ = webSocket({
			url: environment.binanceWebSocket,
			openObserver: {
				next: () => {
					this.binanceConnected$.next(true);
				}
			},
			closeObserver: {
				next: () => {
					this.binanceConnected$.next(false);
				}
			},
		});
		this.solusSocket$ = webSocket({
			url: environment.pricingEngineWebSocket,
			openObserver: {
				next: () => {
					this.solusConnected$.next(true);
				}
			},
			closeObserver: {
				next: () => {
					this.solusConnected$.next(false);
				}
			},
		});
		this.appSocket$ = webSocket({
			url: environment.appWebSocket,
			openObserver: {
				next: () => {
					this.appConnected$.next(true);
				}
			},
			closeObserver: {
				next: () => {
					this.appConnected$.next(false);
				}
			},
		});
	}

	connectToCombinedStream(streamNames: string[], isSolus: boolean = false) {
		if (isSolus) {
			this.solusSocket$.next({
				method: 'SUBSCRIBE',
				params: streamNames.map((name) => `${name.toUpperCase()}@kline_1s`),
				id: Math.floor(Math.random() * 1000),
			});
		} else {
			this.binanceSocket$.next({
				method: 'SUBSCRIBE',
				params: streamNames.map((name) => `${name}@miniTicker`),
				id: Math.floor(Math.random() * 1000),
			});
		}
	}

	disconnectToCombinedStream(streamNames: string[], isSolus: boolean = false) {
		if (isSolus) {
			this.solusSocket$.next({
				method: 'UNSUBSCRIBE',
				params: streamNames.map((name) => `${name.toUpperCase()}@kline_1s`),
				id: Math.floor(Math.random() * 1000),
			});
		} else {
			this.binanceSocket$.next({
				method: 'UNSUBSCRIBE',
				params: streamNames.map((name) => `${name}@miniTicker`),
				id: Math.floor(Math.random() * 1000),
			});
		}
	}

	connectToAppStream() {
		this.appSocket$.next('SUBSCRIBE');
	}

	disconnectToAppStream() {
		this.appSocket$.next('UNSUBSCRIBE');
	}

	getWebSocketStream(isSolus: boolean = false) {
		if (isSolus) {
			return this.solusSocket$;
		}

		return this.binanceSocket$;
	}

	getAppWebSocketStream() {
		return this.appSocket$;
	}

	getConnectionStatus(isSolus: boolean = false) {
		if (isSolus) {
			return this.solusConnected$;
		}

		return this.binanceConnected$;
	}

	getAppConnectionStatus() {
		return this.appConnected$;
	}

	closeWebSocket(isSolus: boolean = false) {
		if (isSolus) {
			this.solusSocket$.complete();
		}
		this.binanceSocket$.complete();
	}

	closeAppWebSocket() {
		this.appSocket$.complete();
	}

	// Send a message to the server
	sendAppMessage(message: any): void {
		this.appSocket$.next(message);
	}

	// Observable for all incoming messages
	onAppMessage(): Observable<WebSocketResponse<any>> {
		return this.appSocket$.asObservable();
	}

	// Filter messages by type
	onAppMessageByType<T>(type: string): Observable<WebSocketResponse<T>> {
		return this.appSocket$.pipe(
			filter((response: WebSocketResponse<any>) => response.type === type),
			map((response: WebSocketResponse<T>) => response),
			retry({ delay: 2000 })
		);
	}
}
