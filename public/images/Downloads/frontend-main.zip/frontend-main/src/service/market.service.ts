import { BreakpointObserver } from '@angular/cdk/layout';
import { Injectable, OnDestroy } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NavigationEnd, Router } from '@angular/router';
import * as moment from 'moment';
import { ToastrService } from 'ngx-toastr';
import { BehaviorSubject, Subscription, retry, timer } from 'rxjs';
import { IChartingLibraryWidget, IOrderLineAdapter } from 'src/assets/js/charting_library/charting_library';
import { ASSET_HISTORY_DEMO, ASSET_HISTORY_MAX_LENGTH, ASSET_HISTORY_USDT, LAST_TRADE_ASSET, SOLUS_OTC_PREFIX } from 'src/constants/constants';
import { MARKETS } from 'src/constants/ui.routes';
import { CoinDecimalPipe } from 'src/pipes/coin-decimal.pipe';
import { BinanceMiniTicker, BinanceStreamMessage, ResponseEntity, SolusCurrency, SolusStreamMessage, SpotTrade, SpotTradeAsset, SpotTradeEventType, SpotTradeRequest, SpotTradeStatus, SpotTradeVariation, State, SupportedCoin, TradePosition, WebSocketResponse, WebSocketResponseType } from 'src/types/app.types';
import { APIService } from './api.service';
import { StateService } from './state.service';
import { TvChartService } from './tv-chart.service';
import { WebsocketService } from './web-socket.service';

@Injectable({
	providedIn: 'root'
})
export class MarketService implements OnDestroy {
	state: State;

	assets: SpotTradeAsset[] = [];
	assets$ = new BehaviorSubject<SpotTradeAsset[]>([]);

	assetHistory: SpotTradeAsset[] = [];
	assetHistory$ = new BehaviorSubject<SpotTradeAsset[]>([]);

	spotTradeVariations: SpotTradeVariation[] = [];
	spotTradeVariations$ = new BehaviorSubject<SpotTradeVariation[]>(this.spotTradeVariations);

	selectedAsset!: SpotTradeAsset;
	selectedAsset$ = new BehaviorSubject<SpotTradeAsset | undefined>(undefined);

	openTrades: SpotTrade[] = [];
	openTrades$ = new BehaviorSubject<SpotTrade[]>([]);

	closeTrades: SpotTrade[] = [];
	closeTrades$ = new BehaviorSubject<SpotTrade[]>([]);

	openPositionsLoading$ = new BehaviorSubject<boolean>(false);
	resolvedPositionsLoading$ = new BehaviorSubject<boolean>(false);

	loading: boolean = false;
	loading$ = new BehaviorSubject<boolean>(false);

	isBinanceSocketConnected: boolean = false;
	isBinanceSocketConnected$ = new BehaviorSubject<boolean>(false);

	isSolusSocketConnected: boolean = false;
	isSolusSocketConnected$ = new BehaviorSubject<boolean>(false);

	subscriptions: Subscription[] = [];
	priceStreamSub: Subscription | undefined;
	appSocketSubscription: Subscription | undefined;

	refreshing: boolean = false;

	_tvWidget: IChartingLibraryWidget | undefined;
	positionAdapters: IOrderLineAdapter[] = [];
	tradesPositionAdapters: {
		tradeId: number,
		positionAdapter: IOrderLineAdapter
	}[] = [];
	resolvedTrades = new Set<SpotTrade>();

	isMobileDevice: boolean = false;

	initSubscriptions: Subscription[] = [];
	initialized: boolean = false;
	openTradesFetched: boolean = false;

	miniTicker: BinanceMiniTicker | SolusStreamMessage['k'] | undefined;

	appWsSpotTradeVariations: SpotTradeVariation[] = [];
	appWsSpotTradeVariations$ = new BehaviorSubject<SpotTradeVariation[]>([]);

	constructor(private api: APIService, private stateService: StateService, private webSocketService: WebsocketService, private tvChartService: TvChartService, private decimalPipe: CoinDecimalPipe, private toastr: ToastrService, private breakpointObserver: BreakpointObserver, private router: Router, private snackbar: MatSnackBar) {
		this.state = this.stateService.getState();

		const sub = this.stateService.state$.subscribe({
			next: (state: State) => {
				this.state = state;

				if (this.state.jwt != null) {
					if (!this.initialized) {
						this.initialize();
						// spot trade variations socket
						this.fetchSpotTradeVariations();
						this.initialized = true;
					} else {
						this.setWsSpotTradeVariation(this.appWsSpotTradeVariations);
					}


					// fetch asset history
					let assetHistory = localStorage.getItem(ASSET_HISTORY_USDT);
					if (this.state.coin === SupportedCoin.DEMO_USDT) {
						assetHistory = localStorage.getItem(ASSET_HISTORY_DEMO);
					}

					if (assetHistory) {
						this.assetHistory = JSON.parse(assetHistory);
						this.assetHistory$.next(this.assetHistory);
					}

				} else {
					this.initSubscriptions.forEach(s => s.unsubscribe());
					this.initialized = false;
					this.setOpenTrades([]);
					this.setCloseTrades([]);
					this.tradesPositionAdapters = [];
					this.resolvedTrades.clear();
					this.openTradesFetched = false;
				}
			},
		});
		this.subscriptions.push(sub);

		const breakpointObserverSub = this.breakpointObserver.observe('only screen and (orientation: landscape) and (max-height: 575.98px), only screen and (orientation: portrait) and (max-width: 576px)').subscribe({
			next: (breakpointState) => {
				this.isMobileDevice = breakpointState.matches;
			}
		});
		this.subscriptions.push(breakpointObserverSub);

		const routerSubscription = this.router.events.subscribe(event => {
			if (event instanceof NavigationEnd) {
				if (!event.url.includes(MARKETS)) {
					this.tradesPositionAdapters.forEach(t => {
						t.positionAdapter.remove();
					});

					this.tradesPositionAdapters = [];
				}
			}
		});
		this.subscriptions.push(routerSubscription);
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach(sub => sub.unsubscribe());
		this.initSubscriptions.forEach(sub => sub.unsubscribe());
	}

	setLoading(value: boolean) {
		this.loading = value;
		this.loading$.next(this.loading);
	}

	setAssets(value: SpotTradeAsset[]) {
		this.assets = value;
		this.refreshAssetHistory();
		this.assets$.next(this.assets);
	}

	setSpotTradeVariation(value: SpotTradeVariation[]) {
		this.spotTradeVariations = value;
		this.spotTradeVariations$.next(this.spotTradeVariations);

		this.api.getListedAssets().subscribe({
			next: (res) => {
				if (res && res.success) {
					const spotTradeAssets: SpotTradeAsset[] = [];
					const assets = res.body.filter(a => this.spotTradeVariations.some(stv => stv.assetId === a.id));

					assets.forEach(asset => {
						const variations = this.spotTradeVariations.filter(variation => variation.assetId === asset.id).sort((a, b) => a.duration - b.duration);
						const spotTradeAsset: SpotTradeAsset = { ...asset, variations: variations, selectedVariation: variations[0] };
						spotTradeAssets.push(spotTradeAsset);
					});
					this.setAssets(spotTradeAssets);

					if (this.assets.length > 0) {
						const lastTradeAssetId = localStorage.getItem(LAST_TRADE_ASSET);
						if (lastTradeAssetId) {
							const assetIdx = this.assets.findIndex(asset => asset.id === Number(lastTradeAssetId));
							if (assetIdx !== -1) {
								this.changeSelectedAsset(this.assets[assetIdx]);
							} else {
								this.changeSelectedAsset(this.assets[0]);
							}
						} else {
							this.changeSelectedAsset(this.assets[0]);
						}

						if (!this.openTradesFetched) {
							this.getOpenPositions();
							this.openTradesFetched = true;
						}
					}
				} else {
					this.setAssets([]);
				}
			}
		});
	}

	setSelectedAsset(value: SpotTradeAsset) {
		this.selectedAsset = value;
		this.selectedAsset$.next(this.selectedAsset);
	}

	setOpenTrades(value: SpotTrade[]) {
		this.openTrades = value;
		this.openTrades$.next(this.openTrades);
	}

	setCloseTrades(value: SpotTrade[]) {
		this.closeTrades = value;
		this.closeTrades$.next(this.closeTrades);
	}

	initialize() {
		this.setupSubscriptions();
		this.setupTradeResolution();
	}

	setupSubscriptions() {
		const tvSub = this.tvChartService.tvWidget$.subscribe({
			next: (tvWidget) => {
				if (tvWidget) {
					this._tvWidget = tvWidget;
				}
			}
		});
		this.initSubscriptions.push(tvSub);

		const binanceSocketSub = this.webSocketService.getConnectionStatus().subscribe({
			next: (connected: boolean) => {
				this.isBinanceSocketConnected = connected;
				if (connected) {
					if (this.selectedAsset) {
						this.subscribeToPriceStream(this.selectedAsset, this.selectedAsset);
					}
				}
				this.isBinanceSocketConnected$.next(this.isBinanceSocketConnected);
			}
		});
		this.initSubscriptions.push(binanceSocketSub);

		const solusSocketSub = this.webSocketService.getConnectionStatus(true).subscribe({
			next: (connected: boolean) => {
				this.isSolusSocketConnected = connected;
				if (connected) {
					if (this.selectedAsset) {
						this.subscribeToPriceStream(this.selectedAsset, this.selectedAsset);
					}
				}
				this.isSolusSocketConnected$.next(this.isSolusSocketConnected);
			}
		});
		this.initSubscriptions.push(solusSocketSub);

		const selectedAssetSub = this.selectedAsset$.subscribe((asset) => {
			this.priceStreamSub = this.webSocketService.getWebSocketStream(asset?.tradingViewSymbol.includes(SOLUS_OTC_PREFIX))?.pipe(retry({ delay: 3000 })).subscribe({
				next: (data: BinanceStreamMessage | SolusStreamMessage) => {

					if (!asset?.tradingViewSymbol.includes(SOLUS_OTC_PREFIX)) {
						const ticker = data as BinanceStreamMessage;
						if (ticker.data) {
							this.miniTicker = ticker.data;
						}
					} else {
						const ticker = data as SolusStreamMessage;
						if (ticker.k) {
							this.miniTicker = ticker.k;
						}
					}
				}
			});

		});
		this.initSubscriptions.push(selectedAssetSub);

		// this.onAppWebSocketConnected();

		const sub = this.webSocketService.onAppMessage().pipe(retry({ delay: 3000 })).subscribe({
			next: (message) => {
				if (message.type === WebSocketResponseType.CONNECTED) {
					this.webSocketService.connectToAppStream();
				}
			},
			error: (err) => {
				console.error('WebSocket error:', err);
			},
			complete: () => {
				console.error('App WebSocket completed');
			},
		});
		this.initSubscriptions.push(sub);

		const sub4 = this.appWsSpotTradeVariations$.subscribe({
			next: (res) => {
				if (res && res.length > 0) {
					if (!this.assets || this.assets.length <= 0) {
						this.filterSpotTradeVariationsByCurrency();
					}
				}
			}
		});
		this.initSubscriptions.push(sub4);

		const sub5 = this.api.getTradeUpdates(this.state.jwt || '').pipe(retry({ delay: 1000 })).subscribe({
			next: (res) => {
				if (res.type === SpotTradeEventType.ResolvedTrade) {
					const closedTrade = JSON.parse(res.data) as SpotTrade;

					this.showResolvedTradeMarkers(closedTrade);
					this.stateService.refreshBalance();
				} else if (res.type === SpotTradeEventType.RefundedTrade) {
					this.getOpenPositions();
					this.stateService.refreshBalance();
					this.toastr.info(`There was some error while resolving your trade. So we refunded your trade amount.`, 'Trade Refunded');
				}
			},
			error: (err) => {
				console.error(err);
			}
		});
		this.initSubscriptions.push(sub5);

		this.onSpotTradePlaced();
	}

	setupTradeResolution() {
		const timerSub = timer(0, 1000).subscribe(() => {
			this.openTrades.forEach(trade => {
				if (trade) {
					const date: moment.Moment = moment(trade.expiresAt).subtract(1, 'second');
					const diff = date.diff(moment(), 'seconds');

					const tradeAlreadyResolved = this.resolvedTrades.has(trade);
					if (diff <= 0 && !tradeAlreadyResolved) {
						this.resolvedTrades.add(trade);

						const index = this.tradesPositionAdapters.findIndex(t => t.tradeId === trade.id);

						if (index !== -1) {
							this.tradesPositionAdapters[index].positionAdapter.remove();

							this.tradesPositionAdapters.splice(index, 1);
						}
					}
				}
			});
			this.initSubscriptions.push(timerSub);

			this.openTrades = this.openTrades.map(this.tradeCalculationCallback());
			this.addOrUpdateTradeMarkers();

			if (this.openTrades.length <= 0) {
				this.tradesPositionAdapters.forEach(p => p.positionAdapter.remove());
				this.tradesPositionAdapters = [];
			} else {
				const otherOpenTrades = this.tradesPositionAdapters.filter(p => !this.openTrades.some(trade => trade.id === p.tradeId));

				otherOpenTrades.forEach(p => {
					p.positionAdapter.remove();

					const index = this.tradesPositionAdapters.findIndex(tpa => tpa.tradeId === p.tradeId);

					if (index !== -1) {
						this.tradesPositionAdapters.splice(index, 1);
					}
				});
			}

			this.setOpenTrades(this.openTrades);
		});
		this.initSubscriptions.push(timerSub);
	}

	addOrUpdateTradeMarkers() {
		if (this._tvWidget !== null && this._tvWidget !== undefined) {
			this.openTrades.forEach((trade, index) => {
				const isResolved = this.resolvedTrades.has(trade);
				if (isResolved) {
					const tradePresent = this.tradesPositionAdapters.find(t => t.tradeId === trade.id);
					if (tradePresent) {
						tradePresent.positionAdapter.remove();
					}
				} else {
					const tradePresent = this.tradesPositionAdapters.find(t => t.tradeId === trade.id);
					if (tradePresent) {
						tradePresent.positionAdapter
							.setText(this.getTradeMarkerText(trade))
							.setBodyBorderColor(this.getMarkerColor(trade.expectedPnL))
							.setLineColor(this.getMarkerColor(trade.expectedPnL))
							.setBodyTextColor(this.getMarkerColor(trade.expectedPnL))
							.setQuantityBackgroundColor(this.getMarkerColor(trade.expectedPnL))
							.setQuantityBorderColor(this.getMarkerColor(trade.expectedPnL));
					} else {
						try {
							const positionAdapter = this._tvWidget?.activeChart?.()?.createOrderLine()
								.setText(this.getTradeMarkerText(trade))
								.setQuantity(`$${this.decimalPipe.transform(trade.investedAmount)}`)
								.setPrice(trade.entryPrice)
								.setExtendLeft(false)
								.setLineLength(100 + (180 * (this.openTrades.length - 1 - index)), 'pixel')
								.setBodyBorderColor(this.getMarkerColor(trade.expectedPnL))
								.setLineColor(this.getMarkerColor(trade.expectedPnL))
								.setBodyTextColor(this.getMarkerColor(trade.expectedPnL))
								.setQuantityBackgroundColor(this.getMarkerColor(trade.expectedPnL))
								.setQuantityBorderColor(this.getMarkerColor(trade.expectedPnL))
								.onMove(() => { });
							console.log('Trade Marker Added');

							if (positionAdapter) {
								this.tradesPositionAdapters.push({
									tradeId: trade.id,
									positionAdapter: positionAdapter
								});
							}
						} catch (error) {
							console.log(error);
						}
					}
				}
			});
		}
	}

	changeSelectedAsset(asset: SpotTradeAsset) {

		if (this.selectedAsset != asset) {
			this.subscribeToPriceStream(this.selectedAsset, asset);

			this.setSelectedAsset(asset);
			localStorage.setItem(LAST_TRADE_ASSET, this.selectedAsset.id.toString());

			this.getSpotTradePositions();

			this.setAssetHistory(asset);
		}
	}

	subscribeToPriceStream(selectedAsset: SpotTradeAsset, newAsset: SpotTradeAsset) {
		if (selectedAsset) {
			this.webSocketService.disconnectToCombinedStream([selectedAsset.binanceSymbol.toLowerCase()], selectedAsset.tradingViewSymbol.includes(SOLUS_OTC_PREFIX));
		}
		this.webSocketService.connectToCombinedStream([newAsset.binanceSymbol.toLowerCase()], newAsset.tradingViewSymbol.includes(SOLUS_OTC_PREFIX));
	}

	getSpotTradePositions(showTradeStatus: boolean = false) {
		this.openPositionsLoading$.next(true);
		this.resolvedPositionsLoading$.next(true);
		const currencyId = this.state.currencies.find(c => c.symbol === SupportedCoin[this.state.coin])?.id || -1;

		// fetch open trades
		this.api.getSpotTrades({ assetId: this.selectedAsset.id, currencyId: currencyId }).subscribe({
			next: async (response) => {
				if (response.success) {
					const openTrades = response.body.content.filter(t => t.tradeStatus === SpotTradeStatus.Open && moment(t.expiresAt).isAfter()).map(t => {
						const trade = { ...t, isConfirmDelete: false, isCancelling: false };

						if (this.openTrades.length > 0) {
							const previousTrade = this.openTrades.find(ot => ot.id === t.id);

							if (previousTrade) {
								trade.isConfirmDelete = previousTrade?.isConfirmDelete || false;
							}
						}
						return trade;
					});
					openTrades.sort((a, b) => moment(b.expiresAt).unix() - moment(a.expiresAt).unix());
					this.setOpenTrades(openTrades);

					const closeTrades = response.body.content.filter(t => t.tradeStatus !== SpotTradeStatus.Open);
					closeTrades.sort((a, b) => moment(b.expiresAt).unix() - moment(a.expiresAt).unix());
					this.setCloseTrades(closeTrades);

					if (showTradeStatus) {
						this.handleResolvedTrades(closeTrades);
					}
				}

				this.openPositionsLoading$.next(false);
				this.resolvedPositionsLoading$.next(false);
			},
			error: () => {
				this.openPositionsLoading$.next(false);
				this.resolvedPositionsLoading$.next(false);
			}
		});
	}

	getOpenPositions() {
		this.openPositionsLoading$.next(true);
		const currencyId = this.state.currencies.find(c => c.symbol === SupportedCoin[this.state.coin])?.id || -1;

		// fetch open trades
		this.api.getSpotTrades({ assetId: this.selectedAsset.id, currencyId: currencyId, tradeStatus: SpotTradeStatus.Open }).subscribe({
			next: async (response) => {
				if (response.success) {
					const openTrades = response.body.content.filter(t => moment(t.expiresAt).isAfter()).map(t => {
						const trade = { ...t, isConfirmDelete: false, isCancelling: false };

						if (this.openTrades.length > 0) {
							const previousTrade = this.openTrades.find(ot => ot.id === t.id);

							if (previousTrade) {
								trade.isConfirmDelete = previousTrade?.isConfirmDelete || false;
							}
						}
						return trade;
					});

					openTrades.sort((a, b) => moment(b.expiresAt).unix() - moment(a.expiresAt).unix());

					this.setOpenTrades(openTrades);

					this.openTrades = this.openTrades.map(this.tradeCalculationCallback());
					this.addOrUpdateTradeMarkers();
				}

				this.openPositionsLoading$.next(false);
			},
			error: () => {
				this.openPositionsLoading$.next(false);
			}
		});
	}

	getResolvedPositions(showTradeStatus: boolean = false, page: number = 0, size: number = 50, infiniteScroll: boolean = false) {
		this.resolvedPositionsLoading$.next(true);

		const currencyId = this.state.currencies.find(c => c.symbol === SupportedCoin[this.state.coin])?.id || -1;

		this.api.getSpotTrades({ assetId: this.selectedAsset.id, currencyId: currencyId, tradeStatus: SpotTradeStatus.Closed, page, size }).subscribe({
			next: async (response) => {
				if (response.success) {
					if (infiniteScroll) {
						this.setCloseTrades([...this.closeTrades, ...response.body.content]);
					} else {
						const closeTrades = response.body.content;
						closeTrades.sort((a, b) => moment(b.expiresAt).unix() - moment(a.expiresAt).unix());
						this.setCloseTrades(closeTrades);

						if (showTradeStatus) {
							this.handleResolvedTrades(closeTrades);
						}
					}
				}
				this.resolvedPositionsLoading$.next(false);
			},
			error: () => {
				this.resolvedPositionsLoading$.next(false);
			}
		});
	}

	handleResolvedTrades(closeTrades: SpotTrade[]) {
		const resolutionCompletedTrades: SpotTrade[] = [];

		this.resolvedTrades.forEach(trade => {
			const closedTrade = closeTrades.find(t => t.id === trade.id);

			if (closedTrade) {
				this.showResolvedTradeMarkers(closedTrade);
				resolutionCompletedTrades.push(trade)
			}
		});
		resolutionCompletedTrades.forEach((trade) => {
			this.resolvedTrades.delete(trade);
		});
	}

	playAudio() {
		const audio = new Audio();
		audio.src = "assets/sounds/trade-notification.mp3";
		audio.load();
		audio.play();
	}

	showResolvedTradeMarkers(closedTrade: SpotTrade) {
		this.getOpenPositions();
		this.playAudio();
		if (closedTrade.tradeStatus === SpotTradeStatus.Profit) {
			if (!this.isMobileDevice) {
				this.toastr.success(`$${this.decimalPipe.transform(closedTrade.returnedAmount)}`, 'Result (P/L)');
			}

			try {
				if (this._tvWidget !== null && this._tvWidget !== undefined) {
					if (this.selectedAsset.id === closedTrade.assetId) {
						const entityId = this._tvWidget?.activeChart?.()?.createMultipointShape([
							{
								time: moment.utc(closedTrade.exitedAt).unix(),
								price: closedTrade.exitPrice
							}
						], {
							shape: 'comment',
							text: `Result (P/L): $${this.decimalPipe.transform(closedTrade.returnedAmount)}`,
							overrides: {
								'backgroundColor': this.getMarkerColor(1),
								'borderColor': this.getMarkerColor(1)
							}
						});

						if (entityId) {
							setTimeout(() => {
								this._tvWidget?.activeChart?.()?.removeEntity(entityId);
							}, 3000);
						}
					}
				}
			} catch (err) {
				console.error(err);
			}
		} else if (closedTrade.tradeStatus === SpotTradeStatus.Loss) {
			if (!this.isMobileDevice) {
				this.toastr.error(`$${this.decimalPipe.transform(closedTrade.returnedAmount)}`, 'Result (P/L)');
			}
			try {
				if (this._tvWidget !== null && this._tvWidget !== undefined) {
					if (this.selectedAsset.id === closedTrade.assetId) {
						const entityId = this._tvWidget?.activeChart?.()?.createMultipointShape([{
							time: moment.utc(closedTrade.exitedAt).unix(),
							price: closedTrade.exitPrice,
						}], {
							shape: 'comment',
							text: `Result (P/L): $${this.decimalPipe.transform(closedTrade.returnedAmount)}`,
							overrides: {
								'backgroundColor': this.getMarkerColor(0),
								'borderColor': this.getMarkerColor(0)
							}
						});

						if (entityId) {
							setTimeout(() => {
								this._tvWidget?.activeChart?.()?.removeEntity(entityId);
							}, 3000);
						}
					}
				}
			} catch (err) {
				console.error(err);
			}
		}
	}

	getTimeDifference(trade: SpotTrade) {
		const exitingAt = moment(trade.expiresAt);
		const currentTime = moment();

		// Remaining time is totalDuration - elapsed time
		const remainingSec = Math.max(exitingAt.diff(currentTime, 'seconds'), 0);

		const formatTime = (time: number): string => (time < 10 ? `0${time}` : `${time}`);

		// Calculate remaining hours, minutes, and seconds
		const hours = formatTime(Math.floor(remainingSec / 3600));
		const minutes = formatTime(Math.floor((remainingSec % 3600) / 60));
		const seconds = formatTime(remainingSec % 60);

		return { hours, minutes, seconds };
	}

	getTradeMarkerText(trade: SpotTrade) {
		const { hours, minutes, seconds } = this.getTimeDifference(trade);

		return `${trade.tradePosition === TradePosition.Long ? 'HIGHER' : 'LOWER'} | $${trade.entryPrice} | ${hours}:${minutes}:${seconds}`
	}

	getMarkerColor(value: number | undefined) {
		if (value == undefined) return '#2962ff';

		return value > 0 ? '#049981' : '#f23645';
	}

	cancelTrade(tradeId: number) {
		const index = this.tradesPositionAdapters.findIndex(t => t.tradeId === tradeId);

		if (index !== -1) {
			this.tradesPositionAdapters[index].positionAdapter.remove();

			this.tradesPositionAdapters.splice(index, 1);

			const openTradeIndex = this.openTrades.findIndex(t => t.id === tradeId);
			this.openTrades.splice(openTradeIndex, 1);
			this.setOpenTrades(this.openTrades);

			this.getResolvedPositions();
			this.stateService.refreshBalance();
		}
	}

	tradeCalculationCallback() {
		return (trade: SpotTrade) => {
			const winMultiplier = trade.winMultiplier || 0;
			const loseInsurance = this.selectedAsset?.variations.find(v => v.id === trade.variationId)?.loseInsurance || 0;


			const invested = trade.investedAmount;
			const expectedProfit = invested * winMultiplier;
			const expectedLoss = (invested * loseInsurance) - invested;

			let isProfit = false;
			if (trade.tradePosition === TradePosition.Long) {
				isProfit = (this.miniTicker?.c || trade.entryPrice) > trade.entryPrice;
			} else {
				isProfit = (this.miniTicker?.c || trade.entryPrice) <= trade.entryPrice;
			}

			trade.expectedPnL = isProfit ? expectedProfit : expectedLoss;
			trade.pnlAfterSale = this.getPnlAfterSale(trade);

			return trade;
		}
	}

	getPnlAfterSale(trade: SpotTrade) {
		const invested = trade.investedAmount;

		const exitChargeMultiplier = this.getExitCharges(moment(), moment(trade.enteredAt), trade);
		const exitCharge = invested * exitChargeMultiplier;
		let refundAmount = invested - exitCharge;

		const exitPremiumMultiplier = this.selectedAsset?.variations.find(v => v.id === trade.variationId)?.exitPremiumCharges || 0;
		const exitPremium = invested * exitPremiumMultiplier;
		refundAmount -= exitPremium;

		if (refundAmount > 0) {
			return refundAmount - invested;
		}
		return 0;
	}

	getExitCharges(exitingAt: moment.Moment, enteredAt: moment.Moment, trade: SpotTrade) {
		if (this.selectedAsset) {
			const totalSeconds = Math.abs(enteredAt.diff(moment(trade.expiresAt), 'seconds'));
			const twoThirdInterval = (2 * totalSeconds) / 3;

			const maxExitCharges = this.selectedAsset?.variations.find(v => v.id === trade.variationId)?.maxExitCharges || 0;
			const minExitCharges = this.selectedAsset?.variations.find(v => v.id === trade.variationId)?.minExitCharges || 0;
			const exitChargePerSecond = (maxExitCharges - minExitCharges) / twoThirdInterval;
			const passedSeconds = Math.abs(enteredAt.diff(exitingAt, 'seconds'));
			const exitCharges = minExitCharges + (exitChargePerSecond * passedSeconds);

			return exitCharges > 1 ? 1 : exitCharges;
		}

		return 0;
	}

	setAssetHistory(asset: SpotTradeAsset) {
		const assetHistoryIndex = this.assetHistory.findIndex(a => a.id === asset.id);

		if (assetHistoryIndex === -1) {
			if (this.assetHistory.length >= ASSET_HISTORY_MAX_LENGTH) {
				this.assetHistory.shift();
			}

			this.assetHistory.push(asset);
		}

		if (this.state.coin === SupportedCoin.USDT) {
			localStorage.setItem(ASSET_HISTORY_USDT, JSON.stringify(this.assetHistory));
		} else if (this.state.coin === SupportedCoin.DEMO_USDT) {
			localStorage.setItem(ASSET_HISTORY_DEMO, JSON.stringify(this.assetHistory));
		}

		this.assetHistory$.next(this.assetHistory);
	}

	removeAssetHistory(assetId: number) {
		const assetHistoryIndex = this.assetHistory.findIndex(a => a.id === assetId);

		if (assetHistoryIndex !== -1) {
			this.assetHistory.splice(assetHistoryIndex, 1);
		}


		if (this.state.coin === SupportedCoin.USDT) {
			localStorage.setItem(ASSET_HISTORY_USDT, JSON.stringify(this.assetHistory));
		} else if (this.state.coin === SupportedCoin.DEMO_USDT) {
			localStorage.setItem(ASSET_HISTORY_DEMO, JSON.stringify(this.assetHistory));
		}
		this.assetHistory$.next(this.assetHistory);
	}

	refreshAssetHistory() {
		const newAssetHistory: SpotTradeAsset[] = [];

		if (this.state.coin === SupportedCoin.USDT) {
			this.assetHistory = JSON.parse(localStorage.getItem(ASSET_HISTORY_USDT) || '[]');
		} else if (this.state.coin === SupportedCoin.DEMO_USDT) {
			this.assetHistory = JSON.parse(localStorage.getItem(ASSET_HISTORY_DEMO) || '[]');
		}

		this.assetHistory.forEach(assetHistory => {
			const assetPresent = this.assets.some(a => a.id === assetHistory.id);

			if (assetPresent) {
				newAssetHistory.push(assetHistory);
			}
		});

		this.assetHistory = newAssetHistory;

		if (this.state.coin === SupportedCoin.USDT) {
			localStorage.setItem(ASSET_HISTORY_USDT, JSON.stringify(this.assetHistory));
		} else if (this.state.coin === SupportedCoin.DEMO_USDT) {
			localStorage.setItem(ASSET_HISTORY_DEMO, JSON.stringify(this.assetHistory));
		}
		this.assetHistory$.next(this.assetHistory);
	}

	fetchSpotTradeVariations() {
		this.setLoading(true);
		this.appSocketSubscription = this.webSocketService.onAppMessageByType<string>(WebSocketResponseType.SPOT_TRADE_VARIATIONS).subscribe((response) => {
			const data = JSON.parse(response.data);

			if (data) {
				this.setWsSpotTradeVariation(data);
			}

			if (data.length <= 0) {
				setTimeout(() => {
					this.webSocketService.connectToAppStream();
				}, 100);
			}

			this.setLoading(false);
		});
		this.subscriptions.push(this.appSocketSubscription);

		if (this.assets && this.assets.length > 0) {
			this.setLoading(false);
		}
	}

	setWsSpotTradeVariation(data: SpotTradeVariation[]) {
		this.appWsSpotTradeVariations = data;
		this.appWsSpotTradeVariations$.next(this.appWsSpotTradeVariations);

		this.filterSpotTradeVariationsByCurrency();
	}

	filterSpotTradeVariationsByCurrency() {
		this.setLoading(false);
		if (this.appWsSpotTradeVariations && this.appWsSpotTradeVariations.length > 0) {
			const currency: SolusCurrency | undefined = this.state.currencies.find(currency => currency.symbol === SupportedCoin[this.state.coin]);

			if (currency) {
				const variations = this.appWsSpotTradeVariations.filter(v => v.currencyId === currency.id);

				this.setSpotTradeVariation(variations);
			}
		}
	}

	placeSpotTrade(spotTradeRequest: SpotTradeRequest) {
		this.webSocketService.sendAppMessage(spotTradeRequest);
		console.log('Trade Placed Message Sent');
	}

	onSpotTradePlaced() {
		const spotTradePlaceSub = this.webSocketService.onAppMessageByType<ResponseEntity<SpotTrade>>(WebSocketResponseType.SPOT_TRADE_PLACE).subscribe((response: WebSocketResponse<ResponseEntity<SpotTrade>>) => {
			const { success, body } = response.data.body;
			console.log('Trade Placed Response: ', success, body);

			if (success) {
				const openTrades = [...this.openTrades, { ...body, isConfirmDelete: false, isCancelling: false }];
				openTrades.sort((a, b) => moment(b.expiresAt).unix() - moment(a.expiresAt).unix());
				this.setOpenTrades(openTrades);
				this.openTrades = this.openTrades.map(this.tradeCalculationCallback());
				this.addOrUpdateTradeMarkers();

				this.playAudio();
				if (this.isMobileDevice) {
					this.snackbar.open('Trade Placed', undefined, {
						verticalPosition: 'top',
						panelClass: ['snackbar-success', 'snackbar-mobile'],
					});
				}

				this.getOpenPositions();
				this.stateService.refreshBalance();
			} else {
				if (typeof body === 'string') {
					this.showErrorSnackbar(body as unknown as string || "Whoops! Looks like your trade got cold feet and decided to stay put!");
				} else {
					console.error(body);
					this.showErrorSnackbar("Failed to place a trade");
				}
			}
		});
		this.initSubscriptions.push(spotTradePlaceSub);
	}

	showErrorSnackbar(message: string) {
		this.snackbar.open(message, undefined, {
			verticalPosition: this.isMobileDevice ? 'top' : 'bottom',
			panelClass: ['snackbar-error', this.isMobileDevice ? 'snackbar-mobile' : 'snackbar'],
		});
	}

	onAppWebSocketConnected() {
		const sub = this.webSocketService.onAppMessageByType<string>(WebSocketResponseType.CONNECTED).subscribe((response: WebSocketResponse<string>) => {
			if (response.data) {
				this.webSocketService.connectToAppStream();
			}
		});
		this.subscriptions.push(sub);
	}
}
