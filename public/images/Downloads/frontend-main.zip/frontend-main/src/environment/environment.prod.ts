import { Environment } from 'src/types/app.types';

const googleRedirectUri = `https://app.solus.finance/login/google`;

export const environment: Environment = {
	production: true,
	uat: false,
	dev: false,
	backend: 'https://api.solus.finance',
	frontend: 'https://app.solus.finance',
	recaptcha: '6Lf56Q4mAAAAADLPzycfj1fPHHksjORevGDz-E1P',
	discord: `https://discord.com/api/oauth2/authorize?client_id=1107545799312810004&redirect_uri=https%3A%2F%2Fapp.solus.finance%2Fdiscord-callback&response_type=code&scope=identify%20email%20guilds.join`,
	metamaskDeepLink: 'https://metamask.app.link/dapp/',
	google: `https://accounts.google.com/o/oauth2/auth?response_type=code&scope=openid%20https://www.googleapis.com/auth/userinfo.email%20https://www.googleapis.com/auth/userinfo.profile&client_id=457283619374-sblgi3bq5lbq46q4io7i9gokri9eggqu.apps.googleusercontent.com&redirect_uri=${googleRedirectUri}`,
	googleRedirectUri: googleRedirectUri,
	pricingEngineWebSocket: 'wss://stream.solus.finance/ws/',
	binanceWebSocket: 'wss://stream.binance.com/stream',
	appWebSocket: 'wss://api.solus.finance/app',
	underMaintenance: false,
	polygonScanApiKey: 'WSGBXW2GIY2GV2JPEJ9RWR7KFIW5UXWR5F',
};
