import { Environment } from 'src/types/app.types';

const googleRedirectUri = 'https://app-uat.solus.finance/login/google';

export const environment: Environment = {
	production: false,
	uat: true,
	dev: false,
	backend: 'https://api-uat.solus.finance',
	frontend: 'https://app-uat.solus.finance',
	recaptcha: '6LeiX1MpAAAAAAIi5hl4vmecBx9BN1F2_lB5GyU6',
	discord: 'https://discord.com/api/oauth2/authorize?client_id=1108110849488453833&redirect_uri=https%3A%2F%2Fapp.solus.finance%2Fdiscord-callback&response_type=code&scope=identify%20email%20guilds.join',
	metamaskDeepLink: 'https://metamask.app.link/dapp/',
	google: `https://accounts.google.com/o/oauth2/auth?response_type=code&scope=openid%20https://www.googleapis.com/auth/userinfo.email%20https://www.googleapis.com/auth/userinfo.profile&client_id=457283619374-sblgi3bq5lbq46q4io7i9gokri9eggqu.apps.googleusercontent.com&redirect_uri=${googleRedirectUri}`,
	googleRedirectUri: googleRedirectUri,
	pricingEngineWebSocket: 'wss://otc.solus.finance/ws/',
	binanceWebSocket: 'wss://stream.binance.com/stream',
	appWebSocket: 'wss://api-uat.solus.finance/app',
	underMaintenance: false,
	polygonScanApiKey: 'WSGBXW2GIY2GV2JPEJ9RWR7KFIW5UXWR5F',
};
