import { BreakpointObserver } from '@angular/cdk/layout';
import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatTabsModule } from '@angular/material/tabs';
import { MatToolbarModule } from '@angular/material/toolbar';
import { Event, NavigationEnd, NavigationStart, Router, RouterModule } from '@angular/router';
import { Subscription } from 'rxjs';
import {
	AFFILIATE_DASHBOARD,
	CASHOUT,
	CHANGE_PASSWORD,
	CREATE_ACCOUNT,
	CRYPTO,
	DEPOSIT,
	EDIT_PROFILE,
	FUTURES,
	KYC,
	LEADERBOARD,
	LINK_DISCORD,
	LOG_IN,
	MARKETS,
	OFFERS,
	ONBOARDING,
	PAYPAL_PAYMENT_CANCELLED,
	PAYPAL_PAYMENT_STATUS,
	PERMISSIONS,
	PORTFOLIO,
	PROFILE_DETAILS,
	RADOM_PAYMENT_FAILED,
	RADOM_PAYMENT_SUCCESS,
	REFERRAL,
	SUPPORT
} from 'src/constants/ui.routes';
import { ImageErrorDirective } from 'src/directives/image-error.directive';
import { StateService } from 'src/service/state.service';
import { Navigation, SolusMode, State, SupportedCoin } from 'src/types/app.types';
import { AccountSwitchComponent } from '../account-switch/account-switch.component';
import { NavAvatarComponent } from '../nav-avatar/nav-avatar.component';

const materialModules = [MatToolbarModule, MatButtonModule, MatIconModule, MatMenuModule, MatSidenavModule, MatDividerModule, MatTabsModule];
const components = [AccountSwitchComponent, NavAvatarComponent];

@Component({
	selector: 'app-navbar',
	standalone: true,
	imports: [CommonModule, ImageErrorDirective, RouterModule, ...materialModules, ...components],
	templateUrl: './navbar.component.html',
	styleUrls: ['./navbar.component.scss'],
	encapsulation: ViewEncapsulation.None
})
export class NavbarComponent implements OnInit, OnDestroy {
	logoDark = '../../assets/solus-logo-dark.svg';
	logo: string = this.logoDark;

	showNavBar = false;
	state: State;
	futuresMode: SolusMode = SolusMode.FUTURES;
	showDepositButton: boolean = true;

	activeLink: string = REFERRAL;

	navItemsDesktop: Omit<Navigation, 'icon'>[] = [
		{
			label: 'Markets',
			link: MARKETS
		},
		{
			label: 'Portfolio',
			link: PORTFOLIO,
		},
		{
			label: 'Offers',
			link: OFFERS,
		},
		{
			label: 'Referral',
			link: REFERRAL,
		},
		{
			label: 'Support',
			link: SUPPORT,
		},
	];

	seperateFuturesItems: string[] = [
		MARKETS
	];

	MARKETS = MARKETS;
	navigationEnded: boolean = false;
	isMobileDevice: boolean = false;

	subscriptions: Subscription[] = [];

	SupportedCoin = SupportedCoin;

	constructor(private router: Router, private stateService: StateService, private breakpointObserver: BreakpointObserver) {
		this.state = this.stateService.getState();

		const sub = this.breakpointObserver.observe('only screen and (orientation: landscape) and (max-height: 575.98px)').subscribe({
			next: (breakpointState) => {
				this.isMobileDevice = breakpointState.matches;
			}
		});
		this.subscriptions.push(sub);

		const stateSub = this.stateService.state$.subscribe({
			next: (state: State) => {
				this.state = state;
				this.showNavBar = this.shouldDisplayNavbar();
			}
		});
		this.subscriptions.push(stateSub)
		this.showNavBar = this.shouldDisplayNavbar();
	}

	shouldDisplayNavbar() {
		const url = window.location.pathname;

		if (
			url === '/' ||
			url.includes(`/${ONBOARDING}`) ||
			url.includes(`/${LINK_DISCORD}`) ||
			url.includes(KYC) ||
			url.includes(`/${PERMISSIONS}`) ||
			url.includes(`/${LOG_IN}`) ||
			url.includes(`/${CREATE_ACCOUNT}`) ||
			url.includes(`/${PROFILE_DETAILS}`) ||
			url.includes(`/${PAYPAL_PAYMENT_STATUS}`) ||
			url.includes(`/${PAYPAL_PAYMENT_CANCELLED}`) ||
			url.includes(`/${RADOM_PAYMENT_SUCCESS}`) ||
			url.includes(`/${RADOM_PAYMENT_FAILED}`)
		) {
			return false;
		} else {
			return this.state.jwt !== null && this.state.user !== null && this.state.user !== undefined;
		}
	}

	ngOnInit(): void {
		const routerSub = this.router.events.subscribe((val: Event) => {
			if (val instanceof NavigationStart) {
				this.setupToolbar(val.url);
				if (this.router.url.includes(MARKETS)) {
					this.navigationEnded = false;
				}
			}

			if (val instanceof NavigationEnd) {
				this.showNavBar = this.shouldDisplayNavbar();
				this.navigationEnded = true;
			}
		});
		this.subscriptions.push(routerSub);
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach(s => s.unsubscribe());
	}

	getLink(link: string) {
		return this.seperateFuturesItems.includes(link) ? [this.state?.mode === SolusMode.FUTURES ? FUTURES : '', link].join("/") : link;
	}

	setupToolbar(urlPath?: string) {
		const url = urlPath || window.location.pathname;

		const allowedUrls = [REFERRAL, DEPOSIT, MARKETS, LEADERBOARD, PORTFOLIO, CRYPTO, CASHOUT, EDIT_PROFILE, CHANGE_PASSWORD, AFFILIATE_DASHBOARD, OFFERS, SUPPORT];

		if (allowedUrls.some(u => url.includes(u))) {
			if (url.includes(DEPOSIT)) {
				this.showDepositButton = false;
			} else {
				this.showDepositButton = true;
			}

			this.showNavBar = this.shouldDisplayNavbar();
			this.activeLink = url;
		}
	}

	depositClick() {
		this.activeLink = DEPOSIT;
		this.router.navigate([DEPOSIT]);
	}
}
