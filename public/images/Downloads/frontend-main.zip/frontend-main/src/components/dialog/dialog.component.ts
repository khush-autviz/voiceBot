import { CommonModule } from '@angular/common';
import { AfterViewInit, Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { Router } from '@angular/router';
import { DISCORD_SUPPORT_CHANNEL_LINK } from 'src/constants/constants';
import { APIService } from 'src/service/api.service';
import { MatDialogData } from 'src/types/app.types';

const materialModules = [MatIconModule, MatButtonModule, MatDialogModule];

@Component({
	selector: 'app-dialog',
	standalone: true,
	imports: [CommonModule, ...materialModules],
	templateUrl: './dialog.component.html',
	styleUrls: ['./dialog.component.scss']
})
export class DialogComponent implements AfterViewInit {

	url: string = DISCORD_SUPPORT_CHANNEL_LINK;

	constructor(public dialogRef: MatDialogRef<DialogComponent>, @Inject(MAT_DIALOG_DATA) public data: MatDialogData, private router: Router, private api: APIService) {

	}

	ngAfterViewInit(): void {
		if(!this.data.skipLog) {
			this.api.log(this.data).subscribe();
		}
	}

	redirectToDestination() {
		if(this.data.redirect) {
			if (this.data.mergeQueryParams) {
				this.router.navigate([this.data.redirect], { queryParamsHandling: 'merge' });
			} else {
				this.router.navigate([this.data.redirect]);
			}
		}
		this.dialogRef.close();
	}

	openDiscord() {
		this.dialogRef.close();
		window.open(this.url, '_blank');
	}
}
