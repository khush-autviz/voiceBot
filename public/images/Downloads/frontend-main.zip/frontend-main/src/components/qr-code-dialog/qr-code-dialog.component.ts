import { CommonModule } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { QRCodeModule } from 'angularx-qrcode';
import { QrCodeDialogData } from 'src/types/app.types';

const materialModules = [MatIconModule, MatButtonModule, MatDialogModule];

@Component({
	selector: 'app-qr-code-dialog',
	standalone: true,
	imports: [CommonModule, QRCodeModule, ...materialModules],
	templateUrl: './qr-code-dialog.component.html',
	styleUrl: './qr-code-dialog.component.scss'
})
export class QrCodeDialogComponent {
	constructor(@Inject(MAT_DIALOG_DATA) public data: QrCodeDialogData) { }
}
