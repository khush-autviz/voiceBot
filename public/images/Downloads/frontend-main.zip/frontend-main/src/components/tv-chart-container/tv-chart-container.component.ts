import { BreakpointObserver } from '@angular/cdk/layout';
import { CommonModule } from '@angular/common';
import { AfterViewInit, Component, Input, OnChanges, OnDestroy, SimpleChanges } from '@angular/core';
import * as moment from 'moment';
import { Subscription } from 'rxjs';
import api from 'solus-datafeed';
import { ChartingLibraryFeatureset, ChartingLibraryWidgetOptions, IChartingLibraryWidget, IOrderLineAdapter, ResolutionString, Timezone, widget } from 'src/assets/js/charting_library';
import { SOLUS_OTC_PREFIX } from 'src/constants/constants';
import { TIMEZONES } from 'src/constants/timezones.constant';
import { TvChartService } from 'src/service/tv-chart.service';
import { SpotTrade, TradePosition } from 'src/types/app.types';

@Component({
	selector: 'app-tv-chart-container',
	standalone: true,
	imports: [CommonModule],
	templateUrl: './tv-chart-container.component.html',
	styleUrls: ['./tv-chart-container.component.scss']
})
export class TvChartContainerComponent implements OnChanges, AfterViewInit, OnDestroy {
	private _symbol: ChartingLibraryWidgetOptions['symbol'] = 'BINANCE:BTCUSDT';
	private _interval: ChartingLibraryWidgetOptions['interval'] = '1' as ResolutionString;
	// BEWARE: no trailing slash is expected in feed URL
	private _datafeedUrl = '';
	private _libraryPath: ChartingLibraryWidgetOptions['library_path'] = 'assets/js/charting_library/';
	private _clientId: ChartingLibraryWidgetOptions['client_id'] = 'tradingview.com';
	private _userId: ChartingLibraryWidgetOptions['user_id'] = 'public_user_id';
	private _fullscreen: ChartingLibraryWidgetOptions['fullscreen'] = false;
	private _autosize: ChartingLibraryWidgetOptions['autosize'] = true;
	private _containerId: ChartingLibraryWidgetOptions['container'] = 'tv_chart_container';
	private _tvWidget: IChartingLibraryWidget | null = null;
	private _theme: ChartingLibraryWidgetOptions['theme'] = 'dark';

	@Input()
	set symbol(symbol: ChartingLibraryWidgetOptions['symbol']) {
		this._symbol = symbol || this._symbol;
	}

	@Input()
	set interval(interval: ChartingLibraryWidgetOptions['interval']) {
		this._interval = interval || this._interval;
	}

	@Input()
	set datafeedUrl(datafeedUrl: string) {
		this._datafeedUrl = datafeedUrl || this._datafeedUrl;
	}

	@Input()
	set libraryPath(libraryPath: ChartingLibraryWidgetOptions['library_path']) {
		this._libraryPath = libraryPath || this._libraryPath;
	}

	@Input()
	set clientId(clientId: ChartingLibraryWidgetOptions['client_id']) {
		this._clientId = clientId || this._clientId;
	}

	@Input()
	set userId(userId: ChartingLibraryWidgetOptions['user_id']) {
		this._userId = userId || this._userId;
	}

	@Input()
	set fullscreen(fullscreen: ChartingLibraryWidgetOptions['fullscreen']) {
		this._fullscreen = fullscreen || this._fullscreen;
	}

	@Input()
	set autosize(autosize: ChartingLibraryWidgetOptions['autosize']) {
		this._autosize = autosize || this._autosize;
	}

	@Input()
	set containerId(containerId: ChartingLibraryWidgetOptions['container']) {
		this._containerId = containerId || this._containerId;
	}

	@Input()
	set theme(theme: ChartingLibraryWidgetOptions['theme']) {
		this._theme = theme || this._theme;
	}

	get theme() { return this._theme; }

	subscriptions: Subscription[] = [];
	intervals: NodeJS.Timeout[] = [];
	positionAdapters: IOrderLineAdapter[] = [];
	isMobileDevice: boolean = false;
	showIndicators: boolean = false;
	isIndicatorModalOpen: boolean = false;

	constructor(private breakpointObserver: BreakpointObserver, private tvChartService: TvChartService) {
		const sub = this.breakpointObserver.observe('only screen and (orientation: landscape) and (max-height: 575.98px)').subscribe({
			next: (breakpointState) => {
				this.isMobileDevice = breakpointState.matches;
			}
		});
		this.subscriptions.push(sub);
	}

	ngOnChanges(changes: SimpleChanges): void {
		if (changes && ((changes['symbol'] && changes['symbol'].currentValue !== changes['symbol'].previousValue) || (changes['theme'] && changes['theme'].currentValue !== changes['theme'].previousValue))) {
			this.constructWidget();
		}
	}

	ngAfterViewInit(): void {
		setTimeout(() => {
			this.constructWidget();
		}, 1);
	}

	ngOnDestroy() {
		if (this._tvWidget !== null) {
			this._tvWidget.remove();
			this._tvWidget = null;
		}

		this.subscriptions.forEach(s => s.unsubscribe());
	}

	checkIfChartElementPresent() {
		const element = document.getElementById('tv_chart_container');

		if (element) return true;
		return false;
	}

	constructWidget() {
		if (this.checkIfChartElementPresent()) {
			this.showIndicators = false;
			const isSolusExchange = this._symbol?.split(':')[0] === SOLUS_OTC_PREFIX;
			const widgetOptions: ChartingLibraryWidgetOptions = {
				symbol: this._symbol,
				datafeed: isSolusExchange ? api["solus"] : api["binance_futures"],
				interval: this._interval,
				container: this._containerId,
				library_path: this._libraryPath,
				locale: 'en',
				theme: this._theme,
				disabled_features: ["edit_buttons_in_legend", "go_to_date", "hide_main_series_symbol_from_indicator_legend", "scales_date_format", "symbol_info", "timeframes_toolbar", "create_volume_indicator_by_default", "vert_touch_drag_scroll", "side_toolbar_in_fullscreen_mode", "always_show_legend_values_on_mobile", "show_zoom_and_move_buttons_on_touch", "control_bar", "header_widget", ...this.isMobileDevice ? ["legend_widget"] as ChartingLibraryFeatureset[] : []],
				enabled_features: ["seconds_resolution", "low_density_bars"],
				client_id: this._clientId,
				user_id: this._userId,
				fullscreen: this._fullscreen,
				autosize: this._autosize,
				timezone: this.getOslonTimezone() as Timezone
			};

			const tvWidget = new widget(widgetOptions);
			this._tvWidget = tvWidget;
			this.tvChartService.setTVWidget(tvWidget);

			this._tvWidget.onChartReady(() => {
				this._tvWidget?.activeChart().setVisibleRange({ from: moment().subtract('30', 'minutes').unix() }, { percentRightMargin: 15 });
				this.showIndicators = true;

				this._tvWidget?.applyOverrides({ "mainSeriesProperties.showCountdown": true });
			});
		}
	}

	getTimeDifference(dateTime: Date) {
		const diffSec = Math.abs(moment().diff(moment(dateTime), 'seconds'));

		const formatTime = (time: number): string => time < 10 ? `0${time}` : `${time}`;

		const minutes = formatTime(Math.floor(diffSec / 60));
		const seconds = formatTime(diffSec % 60);

		return { minutes, seconds };
	}

	getTradeMarkerText(trade: SpotTrade) {
		const { minutes, seconds } = this.getTimeDifference(trade.expiresAt);

		return `${trade.tradePosition === TradePosition.Long ? 'HIGHER' : 'LOWER'} | $${trade.entryPrice} | ${minutes}:${seconds}`
	}

	toggleIndicators() {
		this.isIndicatorModalOpen = !this.isIndicatorModalOpen;
		this._tvWidget?.activeChart?.()?.executeActionById('insertIndicator');
	}

	getOslonTimezone() {
		const timezone = JSON.parse(localStorage.getItem('tradingview.chartproperties') || '{}').timezone;
		const ianaTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
		const found = TIMEZONES.find((tz) => {
			if (timezone) {
				return tz.IANA == timezone;
			}
			return tz.IANA == ianaTimezone;
		});
		return found?.OSLON || found?.IANA || 'Etc/UTC';
	}

}
