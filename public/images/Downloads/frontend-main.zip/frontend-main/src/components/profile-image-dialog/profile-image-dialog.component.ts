import { CommonModule } from '@angular/common';
import { Component, ViewEncapsulation } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { ImageCroppedEvent, ImageCropperComponent } from 'ngx-image-cropper';

const materialModules = [MatDialogModule, MatButtonModule];
const components = [ImageCropperComponent];

@Component({
	selector: 'app-profile-image-dialog',
	standalone: true,
	imports: [CommonModule, ...materialModules, ...components],
	templateUrl: './profile-image-dialog.component.html',
	styleUrl: './profile-image-dialog.component.scss',
	encapsulation: ViewEncapsulation.None
})
export class ProfileImageDialogComponent {

	imageChangedEvent: Event | null = null;
	croppedImage: SafeUrl = '';
	croppedImageBlob: Blob | null | undefined;

	constructor(private sanitizer: DomSanitizer, private dialogRef: MatDialogRef<ProfileImageDialogComponent>) { }


	imageCropped(event: ImageCroppedEvent) {
		this.croppedImage = this.sanitizer.bypassSecurityTrustUrl(event.objectUrl as string);
		this.croppedImageBlob = event.blob;
	}

	fileChangeEvent(event: Event): void {
		this.imageChangedEvent = event;
	}

	saveAvatar() {
		this.dialogRef.close({ blob: this.croppedImageBlob, url: this.croppedImage });
	}
}
