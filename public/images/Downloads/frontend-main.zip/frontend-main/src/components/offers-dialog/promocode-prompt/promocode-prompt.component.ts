import { CommonModule } from '@angular/common';
import { AfterViewInit, Component, Inject, Input } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { Router } from '@angular/router';
import { APIService } from 'src/service/api.service';
import { PromocodeDialogData } from 'src/types/app.types';

const materialModules = [MatIconModule, MatButtonModule, MatDialogModule];

@Component({
  selector: 'app-promocode-prompt',
  standalone: true,
  imports: [CommonModule, ...materialModules],
  templateUrl: './promocode-prompt.component.html',
  styleUrl: './promocode-prompt.component.scss'
})
export class PromocodePromptComponent {
	@Input() title: string = 'Default Title';
	@Input() message: string = 'Default message content.';
	@Input() confirmButtonText: string = 'Confirm';
	@Input() cancelButtonText: string = 'Cancel';
	@Input() redirectUrl: string = '';
	@Input() mergeQueryParams: boolean = false;
	@Input() customStyles: { [key: string]: any } = {};
	@Input() additionalActions: { text: string, action: () => void }[] = [];

	constructor(public dialogRef: MatDialogRef<PromocodePromptComponent>, @Inject(MAT_DIALOG_DATA) public data: PromocodeDialogData, private router: Router, private api: APIService) {}

	ngAfterViewInit(): void {
		if(!this.data.skipLog) {
			this.api.log(this.data).subscribe();
		}
	}

	redirectToDestination() {
		if(this.redirectUrl) {
			if (this.mergeQueryParams) {
				this.router.navigate([this.redirectUrl], { queryParamsHandling: 'merge' });
			} else {
				this.router.navigate([this.redirectUrl]);
			}
		}
		this.dialogRef.close();
	}

	openDiscord() {
		this.dialogRef.close();
		window.open(this.data.url || 'https://discord.com', '_blank');
	}

	onConfirm() {
		this.redirectToDestination();
	}

	onCancel() {
		this.dialogRef.close();
	}
}
