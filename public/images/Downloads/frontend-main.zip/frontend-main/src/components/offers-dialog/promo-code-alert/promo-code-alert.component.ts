import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';

const DEFAULT_CUSTOM_STYLES = {
  card: {
    backgroundColor: '#f5f5f5',
    borderRadius: '8px',
    padding: '16px',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
  },
  content: {
    margin: '0',
  },
  message: {
    margin: '0',
  },
  actions: {
    display: 'flex',
    justifyContent: 'flex-end',
  },
  dismissButton: {
    margin: '0',
  }
};

@Component({
  selector: 'app-promo-code-alert',
  standalone: true,
  imports: [CommonModule, MatCardModule, MatButtonModule],
  templateUrl: './promo-code-alert.component.html',
  styleUrl: './promo-code-alert.component.scss'
})
export class PromoCodeAlertComponent {
  @Input() promoMessage: string;
  @Input() customStyles: any = DEFAULT_CUSTOM_STYLES;
  @Output() dismissAlert = new EventEmitter<void>();

  constructor() {
    this.promoMessage = '';
    this.customStyles = DEFAULT_CUSTOM_STYLES;
  }

  emitDismissAlert() {
    this.dismissAlert.emit();
  }
}
