import { CommonModule } from '@angular/common';
import { Component, Input, OnDestroy } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { CHANGE_PASSWORD, CRYPTO, EDIT_PROFILE, KYC, LOG_IN } from 'src/constants/ui.routes';
import { ImageErrorDirective } from 'src/directives/image-error.directive';
import { APIService } from 'src/service/api.service';
import { StateService } from 'src/service/state.service';
import { State } from 'src/types/app.types';
import { ConfirmDeleteDialogComponent } from '../confirm-delete-dialog/confirm-delete-dialog.component';
import { MatSnackBar } from '@angular/material/snack-bar';

const materialModules = [MatIconModule, MatButtonModule, MatMenuModule, MatDialogModule];

@Component({
	selector: 'app-nav-avatar',
	standalone: true,
	imports: [CommonModule, ImageErrorDirective, ...materialModules],
	templateUrl: './nav-avatar.component.html',
	styleUrl: './nav-avatar.component.scss'
})
export class NavAvatarComponent implements OnDestroy {
	@Input() marketScreen: boolean = false;

	state: State;
	updateWalkthroughSub!: Subscription;
	stateSubscription: Subscription;

	constructor(private router: Router, private stateService: StateService, private api: APIService, private matDialog: MatDialog, private snackbar: MatSnackBar) {
		this.state = this.stateService.getState();
		this.stateSubscription = this.stateService.state$.subscribe((res: State) => {
			this.state = res;
		});

	}

	ngOnDestroy(): void {
		this.updateWalkthroughSub?.unsubscribe();
		this.stateSubscription.unsubscribe();
	}

	onWallet() {
		this.router.navigate([CRYPTO]);
	}

	onUpdateProfile() {
		this.router.navigate([EDIT_PROFILE]);
	}

	onChangePassword() {
		this.router.navigate([CHANGE_PASSWORD]);
	}

	onLogout() {
		this.stateService.onLogout([LOG_IN]);
	}

	onCompleteKYC() {
		this.router.navigate([KYC]);
	}

	onDeleteAccount() {
		this.matDialog.open(ConfirmDeleteDialogComponent, {
			width: '450px',
			disableClose: true
		});
	}
}
