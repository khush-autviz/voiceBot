import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { APIService } from 'src/service/api.service';
import { StateService } from 'src/service/state.service';

@Component({
	selector: 'app-confirm-delete-dialog',
	standalone: true,
	imports: [CommonModule, MatDialogModule, MatButtonModule, MatSnackBarModule, MatProgressSpinnerModule],
	templateUrl: './confirm-delete-dialog.component.html',
	styleUrl: './confirm-delete-dialog.component.scss'
})
export class ConfirmDeleteDialogComponent {
	loading: boolean = false;

	constructor(public dialogRef: MatDialogRef<ConfirmDeleteDialogComponent>, private api: APIService, private stateService: StateService, private snackbar: MatSnackBar) { }

	onConfirmDelete(): void {
		// Logic for confirming delete (call API or perform other actions)
		this.loading = true;

		this.api.deleteAccount().subscribe({
			next: (res) => {
				if (res.success) {
					this.snackbar.open('Account Deleted! Signing you out...', undefined, {
						verticalPosition: 'bottom',
						panelClass: ['snackbar-success'],
					});

					this.stateService.onLogout(['/']);
				} else {
					this.snackbar.open('We were unable to delete your account. Please contact our support team.', undefined, {
						verticalPosition: 'bottom',
						panelClass: ['snackbar-error'],
					});
				}
				this.loading = false;
				this.dialogRef.close();
			},
			error: (err: HttpErrorResponse) => {
				console.error(err);

				this.snackbar.open('We were unable to delete your account. Please contact our support team.', undefined, {
					verticalPosition: 'bottom',
					panelClass: ['snackbar-error'],
				});
				this.loading = false;
				this.dialogRef.close();
			}
		});
	}

	onCancel(): void {
		// Logic for canceling delete
		this.dialogRef.close(false);
	}
}
