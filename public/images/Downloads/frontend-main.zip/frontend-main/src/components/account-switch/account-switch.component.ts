import { CommonModule } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { Subscription } from 'rxjs';
import { CoinDecimalPipe } from 'src/pipes/coin-decimal.pipe';
import { CurrencySymbolPipe } from 'src/pipes/currency-symbol.pipe';
import { APIService } from 'src/service/api.service';
import { MarketService } from 'src/service/market.service';
import { StateService } from 'src/service/state.service';
import { APIResponse, AppConfig, AppConfigEnum, State, SupportedCoin } from 'src/types/app.types';

const materialModules = [MatIconModule, MatMenuModule, MatSnackBarModule];
const pipes = [CoinDecimalPipe, CurrencySymbolPipe];

@Component({
	selector: 'app-account-switch',
	standalone: true,
	imports: [CommonModule, ...materialModules, ...pipes],
	templateUrl: './account-switch.component.html',
	styleUrl: './account-switch.component.scss'
})
export class AccountSwitchComponent implements OnInit {
	@Input() marketScreen: boolean = false;

	state: State;
	stateSub: Subscription;
	SupportedCoin = SupportedCoin;

	demoAccountReloadAmount = 0;
	isDemoAccountLowBalance = false;

	constructor(private stateService: StateService, private marketService: MarketService, private api: APIService, private snackbar: MatSnackBar) {
		this.state = this.stateService.getState();
		this.stateSub = this.stateService.state$.subscribe({
			next: (state: State) => {
				this.state = state;
			}
		});
	}

	ngOnInit(): void {
		this.api.getSettings().subscribe({
			next: (res: APIResponse<AppConfig[]>) => {
				if (res.success) {
					this.stateService.setConfig(res.body);

					const configAmount = this.stateService.getConfig(AppConfigEnum.DEMO_USDT_RELOAD_AMOUNT);
					if (configAmount) {
						this.demoAccountReloadAmount = Number(configAmount);
					}
				}
			},
		});
	}

	getBalance(currency: SupportedCoin) {
		const balance = this.state.balance?.find(b => b.symbol === SupportedCoin[currency]);

		if (currency === SupportedCoin.DEMO_USDT) {
			if (balance && balance.balance < this.demoAccountReloadAmount) {
				this.isDemoAccountLowBalance = true;
			} else {
				this.isDemoAccountLowBalance = false;
			}
		}

		return balance ? balance.balance : 0;
	}

	switchAccount(coin: SupportedCoin) {
		this.stateService.swichMode(this.state.mode, coin);
	}

	topUpDemoAccount() {
		this.api.reloadDemoAccount().subscribe({
			next: (res) => {
				if (res.success) {
					this.snackbar.open('Top up successful on Demo Account.', undefined, {
						panelClass: 'snackbar-success',
					});

					this.stateService.refreshBalance();
				} else {
					this.snackbar.open('Top up failed on Demo Account! Please try again.', undefined, {
						panelClass: 'snackbar-error',
					});
				}
			},
			error: (err: any) => {
				console.error(err);

				this.snackbar.open('Top up failed on Demo Account! Please try again.', undefined, {
					panelClass: 'snackbar-error',
				});
			}
		});

	}
}
