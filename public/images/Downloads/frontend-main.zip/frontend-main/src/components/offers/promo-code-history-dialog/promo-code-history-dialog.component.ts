import { CommonModule } from '@angular/common';
import { Component, inject, Inject, OnInit, ViewEncapsulation } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatListModule } from '@angular/material/list';
import { PromoCodeHistoryDialogConfig } from 'src/types/app.types';
import { MatTableModule } from '@angular/material/table';
import { DomSanitizer } from '@angular/platform-browser';
import { CoinDecimalPipe } from 'src/pipes/coin-decimal.pipe';
import { CurrencySymbolPipe } from 'src/pipes/currency-symbol.pipe';

@Component({
	selector: 'app-promo-code-history-dialog',
	standalone: true,
	imports: [CommonModule, MatCardModule, MatButtonModule, MatListModule, MatListModule, MatTableModule, CoinDecimalPipe, CurrencySymbolPipe],
	templateUrl: './promo-code-history-dialog.component.html',
	styleUrl: './promo-code-history-dialog.component.scss',
	encapsulation: ViewEncapsulation.None,
})
export class PromoCodeHistoryDialogComponent implements OnInit {
	sanitizer = inject(DomSanitizer);

	historyDataSource: any[] = [];
	loading: boolean = false;

	constructor(@Inject(MAT_DIALOG_DATA) public data: PromoCodeHistoryDialogConfig, public dialogRef: MatDialogRef<PromoCodeHistoryDialogComponent>) { }

	ngOnInit(): void {
		this.loading = true;
		this.data.getHistory.subscribe({
			next: (res) => {
				if (res.success) {
					this.historyDataSource = res.body;
				} else {
					this.historyDataSource = [];
				}
				this.loading = false;
			},
			error: () => {
				this.historyDataSource = [];
				this.loading = false;
			}
		});
	}

	getColumns() {
		return this.data.displayedColumns.map(x => x.name);
	}

	getActiveClass(column: any, element: any) {
		if (column.activeField) {
			if (element[column.activeField] === 'ACTIVE') {
				return column.activeClass;
			}
		}
		return '';
	}
}
