import { CommonModule } from '@angular/common';
import { Component, Inject, ViewEncapsulation } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { PromoCodePromptConfig } from 'src/types/app.types';

@Component({
	selector: 'app-promo-code-prompt',
	standalone: true,
	imports: [CommonModule, MatIconModule, MatCardModule, MatSnackBarModule, MatDialogModule, MatInputModule, MatButtonModule, ReactiveFormsModule],
	templateUrl: './promo-code-prompt.component.html',
	styleUrl: './promo-code-prompt.component.scss',
	encapsulation: ViewEncapsulation.None
})
export class PromoCodePromptComponent {
	constructor(@Inject(MAT_DIALOG_DATA) public dialogData: PromoCodePromptConfig, public dialogRef: MatDialogRef<PromoCodePromptComponent>) { }

	form = new FormGroup({
		code: new FormControl('', [Validators.required]),
		tradeId: new FormControl(''),
	});

	closeDialog(): void {
		if (this.dialogRef) {
			this.dialogRef.close();
		}
	}

	submit() {
		this.dialogRef.close(this.form.value);
	}

}
