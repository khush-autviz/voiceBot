import { CommonModule } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatListModule } from '@angular/material/list';
import { PromoCodeAlertConfig } from 'src/types/app.types';

@Component({
	selector: 'app-promo-code-alert',
	standalone: true,
	imports: [CommonModule, MatCardModule, MatButtonModule, MatListModule],
	templateUrl: './promo-code-alert.component.html',
	styleUrl: './promo-code-alert.component.scss'
})
export class PromoCodeAlertComponent {
	constructor(@Inject(MAT_DIALOG_DATA) public dialogData: PromoCodeAlertConfig, public dialogRef: MatDialogRef<PromoCodeAlertComponent>) { }
}
