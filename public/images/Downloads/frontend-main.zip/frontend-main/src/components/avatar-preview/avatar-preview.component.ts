import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { SafeUrl } from '@angular/platform-browser';
import { ImageErrorDirective } from 'src/directives/image-error.directive';

const materialModules = [MatIconModule];

@Component({
	selector: 'app-avatar-preview',
	standalone: true,
	imports: [CommonModule, ImageErrorDirective, ...materialModules],
	templateUrl: './avatar-preview.component.html',
	styleUrls: ['./avatar-preview.component.scss'],
})
export class AvatarPreviewComponent {
	@Input() avatarPreviewUrl!: string | SafeUrl | undefined;
	@Output() editClicked = new EventEmitter<void>();
	showEdit: boolean = false;

	onEditClick(): void {
		this.editClicked.emit();
	}
}
