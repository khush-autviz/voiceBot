import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';

const materialModules = [MatPaginatorModule];

@Component({
	selector: 'app-pagination[currentPage][itemsPerPage][totalItems]',
	standalone: true,
	imports: [CommonModule, ...materialModules],
	templateUrl: './pagination.component.html',
	styleUrl: './pagination.component.scss'
})
export class PaginationComponent {
	@Input() currentPage!: number;
	@Input() itemsPerPage!: number;
	@Input() totalItems!: number;
	@Output() pageChanged: EventEmitter<PageEvent> = new EventEmitter();

	get totalPages(): number {
		return Math.ceil(this.totalItems / this.itemsPerPage);
	}

	changePage(pageEvent: PageEvent): void {
		const page = pageEvent.pageIndex + 1;

		if (page >= 1 && page <= this.totalPages) {
			this.currentPage = page;
			this.pageChanged.emit(pageEvent);
		} else {
			this.pageChanged.emit({ ...pageEvent, pageIndex: this.currentPage - 1 });
		}

	}
}
