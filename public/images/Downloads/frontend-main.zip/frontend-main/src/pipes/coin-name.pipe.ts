import { Pipe, PipeTransform } from '@angular/core';
import { SupportedCoin } from 'src/types/app.types';

@Pipe({
	name: 'coin',
	standalone: true,
	pure: true
})
export class CoinNamePipe implements PipeTransform {

	transform(value: SupportedCoin, args?: any): string {
		return SupportedCoin[value];
	}

}
