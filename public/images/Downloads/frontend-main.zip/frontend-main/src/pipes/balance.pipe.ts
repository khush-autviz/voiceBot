import { Pipe, PipeTransform } from '@angular/core';
import { Balance } from 'src/types/app.types';

@Pipe({
	name: 'balance',
	standalone: true,
	pure: true
})
export class BalancePipe implements PipeTransform {

	transform(balances: Balance[] | null, args?: string): number {
		if (balances === null) {
			return 0;
		}
		for (const balance of balances) {
			if (balance.symbol === args) {
				return balance.balance;
			}
		}
		return 0;
	}

}
