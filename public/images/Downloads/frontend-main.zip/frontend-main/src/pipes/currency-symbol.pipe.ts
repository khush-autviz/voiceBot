import { CurrencyPipe } from '@angular/common';
import { OnDestroy, Pipe, PipeTransform } from '@angular/core';
import { Subscription } from 'rxjs';
import { StateService } from 'src/service/state.service';
import { State, SupportedCoin } from 'src/types/app.types';
import { CoinNamePipe } from './coin-name.pipe';

@Pipe({
	name: 'currencySymbol',
	standalone: true,
	pure: true
})
export class CurrencySymbolPipe implements PipeTransform, OnDestroy {
	private state: State;
	private stateSub: Subscription;

	constructor(private stateService: StateService, private currencyPipe: CurrencyPipe, private coinNamePipe: CoinNamePipe) {
		this.state = stateService.getState();
		this.stateSub = this.stateService.state$.subscribe({
			next: (state: State) => {
				this.state = state;
			}
		});
	}

	transform(value: string | number | null, fixedCoin?: SupportedCoin) {
		const usdCoins = [SupportedCoin.USDT, SupportedCoin.DEMO_USDT, SupportedCoin.BONUS_USDT];

		if ((fixedCoin && !usdCoins.includes(fixedCoin)) || (!fixedCoin && (!usdCoins.includes(this.state.coin)))) {
			return value + ' ' + this.coinNamePipe.transform(this.state.coin);
		}
		return this.currencyPipe.transform(value, 'USD', true, '0.2-2') || '';
	}

	ngOnDestroy() {
		this.stateSub.unsubscribe();
	}
}
