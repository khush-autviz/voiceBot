import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
	name: 'ethAddress',
	standalone: true,
	pure: true,
})
export class EthereumAddressPipe implements PipeTransform {
	transform(value: any): string {
		if (value && value.length >= 42) {
			const prefix = value.slice(0, 4);
			const middle = '...';
			const suffix = value.slice(-4);
			return `${prefix}${middle}${suffix}`;
		} else {
			return value;
		}
	}
}
