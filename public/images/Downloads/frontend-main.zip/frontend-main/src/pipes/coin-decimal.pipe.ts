import { OnDestroy, Pipe, PipeTransform } from '@angular/core';
import { Subscription } from 'rxjs';
import { APIService } from 'src/service/api.service';
import { StateService } from 'src/service/state.service';
import { SolusCurrency, State, SupportedCoin } from 'src/types/app.types';

@Pipe({
	name: 'decimal',
	standalone: true,
	pure: true
})
export class CoinDecimalPipe implements PipeTransform, OnDestroy {

	private state: State;
	private stateSub: Subscription;

	constructor(private stateService: StateService, private api: APIService) {
		this.state = stateService.getState();
		this.stateSub = this.stateService.state$.subscribe({
			next: (state: State) => {
				this.state = state;
			}
		});
	}

	ngOnDestroy(): void {
		this.stateSub.unsubscribe();
	}

	transform(value: number, options: { decimalPlaces?: number, coinType?: number | undefined } = { decimalPlaces: 2 }): number {
		const currency: SolusCurrency | undefined =
			this.state.currencies.find(c => c.symbol === SupportedCoin[options.coinType || this.state.coin]);
		if (currency === undefined) {
			return 0;
		}
		return Number((value / Math.pow(10, currency.decimals)).toFixed(options.decimalPlaces));
	}

}
