import { ValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import { COUNTRY_CODES } from 'src/assets/country-codes';
import { CountryCode } from 'src/types/app.types';

// export function numberValidator(): ValidatorFn {
//     return (control: AbstractControl): ValidationErrors | null => {
//       const value: string = control.value;
//       if (!value) {
//         return null;
//       }
//       let isValid: boolean;
//       const valueArray = value.split('').filter(char => char !== '-');
//       isValid = valueArray?.every((value: string) =>
//         Number.isInteger(Number(value))) && valueArray.length >= 9 && valueArray.length <= 13;
//       return !isValid ? { incorrectNumber: true } : null;
//     }
//   }

export function countryCodeValidator(): ValidatorFn {
	return (control: AbstractControl): ValidationErrors | null => {
		const value: string = control.value;
		if (!value) {
			return null;
		}
		const exists = COUNTRY_CODES.map(
			(countryCode: CountryCode) => countryCode.code
		).includes(value);
		return !exists ? { incorrectCountryCode: true } : null;
	};
}
