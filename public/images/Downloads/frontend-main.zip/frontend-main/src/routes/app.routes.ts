import { Routes } from '@angular/router';
import { GetStartedComponent } from 'src/app/get-started/get-started.component';
import * as ROUTES from 'src/constants/ui.routes';
import { AuthGuard } from 'src/guards/auth.guard';
import { marketModeGuard } from 'src/guards/market-mode.guard';
import { rootRouteGuard } from 'src/guards/root-route.guard';
import { SolusMode } from 'src/types/app.types';

export const routes: Routes = [
	{ path: ROUTES.MARKETS, loadComponent: () => import('../app/market-trade-room/market-trade-room.component').then((m) => m.MarketTradeRoomComponent), canActivate: [AuthGuard, marketModeGuard(SolusMode.PRICE_PREDICTION)] },
	{ path: ROUTES.PORTFOLIO, loadComponent: () => import('../app/portfolio/portfolio.component').then((m) => m.PortfolioComponent), canActivate: [AuthGuard] },
	{ path: ROUTES.PROFILE_DETAILS, loadComponent: () => import('../app/profile-details/profile-details.component').then((m) => m.ProfileDetailsComponent), canActivate: [AuthGuard] },
	{ path: ROUTES.EDIT_PROFILE, loadComponent: () => import('../app/edit-profile/edit-profile.component').then((m) => m.EditProfileComponent), canActivate: [AuthGuard] },
	{ path: ROUTES.CHANGE_PASSWORD, loadComponent: () => import('../app/change-password/change-password.component').then((m) => m.ChangePasswordComponent), canActivate: [AuthGuard] },
	{ path: ROUTES.REFERRAL, loadComponent: () => import('../app/referral/referral.component').then((m) => m.ReferralComponent), canActivate: [AuthGuard] },
	{ path: ROUTES.ONBOARDING, loadComponent: () => import('../app/choose-product/choose-product.component').then((m) => m.ChooseProductComponent), canActivate: [AuthGuard], },
	{ path: ROUTES.OFFERS, loadComponent: () => import('../app/offers/offers.component').then((m) => m.OffersComponent), canActivate: [AuthGuard] },
	{ path: ROUTES.SUPPORT, loadComponent: () => import('../app/support/support.component').then((m) => m.SupportComponent), canActivate: [AuthGuard] },
	// PUBLIC ROUTES
	{ path: ROUTES.LINK_DISCORD, loadComponent: () => import('../app/link-discord/link-discord.component').then((m) => m.LinkDiscordComponent) },
	{ path: ROUTES.GOOGLE_SIGN_IN, loadComponent: () => import('../app/google-signin/google-signin.component').then((m) => m.GoogleSigninComponent) },
	{
		path: ROUTES.PAYPAL_PAYMENT_STATUS,
		pathMatch: 'full',
		loadComponent: () => import('../app/payment-status/payment-status.component').then((m) => m.PaymentStatusComponent)
	},
	{
		path: ROUTES.PAYPAL_PAYMENT_CANCELLED,
		pathMatch: 'full',
		loadComponent: () => import('../app/payment-status/payment-status.component').then((m) => m.PaymentStatusComponent)
	},
	{
		path: ROUTES.RADOM_PAYMENT_SUCCESS,
		pathMatch: 'full',
		loadComponent: () => import('../app/payment-status/payment-status.component').then((m) => m.PaymentStatusComponent)
	},
	{
		path: ROUTES.RADOM_PAYMENT_FAILED,
		pathMatch: 'full',
		loadComponent: () => import('../app/payment-status/payment-status.component').then((m) => m.PaymentStatusComponent)
	},
	{
		path: '',
		canActivate: [rootRouteGuard],
		component: GetStartedComponent,
		children: [
			{
				path: '',
				redirectTo: ROUTES.LOG_IN,
				pathMatch: 'full'
			},
			{
				path: ROUTES.LOG_IN,
				loadComponent: () => import('../app/login/login.component').then((m) => m.LoginComponent)
			},
			{
				path: ROUTES.CREATE_ACCOUNT,
				loadComponent: () => import('../app/create-account/create-account.component').then((m) => m.CreateAccountComponent)
			},
			{
				path: ROUTES.CREATE_ACCOUNT + '/:referral-code',
				loadComponent: () => import('../app/create-account/create-account.component').then((m) => m.CreateAccountComponent)
			},
			{
				path: ROUTES.INVITE + '/:referral-code',
				loadComponent: () => import('../app/create-account/create-account.component').then((m) => m.CreateAccountComponent)
			},
			{
				path: ROUTES.FORGOT_PASSWORD,
				loadComponent: () => import('../app/forgot-password/forgot-password.component').then((m) => m.ForgotPasswordComponent)
			},
		]
	},

	// KYC ROUTES
	{
		path: ROUTES.KYC,
		canActivate: [AuthGuard],
		children: [
			{
				path: '',
				loadComponent: () => import('../app/kyc-form/kyc-form.component').then((m) => m.KycFormComponent)
			},
			{
				path: ROUTES.PERMISSIONS,
				loadComponent: () => import('../app/permission/permission.component').then((m) => m.PermissionComponent)
			},
			{
				path: ROUTES.SUCCESS,
				loadComponent: () => import('../app/success-kyc/success-kyc.component').then((m) => m.SuccessKycComponent)
			},
		]
	},

	// WALLET ROUTES
	{
		path: ROUTES.CRYPTO,
		canActivate: [AuthGuard],
		children: [
			{
				path: '',
				loadComponent: () => import('../app/paid-mode/wallet/wallet.component').then((m) => m.WalletComponent)
			},
			{
				path: ROUTES.CASHOUT,
				loadComponent: () => import('../app/paid-mode/cashout/cashout.component').then((m) => m.CashoutComponent)
			},
			{
				path: ROUTES.PASSBOOK,
				loadComponent: () => import('../app/passbook/passbook.component').then((m) => m.PassbookComponent)
			},
		]
	},

	// DEPOSIT ROUTES
	{
		path: ROUTES.DEPOSIT,
		canActivate: [AuthGuard],
		children: [
			{
				path: '',
				loadComponent: () => import('../app/deposit/deposit.component').then((m) => m.DepositComponent)
			},
			{
				path: ROUTES.CRYPTO,
				loadComponent: () => import('../app/deposit/methods/radom-deposit/radom-deposit.component').then((m) => m.RadomDepositComponent)
			},
			{
				path: ROUTES.POLYGON,
				loadComponent: () => import('../app/deposit/methods/polygon-deposit/polygon-deposit.component').then((m) => m.PolygonDepositComponent)
			},
			{
				path: ROUTES.PAYPAL,
				loadComponent: () => import('../app/deposit/methods/paypal-deposit/paypal-deposit.component').then((m) => m.PaypalDepositComponent)
			},
			{
				path: ROUTES.UPI,
				loadComponent: () => import('../app/deposit/methods/upi-deposit/upi-deposit.component').then((m) => m.UpiDepositComponent)
			},

		]
	},

	{
		path: '**',
		redirectTo: ROUTES.LOG_IN,
	}

];
