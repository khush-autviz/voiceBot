import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
	selector: 'img',
	standalone: true
})
export class ImageErrorDirective {
	@Input()
	placeholder: string = '../assets/lion.svg';

	constructor(private el: ElementRef) { }

	@HostListener("error")
	private onError() {
		this.el.nativeElement.src = this.placeholder;
	}
}
