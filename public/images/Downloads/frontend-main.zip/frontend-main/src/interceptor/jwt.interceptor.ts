import { HttpContextToken, HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpStatusCode } from "@angular/common/http";
import { inject, Injectable } from "@angular/core";
import { Router } from "@angular/router";
import * as moment from "moment";
import { Observable } from "rxjs";
import { AFFILIATE_UPDATE_CLICK_COUNT_API, ERROR_LOG, PUBLIC } from "src/constants/api.routes";
import { JWT, JWT_CREATED_AT } from "src/constants/constants";
import { CREATE_ACCOUNT, FORGOT_PASSWORD, LOG_IN } from "src/constants/ui.routes";
import { StateService } from "src/service/state.service";

export const BYPASS_AUTH_HEADER = new HttpContextToken(() => false);

@Injectable({
	providedIn: 'root'
})
export class JwtInterceptor implements HttpInterceptor {

	constructor(private router: Router) { }

	intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
		const stateService = inject(StateService);
		const jwt: string | null = localStorage.getItem(JWT);
		if (this.shouldAuthenticate(req)) {
			if (jwt !== null) {
				const jwtCreatedAt = localStorage.getItem(JWT_CREATED_AT);

				if (jwtCreatedAt !== null) {
					const hoursDiff = moment().diff(moment(jwtCreatedAt, 'DD-MM-YYYY HH:mm:ss'), 'hours', true);

					if (hoursDiff < 24) {
						return next.handle(this.addJwt(req, jwt));
					} else {
						if (![LOG_IN, CREATE_ACCOUNT, FORGOT_PASSWORD].some(url => this.router.url.includes(url))) {
							try {
								stateService.onLogout(['/']);
							} catch (err: any) {
								console.error(err);

								localStorage.clear();
								this.router.navigate(['/']);
							}
						}
						throw new HttpErrorResponse({ status: HttpStatusCode.Unauthorized });
					}
				}

				return next.handle(this.addJwt(req, jwt));
			} else {
				if (req.url.includes(ERROR_LOG)) {
					return next.handle(req);
				} else {
					if (![LOG_IN, CREATE_ACCOUNT, FORGOT_PASSWORD].some(url => this.router.url.includes(url))) {
						try {
							stateService.onLogout(['/']);
						} catch (err: any) {
							console.error(err);

							localStorage.clear();
							this.router.navigate(['/']);
						}
					}
					throw new HttpErrorResponse({ status: HttpStatusCode.Unauthorized });
				}
			}
		} else {
			return next.handle(req);
		}
	}

	private shouldAuthenticate(httpRequest: HttpRequest<any>): boolean {
		return !httpRequest.url.includes(PUBLIC) && !httpRequest.url.includes(AFFILIATE_UPDATE_CLICK_COUNT_API);
	}

	private addJwt(httpRequest: HttpRequest<any>, jwt: string): HttpRequest<any> {
		// TODO: replace with a boolean func in shouldAuthenticate
		if (httpRequest.context.get(BYPASS_AUTH_HEADER) !== true) {
			return httpRequest.clone({
				setHeaders: {
					Authorization: `Bearer ${jwt}`
				}
			});
		}

		return httpRequest;
	}

}
