import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, catchError, throwError } from 'rxjs';
import { CREATE_ACCOUNT, FORGOT_PASSWORD, LOG_IN } from 'src/constants/ui.routes';
import { StateService } from 'src/service/state.service';

@Injectable({
	providedIn: 'root',
})
export class GlobalErrorHandler implements HttpInterceptor {
	router = inject(Router);

	intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
		const stateService = inject(StateService);

		return next.handle(req).pipe(catchError((error: HttpErrorResponse) => {
			if (error.status && error.status === 403) {
				if (![LOG_IN, CREATE_ACCOUNT, FORGOT_PASSWORD].some(url => this.router.url.includes(url))) {
					try {
						stateService.onLogout(['/']);
					} catch (err: any) {
						console.error(err);

						localStorage.clear();
						this.router.navigate(['/']);
					}
				}
			}
			console.error(error);
			return throwError(() => error);
		}));
	}
}
